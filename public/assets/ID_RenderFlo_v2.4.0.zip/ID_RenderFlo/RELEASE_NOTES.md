# ID RenderFlo — v2.4.0 Release Notes
**Universal Industrial Design Studio & Parametric CAD Pipeline for Blender**  
*Created by Sahitya Kashyap ([sahityakashyap.in](https://sahityakashyap.in))*

---

## 🚀 What's New in v2.4.0

### 1. 🦏 Native Rhino `.3DM` CAD Importer
ID RenderFlo's isolated CAD engine now natively imports Rhinoceros 3D (`.3dm`) files directly alongside `.STEP`, `.STP`, `.IGES`, and `.STL`:
* **Geometry Engine**: Direct extraction of Rhino `Mesh`, `Brep`, `Extrusion`, and `SubD` objects with cached render meshes.
* **True CAD Split Normals**: Converts Rhino surface normals into custom split vertex normals (`normals_split_custom_set_from_vertices`), guaranteeing razor-sharp industrial design fillets, chamfers, and bezels without shading artifacts or black edge clipping.
* **Rhino Layer-to-Material Mapping**: Automatically translates Rhino layers and their native display colors into distinct Blender Principled BSDF materials (`Rhino_<LayerName>`). Your imported product arrives pre-configured for instant colorway adjustments in the CMF Matrix!
* **Smart Unit Detection**: Automatically queries Rhino model unit metadata (`model.Settings.ModelUnitSystem`) to cleanly scale millimeters, centimeters, inches, or meters to native Blender dimensions.
* **Automated Product Alignment**: Automatically centers CAD parts on the XY origin, snaps the base to the Z=0 ground plane, and positions the target empty at the product's optical center.

---

### 2. 💡 KeyShot-Style Procedural HDRI Dome & Interactive 2D Pin Canvas
Bring professional studio lighting into Blender with a fully procedural environment dome and interactive pin system:
* **Interactive 2D Pin Canvas**: Launch a real-time, interactive 2D panoramic canvas directly in the 3D Viewport. Visually position pins across the latitude/longitude dome map with live viewport feedback.
* **Viewport Isolation**: The 2D canvas strictly renders within the active working viewport and automatically disables when secondary viewports or render cameras are focused.
* **Pin Types & Control**:
  * **Round Pins** (`CIRCLE`): Specular spotlight pins with independent radius and falloff softness.
  * **Softbox Strips** (`RECT`): Rectangular softbox lights with adjustable aspect ratio and 2D tilt rotation.
  * **Eyedropper Normal Raycaster**: Click on any surface point of your 3D CAD model to cast a reflection vector and automatically calculate the required azimuth and elevation to place the specular highlight directly on that surface.
* **External HDRI Support**: Seamlessly switch between the procedural dome and high-dynamic-range image maps (`.hdr` / `.exr`) with one-click browsing, intensity, and global dome rotation.

---

### 3. 🔦 Simultaneous Dual-Lighting Pipeline
* Run both the **Procedural HDRI Dome & Pins** and **Physical Studio Lamps** together in the same scene without conflict.
* The segmented lighting tabs (`[ HDRI Dome & Pins ]` | `[ Physical Lights ]`) serve as a clean UI filter while Cycles and EEVEE evaluate both lighting sources simultaneously.
* **Physical Light Deletion**: Easily remove unwanted lamps directly from the N-panel via dedicated `[ X ]` buttons without having to open the Outliner.

---

### 4. 🎨 Color Management Look & Contrast Selector
* Added a dedicated **Contrast** selector right beside **Exposure** in Section 5 (Environment & Backdrop).
* Choose instantly between all 8 standard Blender color management looks: *None*, *Very Low*, *Low*, *Medium Low*, *Medium*, *Medium High*, *High*, and *Very High Contrast*.

---

### 5. 📐 HardOps-Inspired Collapsible UI Navigation
Eliminate vertical N-panel scroll clutter with streamlined, collapsible module headers:
* **CAD Engine & Import**
* **New Studio Defaults**
* **1. Format & Aspect Ratio**
* **2. Studio Camera & Framing**
* **3. CMF Variations**
* **4. Lighting Rig (HDRI & Physical)**
* **5. Environment, Floor & Backdrop**
* **6. GPU & Fast Render Queue**

Each section expands and collapses with a single click (`▼` / `▶`), keeping your workspace focused and neat.

---

### 6. 🔒 Studio Padlock & Live Auto-Save Integrity
* **Padlock Protection**: Lock hero camera positions and studio setups (`is_locked`) against accidental auto-save overwrites.
* **Unblocked Tweaking**: Lighting and HDRI pin adjustments remain fully interactive while locked, accompanied by a 1-click **Unlock Padlock Banner** when you want to resume auto-saving camera transforms.

---

## 🛠️ System Compatibility
* **Blender Versions**: 100% backward- and forward-compatible across **Blender 3.6 LTS, 4.0, 4.1, 4.2 LTS, 4.5 LTS, through 5.2.2+**.
* **Supported Platforms**: Windows, macOS (Intel & Apple Silicon), and Linux.
* **Zero Host Contamination**: All CAD dependencies (`cascadio`, `gmsh`, `rhino3dm`) install into a dedicated, isolated user folder (`id_renderflo_engine/<python_ver>`). Blender's internal Python packages are never touched or modified.

---

## 📦 Installation Instructions

### Blender 4.2+ (Extension Package):
1. In Blender, go to **Edit > Preferences > Get Extensions**.
2. Click the top-right menu icon (down arrow) and select **Install from Disk...**
3. Select `ID_RenderFlo_v2.4.0.zip` and enable the extension.
4. Press **N** in any 3D Viewport to open the **ID RenderFlo** panel.

### Blender 3.6 LTS – 4.1 (Classic Add-on):
1. In Blender, go to **Edit > Preferences > Add-ons**.
2. Click **Install...** and select `ID_RenderFlo_v2.4.0.zip`.
3. Check the box to activate **ID RenderFlo**.
4. Press **N** in any 3D Viewport to access the studio manager.

