bl_info = {
    "name": "ID RenderFlo",
    "author": "Sahitya Kashyap (sahityakashyap.in)",
    "version": (2, 4, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar (N-Panel) > ID RenderFlo  &  File > Import > CAD (.step/.stp/.iges/.3dm)",
    "description": "Universal Industrial Design Studio & CAD Pipeline: Native Rhino .3dm & Isolated OpenCASCADE STEP/CAD Importer, Multi-Studio Cameras with Real-Time Auto-Save & Studio Lock, KeyShot-Style Procedural HDRI Dome & Interactive 2D Pin Editor, In-Panel CMF Cloner, and Non-Blocking GPU Batch Queue",
    "doc_url": "https://sahityakashyap.in",
    "tracker_url": "https://sahityakashyap.in",
    "category": "Render",
}

import bpy
import os
import sys
import site
import json
import math
import tempfile
import subprocess
import uuid
import pickle
import gpu
import blf
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from bpy_extras import view3d_utils
from bpy_extras.io_utils import ImportHelper

MASTER_LIGHT_COLL = "_RENDERFLO_LIGHTS_MASTER_"
MASTER_CAM_COLL = "_RENDERFLO_CAMERAS_"
TARGET_EMPTY_NAME = "RenderFlo_Product_Target"
GROUND_PLANE_NAME = "RenderFlo_Shadow_Floor"
BACKDROP_OBJ_NAME = "RenderFlo_Curved_Backdrop"
DOME_VISUALIZER_OBJ = "RenderFlo_HDRI_Dome_Visualizer"
DOME_PIN_PREFIX = "RenderFlo_DomePin_"

_IS_INTERNAL_UPDATE = False
_CAD_ENGINE_AVAILABLE = None

# ------------------------------------------------------------------------
# Adaptive Version-Safe Mesh Import Dispatcher (3.6 - 5.2.2+)
# ------------------------------------------------------------------------

def safe_import_stl(filepath):
    if hasattr(bpy.ops.wm, "stl_import"):
        bpy.ops.wm.stl_import(filepath=filepath)
    elif hasattr(bpy.ops.import_mesh, "stl"):
        bpy.ops.import_mesh.stl(filepath=filepath)

def safe_import_obj(filepath):
    if hasattr(bpy.ops.wm, "obj_import"):
        bpy.ops.wm.obj_import(filepath=filepath)
    elif hasattr(bpy.ops.import_scene, "obj"):
        bpy.ops.import_scene.obj(filepath=filepath)

def safe_import_ply(filepath):
    if hasattr(bpy.ops.wm, "ply_import"):
        bpy.ops.wm.ply_import(filepath=filepath)
    elif hasattr(bpy.ops.import_mesh, "ply"):
        bpy.ops.import_mesh.ply(filepath=filepath)

# ------------------------------------------------------------------------
# Universal Cross-Version CAD Kernel Bootstrapper
# ------------------------------------------------------------------------

def get_cad_env_dir():
    py_ver = f"py{sys.version_info.major}_{sys.version_info.minor}"
    return bpy.utils.user_resource('SCRIPTS', path=os.path.join("id_renderflo_engine", py_ver), create=True)

def is_cad_engine_ready(force_recheck=False):
    global _CAD_ENGINE_AVAILABLE
    if _CAD_ENGINE_AVAILABLE is not None and not force_recheck:
        return _CAD_ENGINE_AVAILABLE

    env_dir = get_cad_env_dir()
    search_dirs = [env_dir]
    try:
        us = site.getusersitepackages()
        if us and os.path.isdir(us):
            search_dirs.append(us)
    except Exception:
        pass

    for d in search_dirs:
        if (
            os.path.isdir(os.path.join(d, "cascadio")) or
            os.path.isdir(os.path.join(d, "gmsh")) or
            os.path.isfile(os.path.join(d, "gmsh.py")) or
            os.path.isdir(os.path.join(d, "rhino3dm"))
        ):
            _CAD_ENGINE_AVAILABLE = True
            return True

    _CAD_ENGINE_AVAILABLE = False
    return False

def bootstrap_cad_engine():
    py_exec = sys.executable
    target_dir = get_cad_env_dir()
    os.makedirs(target_dir, exist_ok=True)

    try:
        subprocess.call([py_exec, "-m", "ensurepip", "--user"])
    except Exception:
        pass

    for pkg in ("cascadio", "gmsh", "rhino3dm"):
        subprocess.run(
            [py_exec, "-m", "pip", "install", "--target", target_dir, "--upgrade", pkg],
            capture_output=True, text=True
        )

    return is_cad_engine_ready(force_recheck=True)

# ------------------------------------------------------------------------
# Isolated Process CAD Worker
# ------------------------------------------------------------------------

UNIVERSAL_WORKER_CODE = r"""
import sys
import os
import math

env_dir = sys.argv[1]
cad_filepath = sys.argv[2]
out_file = sys.argv[3]
lin_tol = float(sys.argv[4])
ang_rad = float(sys.argv[5])

if env_dir and os.path.isdir(env_dir) and env_dir not in sys.path:
    sys.path.insert(0, env_dir)

try:
    import site
    us = site.getusersitepackages()
    if us and os.path.isdir(us) and us not in sys.path:
        sys.path.insert(0, us)
except Exception:
    pass

ext = os.path.splitext(cad_filepath)[1].lower()

converted = False
if ext in {'.step', '.stp'} and out_file.endswith('.glb'):
    try:
        import cascadio
        cascadio.step_to_glb(cad_filepath, out_file, lin_tol, ang_rad)
        converted = True
    except Exception:
        converted = False

if not converted:
    import gmsh
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("RenderFlo_CAD")
        gmsh.model.occ.importShapes(cad_filepath)
        gmsh.model.occ.synchronize()
        ang_deg = math.degrees(ang_rad)
        gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", max(6, int(360.0 / max(ang_deg, 2.0))))
        gmsh.option.setNumber("Mesh.MeshSizeMax", max(lin_tol * 25.0, 0.5))
        gmsh.option.setNumber("Mesh.MeshSizeMin", max(lin_tol * 0.5, 0.005))
        gmsh.model.mesh.generate(2)
        gmsh.write(out_file)
    finally:
        gmsh.finalize()
"""

def execute_universal_cad_import(context, filepath, lin_tol, ang_rad):
    if not is_cad_engine_ready():
        success = bootstrap_cad_engine()
        if not success:
            raise RuntimeError("Could not initialize CAD kernel. Please check internet connection on initial setup.")

    base_name = os.path.splitext(os.path.basename(filepath))[0]
    ext = os.path.splitext(filepath)[1].lower()
    tmp_dir = tempfile.gettempdir()
    worker_script = os.path.join(tmp_dir, "_renderflo_worker.py")
    out_glb = os.path.join(tmp_dir, f"_rf_{base_name}.glb")
    out_stl = os.path.join(tmp_dir, f"_rf_{base_name}.stl")

    with open(worker_script, "w", encoding="utf-8") as f:
        f.write(UNIVERSAL_WORKER_CODE)

    for p in (out_glb, out_stl):
        if os.path.exists(p):
            try:
                os.remove(p)
            except OSError:
                pass

    env_dir = get_cad_env_dir()
    target_out = out_glb if ext in {'.step', '.stp'} else out_stl

    res = subprocess.run(
        [sys.executable, worker_script, env_dir, filepath, target_out, str(lin_tol), str(ang_rad)],
        capture_output=True, text=True
    )

    if (res.returncode != 0 or not os.path.exists(target_out)) and target_out == out_glb:
        target_out = out_stl
        res = subprocess.run(
            [sys.executable, worker_script, env_dir, filepath, target_out, str(lin_tol), str(ang_rad)],
            capture_output=True, text=True
        )

    if res.returncode == 0 and os.path.exists(target_out):
        before = set(context.scene.objects)
        if target_out.endswith(".glb"):
            bpy.ops.import_scene.gltf(filepath=target_out)
        else:
            safe_import_stl(target_out)

        try:
            os.remove(target_out)
        except OSError:
            pass

        return [o for o in context.scene.objects if o not in before]

    err = (res.stderr or res.stdout or "Unknown conversion error").strip()
    raise RuntimeError(f"CAD Conversion failed: {err[-300:]}")

# ------------------------------------------------------------------------
# Isolated Rhino .3DM Worker & Importer
# ------------------------------------------------------------------------

def ensure_rhino3dm():
    env_dir = get_cad_env_dir()
    if env_dir and os.path.isdir(env_dir) and env_dir not in sys.path:
        sys.path.insert(0, env_dir)

    search_dirs = [env_dir]
    try:
        us = site.getusersitepackages()
        if us and os.path.isdir(us):
            search_dirs.append(us)
        deps_dir = bpy.utils.user_resource('SCRIPTS', path="id_renderflo_deps", create=False)
        if deps_dir and os.path.isdir(deps_dir):
            search_dirs.append(deps_dir)
    except Exception:
        pass

    for d in search_dirs:
        if os.path.isdir(os.path.join(d, "rhino3dm")):
            return True

    py_exec = sys.executable
    os.makedirs(env_dir, exist_ok=True)
    try:
        subprocess.call([py_exec, "-m", "ensurepip", "--user"])
    except Exception:
        pass

    res = subprocess.run(
        [py_exec, "-m", "pip", "install", "--target", env_dir, "--upgrade", "rhino3dm"],
        capture_output=True, text=True
    )
    return os.path.isdir(os.path.join(env_dir, "rhino3dm")) or res.returncode == 0

RHINO_WORKER_CODE = r"""
import sys
import os
import pickle

env_dir = sys.argv[1]
filepath = sys.argv[2]
out_pickle = sys.argv[3]

if env_dir and os.path.isdir(env_dir) and env_dir not in sys.path:
    sys.path.insert(0, env_dir)

try:
    import site
    us = site.getusersitepackages()
    if us and os.path.isdir(us) and us not in sys.path:
        sys.path.insert(0, us)
except Exception:
    pass

import rhino3dm

model = None
try:
    model = rhino3dm.File3dm.Read(filepath)
except Exception:
    pass

if not model:
    try:
        with open(filepath, "rb") as bf:
            model = rhino3dm.File3dm.FromByteArray(bf.read())
    except Exception:
        pass

if not model:
    base_file = os.path.basename(filepath)
    raise RuntimeError(
        f"Could not parse '{base_file}'. The file appears corrupted or unfinalized (common with Rhino 8 'Save As Rhino 7'). "
        "Please save natively in Rhino (File > Save) as .3dm or export as .STEP."
    )

unit_scale = 1.0
try:
    unit_sys = model.Settings.ModelUnitSystem
    unit_scale = rhino3dm.UnitSystem.UnitScale(unit_sys, rhino3dm.UnitSystem.Meters)
    if not unit_scale or unit_scale <= 0:
        unit_scale = 1.0
except Exception:
    unit_scale = 1.0

objects_data = []
breps_without_mesh = 0

for obj in model.Objects:
    attr = obj.Attributes
    if not attr or not attr.Visible:
        continue

    layer = None
    if 0 <= attr.LayerIndex < len(model.Layers):
        layer = model.Layers[attr.LayerIndex]

    if layer and not layer.Visible:
        continue

    layer_name = layer.Name if layer and layer.Name else "Default"
    col = layer.Color if layer else (180, 180, 180, 255)
    color_rgba = (col[0] / 255.0, col[1] / 255.0, col[2] / 255.0, 1.0)

    geom = obj.Geometry
    if not geom:
        continue

    rhino_meshes = []
    geom_type = geom.ObjectType

    if geom_type == rhino3dm.ObjectType.Mesh:
        rhino_meshes.append(geom)
    elif geom_type == rhino3dm.ObjectType.Brep:
        for f in geom.Faces:
            try:
                m = f.GetMesh(rhino3dm.MeshType.Any)
                if m and len(m.Vertices) > 0:
                    rhino_meshes.append(m)
            except Exception:
                pass
        if not rhino_meshes:
            breps_without_mesh += 1
    elif geom_type == rhino3dm.ObjectType.Extrusion:
        try:
            m = geom.GetMesh(rhino3dm.MeshType.Any)
            if m and len(m.Vertices) > 0:
                rhino_meshes.append(m)
        except Exception:
            pass
    elif geom_type == rhino3dm.ObjectType.SubD:
        try:
            if hasattr(rhino3dm.Mesh, "CreateFromSubDControlNet"):
                m = rhino3dm.Mesh.CreateFromSubDControlNet(geom)
                if m and len(m.Vertices) > 0:
                    rhino_meshes.append(m)
        except Exception:
            pass

    if not rhino_meshes:
        continue

    all_verts = []
    all_faces = []
    all_normals = []
    has_valid_normals = True

    for rm in rhino_meshes:
        v_offset = len(all_verts)
        rm_verts = [(v.X, v.Y, v.Z) for v in rm.Vertices]
        all_verts.extend(rm_verts)

        for f in rm.Faces:
            if f[2] == f[3]:
                all_faces.append((f[0] + v_offset, f[1] + v_offset, f[2] + v_offset))
            else:
                all_faces.append((f[0] + v_offset, f[1] + v_offset, f[2] + v_offset, f[3] + v_offset))

        if len(rm.Normals) == len(rm.Vertices):
            all_normals.extend([(n.X, n.Y, n.Z) for n in rm.Normals])
        else:
            has_valid_normals = False

    if all_verts and all_faces:
        obj_name = attr.Name if attr.Name else f"{layer_name}_{len(objects_data) + 1}"
        objects_data.append({
            'name': obj_name,
            'layer_name': layer_name,
            'layer_color': color_rgba,
            'verts': all_verts,
            'faces': all_faces,
            'normals': all_normals if has_valid_normals and len(all_normals) == len(all_verts) else []
        })

payload = {
    'unit_scale': unit_scale,
    'objects': objects_data,
    'breps_without_mesh': breps_without_mesh
}

with open(out_pickle, 'wb') as f:
    pickle.dump(payload, f)
"""

def import_rhino_3dm(filepath, context):
    if not ensure_rhino3dm():
        raise RuntimeError("Could not initialize 'rhino3dm' dependency. Please verify internet connection.")

    env_dir = get_cad_env_dir()
    tmp_dir = tempfile.gettempdir()
    worker_script = os.path.join(tmp_dir, f"_rf_3dm_worker_{uuid.uuid4().hex[:8]}.py")
    out_pickle = os.path.join(tmp_dir, f"_rf_3dm_{uuid.uuid4().hex[:8]}.pkl")

    with open(worker_script, "w", encoding="utf-8") as f:
        f.write(RHINO_WORKER_CODE)

    res = subprocess.run(
        [sys.executable, worker_script, env_dir, filepath, out_pickle],
        capture_output=True, text=True
    )

    if res.returncode != 0 or not os.path.exists(out_pickle):
        raw_err = (res.stderr or res.stdout or "").strip()
        clean_msg = "Unknown .3dm parsing error"
        for line in reversed(raw_err.splitlines()):
            line = line.strip()
            if not line:
                continue
            if "RuntimeError:" in line:
                clean_msg = line.split("RuntimeError:", 1)[1].strip()
                break
            elif "Error:" in line or "Exception:" in line:
                clean_msg = line
                break
            elif clean_msg == "Unknown .3dm parsing error":
                clean_msg = line
        try:
            if os.path.exists(worker_script):
                os.remove(worker_script)
        except OSError:
            pass
        raise RuntimeError(clean_msg)

    with open(out_pickle, "rb") as f:
        data = pickle.load(f)

    for p in (worker_script, out_pickle):
        try:
            if os.path.exists(p):
                os.remove(p)
        except OSError:
            pass

    objects_data = data.get("objects", [])
    breps_without_mesh = data.get("breps_without_mesh", 0)
    unit_scale = data.get("unit_scale", 1.0)

    created_objects = []

    for part in objects_data:
        m_name = part.get("name", "Rhino_Part")
        mesh = bpy.data.meshes.new(name=m_name)
        mesh.from_pydata(part["verts"], [], part["faces"])
        mesh.update()

        for poly in mesh.polygons:
            poly.use_smooth = True

        normals = part.get("normals", [])
        if normals and len(normals) == len(part["verts"]):
            if hasattr(mesh, "use_auto_smooth"):
                mesh.use_auto_smooth = True
            try:
                mesh.normals_split_custom_set_from_vertices(normals)
            except Exception:
                pass

        # Layer-to-Material Mapping
        layer_name = part.get("layer_name", "Default")
        layer_color = part.get("layer_color", (0.8, 0.8, 0.8, 1.0))
        mat_name = f"Rhino_{layer_name}"
        mat = bpy.data.materials.get(mat_name)
        if not mat:
            mat = bpy.data.materials.new(name=mat_name)
            mat.use_nodes = True
            bsdf = next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
            if bsdf:
                if "Base Color" in bsdf.inputs:
                    bsdf.inputs["Base Color"].default_value = (layer_color[0], layer_color[1], layer_color[2], 1.0)
                if "Roughness" in bsdf.inputs:
                    bsdf.inputs["Roughness"].default_value = 0.35

        obj = bpy.data.objects.new(m_name, mesh)
        context.scene.collection.objects.link(obj)
        obj.data.materials.append(mat)
        created_objects.append(obj)

    return created_objects, breps_without_mesh, unit_scale

# ------------------------------------------------------------------------
# GPU Hardware & Quality Settings
# ------------------------------------------------------------------------

def configure_cycles_gpu(scene, force_gpu=True):
    scene.render.engine = 'CYCLES'
    if not hasattr(scene, "cycles"):
        return "Cycles not available"

    if not force_gpu:
        scene.cycles.device = 'CPU'
        return "CPU"

    scene.cycles.device = 'GPU'
    try:
        prefs = bpy.context.preferences
        cprefs = prefs.addons['cycles'].preferences
        preferred_backends = ['OPTIX', 'CUDA', 'HIP', 'METAL', 'ONEAPI']
        chosen_backend = None

        for backend in preferred_backends:
            try:
                cprefs.compute_device_type = backend
                cprefs.get_devices()
                gpu_devs = [d for d in cprefs.devices if d.type != 'CPU']
                if gpu_devs:
                    chosen_backend = backend
                    for d in cprefs.devices:
                        d.use = (d.type != 'CPU')
                    break
            except Exception:
                continue

        if chosen_backend:
            return f"GPU ({chosen_backend})"
    except Exception:
        pass

    return "GPU (Active)"

def apply_render_quality_settings(scene, samples):
    if hasattr(scene, "cycles"):
        scene.cycles.samples = samples
        scene.cycles.preview_samples = scene.rf_viewport_samples
        scene.cycles.use_adaptive_sampling = True
        scene.cycles.adaptive_threshold = scene.rf_noise_threshold
        scene.cycles.use_denoising = scene.rf_use_denoiser

# ------------------------------------------------------------------------
# Aspect Ratio & Studio Configurations
# ------------------------------------------------------------------------

ASPECT_PRESETS = [
    ('16_9', "16:9 (Widescreen)", "16:9 Landscape", 16, 9),
    ('1_1', "1:1 (Square)", "1:1 Square", 1, 1),
    ('4_5', "4:5 (Portrait)", "4:5 Portrait", 4, 5),
    ('9_16', "9:16 (Vertical)", "9:16 Vertical", 9, 16),
    ('4_3', "4:3 (Standard)", "4:3 Standard", 4, 3),
    ('3_2', "3:2 (Photography)", "3:2 Photo", 3, 2),
    ('21_9', "21:9 (Ultrawide)", "21:9 Cinematic", 21, 9),
    ('CUSTOM', "Custom Resolution", "Enter custom pixel dimensions", 0, 0),
]

def update_studio_aspect_ratio(self, context):
    global _IS_INTERNAL_UPDATE
    if _IS_INTERNAL_UPDATE:
        return
    _IS_INTERNAL_UPDATE = True
    try:
        if self.aspect_preset != 'CUSTOM':
            for code, _, _, w, h in ASPECT_PRESETS:
                if code == self.aspect_preset:
                    base = self.base_resolution
                    if w >= h:
                        self.res_x = base
                        self.res_y = int(round(base * (h / w)))
                    else:
                        self.res_y = base
                        self.res_x = int(round(base * (w / h)))
                    break

        if context and context.scene:
            scene = context.scene
            if 0 <= scene.rf_studio_index < len(scene.rf_studios):
                if scene.rf_studios[scene.rf_studio_index] == self and self.use_resolution:
                    scene.render.resolution_x = self.res_x
                    scene.render.resolution_y = self.res_y
                    scene.render.resolution_percentage = self.res_scale
                    if scene.camera and scene.camera.data:
                        scene.camera.data.sensor_fit = 'VERTICAL' if (self.res_y > self.res_x) else 'HORIZONTAL'
    finally:
        _IS_INTERNAL_UPDATE = False

def update_global_render_settings(self, context):
    if _IS_INTERNAL_UPDATE or not context or not context.scene:
        return
    scene = context.scene
    configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)
    apply_render_quality_settings(scene, scene.rf_render_samples)

# ------------------------------------------------------------------------
# Data Structures
# ------------------------------------------------------------------------

class RENDERFLO_PG_collection_state(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Collection Name")
    hide_viewport: bpy.props.BoolProperty(name="Hide Viewport")
    hide_render: bpy.props.BoolProperty(name="Hide Render")

class RENDERFLO_PG_material_slot(bpy.types.PropertyGroup):
    slot_index: bpy.props.IntProperty(name="Slot Index")
    material_name: bpy.props.StringProperty(name="Material Name")

class RENDERFLO_PG_object_materials(bpy.types.PropertyGroup):
    object_name: bpy.props.StringProperty(name="Object Name")
    slots: bpy.props.CollectionProperty(type=RENDERFLO_PG_material_slot)

class RENDERFLO_PG_object_transform(bpy.types.PropertyGroup):
    object_name: bpy.props.StringProperty(name="Object Name")
    location: bpy.props.FloatVectorProperty(size=3)
    rotation_euler: bpy.props.FloatVectorProperty(size=3)
    scale: bpy.props.FloatVectorProperty(size=3, default=(1.0, 1.0, 1.0))

class RENDERFLO_PG_cmf_preset(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="CMF Name", default="CMF_01")
    object_materials: bpy.props.CollectionProperty(type=RENDERFLO_PG_object_materials)

class RENDERFLO_PG_studio_cmf_toggle(bpy.types.PropertyGroup):
    cmf_name: bpy.props.StringProperty(name="CMF Name")
    enabled: bpy.props.BoolProperty(name="Include in Matrix", default=True)

class RENDERFLO_PG_light_state(bpy.types.PropertyGroup):
    light_obj_name: bpy.props.StringProperty(name="Light Object")
    location: bpy.props.FloatVectorProperty(size=3)
    rotation_euler: bpy.props.FloatVectorProperty(size=3)
    scale: bpy.props.FloatVectorProperty(size=3, default=(1.0, 1.0, 1.0))
    energy: bpy.props.FloatProperty(default=100.0)
    color: bpy.props.FloatVectorProperty(size=3, subtype='COLOR', default=(1.0, 1.0, 1.0))
    size: bpy.props.FloatProperty(default=1.0)
    hide_viewport: bpy.props.BoolProperty(default=False)
    hide_render: bpy.props.BoolProperty(default=False)

def find_studio_for_pin(scene, pin):
    if not scene:
        return None
    for s in scene.rf_studios:
        for p in s.hdri_pins:
            if p == pin:
                return s
    if 0 <= scene.rf_studio_index < len(scene.rf_studios):
        return scene.rf_studios[scene.rf_studio_index]
    return None

def on_hdri_pin_update(self, context):
    global _IS_INTERNAL_UPDATE
    if _IS_INTERNAL_UPDATE or not context or not getattr(context, "scene", None):
        return
    scene = context.scene
    studio = find_studio_for_pin(scene, self)
    if studio:
        rebuild_studio_hdri_nodes(studio, scene, force=True)
        update_studio_dome_visualizer(studio, context)

def on_studio_hdri_update(self, context):
    global _IS_INTERNAL_UPDATE
    if _IS_INTERNAL_UPDATE or not context or not getattr(context, "scene", None):
        return
    rebuild_studio_hdri_nodes(self, context.scene, force=True)
    update_studio_dome_visualizer(self, context)

def on_studio_viewport_dome_change(self, context):
    if _IS_INTERNAL_UPDATE or not context or not getattr(context, "scene", None):
        return
    scene = context.scene
    scene.render.film_transparent = False if self.viewport_show_dome else self.film_transparent
    if context.screen:
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D' and hasattr(space, "shading"):
                        if self.viewport_show_dome:
                            space.shading.use_scene_world = True
                            space.shading.use_scene_lights = True
                area.tag_redraw()

def on_studio_dome_visualizer_change(self, context):
    if _IS_INTERNAL_UPDATE or not context or not getattr(context, "scene", None):
        return
    update_studio_dome_visualizer(self, context)

class RENDERFLO_PG_hdri_pin(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Pin Name", default="Pin_01")
    enabled: bpy.props.BoolProperty(name="Enabled", default=True, update=on_hdri_pin_update)
    pin_shape: bpy.props.EnumProperty(
        name="Shape",
        items=[
            ('CIRCLE', "Round Pin", "Circular radial highlight pin"),
            ('RECT', "Softbox Strip", "Rectangular directional softbox strip"),
        ],
        default='CIRCLE',
        update=on_hdri_pin_update
    )
    azimuth: bpy.props.FloatProperty(
        name="Azimuth",
        description="Horizontal angle in degrees",
        default=45.0,
        min=-180.0,
        max=180.0,
        update=on_hdri_pin_update
    )
    elevation: bpy.props.FloatProperty(
        name="Elevation",
        description="Vertical angle in degrees",
        default=35.0,
        min=-90.0,
        max=90.0,
        update=on_hdri_pin_update
    )
    radius: bpy.props.FloatProperty(
        name="Size",
        description="Angular size of the pin (small values create sharp pinpoint highlights)",
        default=0.08,
        min=0.0005,
        max=1.5,
        precision=4,
        step=0.1,
        update=on_hdri_pin_update
    )
    aspect: bpy.props.FloatProperty(
        name="Aspect Ratio",
        description="Width-to-height ratio when pin_shape is RECT",
        default=2.0,
        min=0.05,
        max=20.0,
        precision=2,
        update=on_hdri_pin_update
    )
    rotation: bpy.props.FloatProperty(
        name="Tilt",
        description="2D tilt angle in degrees for rectangular softbox pin",
        default=0.0,
        min=-180.0,
        max=180.0,
        update=on_hdri_pin_update
    )
    falloff: bpy.props.FloatProperty(
        name="Glow / Falloff",
        description="Edge softness / glow feathering (lower for crisp glints, higher for soft wrap)",
        default=0.04,
        min=0.0001,
        max=1.0,
        precision=4,
        step=0.1,
        update=on_hdri_pin_update
    )
    energy: bpy.props.FloatProperty(
        name="Energy",
        description="Intensity / brightness",
        default=15.0,
        min=0.0,
        max=500.0,
        update=on_hdri_pin_update
    )
    color: bpy.props.FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        update=on_hdri_pin_update
    )

def get_cmf_enum_items(self, context):
    items = [('NONE', "-- Keep Current Materials --", "Do not override materials")]
    if context and getattr(context, "scene", None):
        for cmf in context.scene.rf_cmf_presets:
            items.append((cmf.name, f"CMF: {cmf.name}", f"Apply colorway '{cmf.name}'"))
    items.append(('CUSTOM', "Unique Studio CMF", "Store materials only for this Studio"))
    return items

def sync_studio_cmf_toggles(scene, studio):
    existing_map = {t.cmf_name: t.enabled for t in studio.cmf_matrix_toggles}
    studio.cmf_matrix_toggles.clear()
    for cmf in scene.rf_cmf_presets:
        t = studio.cmf_matrix_toggles.add()
        t.cmf_name = cmf.name
        t.enabled = existing_map.get(cmf.name, True)

def on_studio_camera_change(self, context):
    if _IS_INTERNAL_UPDATE or not context or not context.scene:
        return
    if self.camera_obj and self.camera_obj.type == 'CAMERA':
        context.scene.camera = self.camera_obj

def on_studio_cmf_change(self, context):
    if _IS_INTERNAL_UPDATE or not context or not context.scene:
        return
    sync_studio_cmf_toggles(context.scene, self)
    apply_cmf_to_scene(context.scene, self)

def on_studio_use_materials_change(self, context):
    if _IS_INTERNAL_UPDATE or not context or not context.scene:
        return
    sync_studio_cmf_toggles(context.scene, self)
    if self.use_materials:
        apply_cmf_to_scene(context.scene, self)

def on_studio_image_style_change(self, context):
    if _IS_INTERNAL_UPDATE or not context or not context.scene:
        return
    if self.use_image_style:
        apply_image_style_to_scene(context.scene, self)

def on_studio_lock_change(self, context):
    if not context or not context.scene:
        return
    if self.camera_obj:
        for i in range(3):
            self.camera_obj.lock_location[i] = self.is_locked
            self.camera_obj.lock_rotation[i] = self.is_locked
            self.camera_obj.lock_scale[i] = self.is_locked

    if self.light_collection_name:
        coll = bpy.data.collections.get(self.light_collection_name)
        if coll:
            for obj in coll.objects:
                if obj.type == 'LIGHT':
                    for i in range(3):
                        obj.lock_location[i] = self.is_locked
                        obj.lock_rotation[i] = self.is_locked
                        obj.lock_scale[i] = self.is_locked

class RENDERFLO_PG_studio_item(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Studio Name", default="New Studio")
    render_enabled: bpy.props.BoolProperty(name="Include in Batch", default=True)
    is_locked: bpy.props.BoolProperty(
        name="Lock Studio",
        description="Freeze camera & lighting transforms and prevent auto-save overwrites",
        default=False,
        update=on_studio_lock_change
    )

    camera_obj: bpy.props.PointerProperty(
        name="Camera",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'CAMERA',
        update=on_studio_camera_change
    )

    aspect_preset: bpy.props.EnumProperty(
        name="Aspect Ratio",
        items=[(c, n, d) for c, n, d, _, _ in ASPECT_PRESETS],
        default='16_9',
        update=update_studio_aspect_ratio
    )
    base_resolution: bpy.props.IntProperty(name="Long Edge (px)", default=1920, min=128, max=16384, update=update_studio_aspect_ratio)
    res_x: bpy.props.IntProperty(name="Width (X)", default=1920, min=64, max=16384, update=update_studio_aspect_ratio)
    res_y: bpy.props.IntProperty(name="Height (Y)", default=1080, min=64, max=16384, update=update_studio_aspect_ratio)
    res_scale: bpy.props.IntProperty(name="Resolution %", default=100, min=10, max=400, subtype='PERCENTAGE', update=update_studio_aspect_ratio)

    use_custom_samples: bpy.props.BoolProperty(
        name="Custom Samples for Studio",
        description="Override global samples specifically for this Studio",
        default=False
    )
    studio_samples: bpy.props.IntProperty(name="Studio Samples", default=256, min=1, max=65536)

    light_collection_name: bpy.props.StringProperty(name="Studio Light Collection")
    world_name: bpy.props.StringProperty(name="World")

    # Procedural HDRI Dome & Interactive Pin Properties
    use_hdri_dome: bpy.props.BoolProperty(
        name="Use Procedural HDRI Dome",
        description="Generate procedural HDRI studio dome with interactive highlight pins",
        default=True,
        update=on_studio_hdri_update
    )
    use_custom_hdri: bpy.props.BoolProperty(
        name="Use HDRI Map",
        description="Use an external HDRI or EXR environment image as background",
        default=False,
        update=on_studio_hdri_update
    )
    hdri_image: bpy.props.PointerProperty(
        name="HDRI Map",
        type=bpy.types.Image,
        description="External HDRI or EXR environment image",
        update=on_studio_hdri_update
    )
    hdri_image_strength: bpy.props.FloatProperty(
        name="HDRI Intensity",
        description="Brightness intensity multiplier for the external HDRI map",
        default=1.0,
        min=0.0,
        max=50.0,
        update=on_studio_hdri_update
    )
    hdri_base_color: bpy.props.FloatVectorProperty(
        name="Base Color",
        description="Ambient background tint of the HDRI dome",
        subtype='COLOR',
        size=3,
        default=(0.05, 0.05, 0.06),
        min=0.0,
        max=1.0,
        update=on_studio_hdri_update
    )
    hdri_base_energy: bpy.props.FloatProperty(
        name="Base Energy",
        description="Background ambient brightness",
        default=0.5,
        min=0.0,
        max=50.0,
        update=on_studio_hdri_update
    )
    hdri_rotation: bpy.props.FloatProperty(
        name="HDRI Rotation",
        description="Global dome Z-rotation in degrees",
        default=0.0,
        min=-180.0,
        max=180.0,
        update=on_studio_hdri_update
    )
    hdri_glow_size: bpy.props.FloatProperty(
        name="HDRI Glow (Distance Scale)",
        description="Scale the size of the HDRI glow and pin highlights to simulate lights closer or farther based on product size",
        default=1.0,
        min=0.01,
        max=10.0,
        precision=3,
        step=0.1,
        update=on_studio_hdri_update
    )
    hdri_pins: bpy.props.CollectionProperty(type=RENDERFLO_PG_hdri_pin)
    viewport_show_dome: bpy.props.BoolProperty(
        name="Show Dome in Viewport",
        description="Show procedural HDRI dome in 3D Viewport background (temporarily disables transparent film during interactive design)",
        default=True,
        update=on_studio_viewport_dome_change
    )
    hdri_preview_image: bpy.props.PointerProperty(type=bpy.types.Image)

    cmf_mode: bpy.props.EnumProperty(name="CMF Variation", items=get_cmf_enum_items, update=on_studio_cmf_change)

    exposure: bpy.props.FloatProperty(name="Exposure", default=0.0, min=-10.0, max=10.0, update=on_studio_image_style_change)
    contrast: bpy.props.EnumProperty(
        name="Contrast",
        description="Color management look / contrast tone curve",
        items=[
            ('None', "None", "Default standard contrast"),
            ('Very Low Contrast', "Very Low", "Very Low Contrast"),
            ('Low Contrast', "Low", "Low Contrast"),
            ('Medium Low Contrast', "Med-Low", "Medium Low Contrast"),
            ('Medium Contrast', "Medium", "Medium Contrast"),
            ('Medium High Contrast', "Med-High", "Medium High Contrast"),
            ('High Contrast', "High", "High Contrast"),
            ('Very High Contrast', "Very High", "Very High Contrast"),
        ],
        default='None',
        update=on_studio_image_style_change
    )
    film_transparent: bpy.props.BoolProperty(name="Transparent PNG", default=True, update=on_studio_image_style_change)

    use_camera: bpy.props.BoolProperty(name="Camera", default=True)
    use_resolution: bpy.props.BoolProperty(name="Aspect Ratio & Res", default=True)
    use_lights: bpy.props.BoolProperty(name="Lights & HDRI", default=True)
    lighting_tab: bpy.props.EnumProperty(
        name="Lighting Module",
        description="Switch between KeyShot-style HDRI Dome & Pins and Physical Lamps",
        items=[
            ('HDRI', "HDRI Dome & Pins", "KeyShot-style procedural HDRI dome and highlight pins", 'WORLD', 0),
            ('LIGHTS', "Physical Lights", "Key, Rim, and Fill studio lamps", 'LIGHT_SUN', 1),
        ],
        default='HDRI'
    )
    use_materials: bpy.props.BoolProperty(name="CMF (Materials)", default=True, update=on_studio_use_materials_change)
    use_collections: bpy.props.BoolProperty(name="Model Sets", default=True)
    use_transforms: bpy.props.BoolProperty(name="Exploded / Part Positions", default=False)
    use_image_style: bpy.props.BoolProperty(name="Image Style", default=True)

    cmf_matrix_toggles: bpy.props.CollectionProperty(type=RENDERFLO_PG_studio_cmf_toggle)
    collection_states: bpy.props.CollectionProperty(type=RENDERFLO_PG_collection_state)
    object_materials: bpy.props.CollectionProperty(type=RENDERFLO_PG_object_materials)
    object_transforms: bpy.props.CollectionProperty(type=RENDERFLO_PG_object_transform)
    light_states: bpy.props.CollectionProperty(type=RENDERFLO_PG_light_state)

def on_active_studio_index_change(self, context):
    if _IS_INTERNAL_UPDATE or not context or not context.scene:
        return
    scene = context.scene
    if 0 <= scene.rf_studio_index < len(scene.rf_studios):
        sync_studio_cmf_toggles(scene, scene.rf_studios[scene.rf_studio_index])

# ------------------------------------------------------------------------
# Material & CAD Import Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_sync_cmf_matrix(bpy.types.Operator):
    bl_idname = "renderflo.sync_cmf_matrix"
    bl_label = "Sync Colorway Matrix List"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        for s in scene.rf_studios:
            sync_studio_cmf_toggles(scene, s)
        return {'FINISHED'}

class RENDERFLO_OT_clone_active_material(bpy.types.Operator):
    bl_idname = "renderflo.clone_active_material"
    bl_label = "Clone Slot Material as New"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.active_material:
            self.report({'WARNING'}, "Select an object with an active material slot first.")
            return {'CANCELLED'}

        orig_mat = obj.active_material
        new_mat = orig_mat.copy()
        new_mat.name = f"{orig_mat.name}_Var"
        obj.active_material = new_mat
        self.report({'INFO'}, f"Cloned material to '{new_mat.name}' on {obj.name}")
        return {'FINISHED'}

class RENDERFLO_OT_bootstrap_cad_kernel(bpy.types.Operator):
    bl_idname = "renderflo.bootstrap_cad_kernel"
    bl_label = "Verify & Download CAD Engine"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if bootstrap_cad_engine():
            for area in context.screen.areas:
                area.tag_redraw()
            self.report({'INFO'}, "ID RenderFlo: CAD Kernel successfully initialized!")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Failed to initialize CAD engine. Check internet connection for initial setup.")
            return {'CANCELLED'}

class RENDERFLO_OT_import_cad(bpy.types.Operator, ImportHelper):
    bl_idname = "renderflo.import_cad"
    bl_label = "Import CAD (ID RenderFlo)"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".step"
    filter_glob: bpy.props.StringProperty(
        default="*.step;*.stp;*.iges;*.igs;*.stl;*.3dm;*.obj;*.fbx;*.glb;*.gltf;*.ply",
        options={'HIDDEN'},
        maxlen=255,
    )

    tess_preset: bpy.props.EnumProperty(
        name="Tessellation Quality",
        items=[
            ('ULTRA', "Ultra Fine (0.02mm)", "Highest accuracy for macro product shots"),
            ('HIGH', "High Quality (0.08mm)", "Balanced smooth fillets and polycount"),
            ('MEDIUM', "Medium (0.25mm)", "Optimized performance for large assemblies"),
            ('CUSTOM', "Custom Tolerances", "Manually specify linear and angular deflection"),
        ],
        default='HIGH'
    )
    linear_deflection: bpy.props.FloatProperty(name="Linear Deflection (mm)", default=0.08, min=0.001, max=10.0)
    angular_deflection: bpy.props.FloatProperty(name="Angular Deflection (deg)", default=15.0, min=1.0, max=90.0)
    up_axis: bpy.props.EnumProperty(
        name="CAD Up-Axis",
        items=[
            ('Y_UP', "Y-Up (CAD Default)", "Rotate +90 deg on X to match Z-Up"),
            ('Z_UP', "Z-Up (Rhino / Fusion / Blender)", "Keep Z as Up-Axis"),
        ],
        default='Y_UP'
    )
    unit_scale: bpy.props.EnumProperty(
        name="CAD Units",
        items=[
            ('MM_TO_M', "Millimeters -> Meters (0.001x)", "Scales metric CAD millimetres to Blender meters"),
            ('KEEP', "Keep Native Units (1.0x)", "Do not apply unit scale"),
            ('CM_TO_M', "Centimeters -> Meters (0.01x)", "Scale by 0.01"),
            ('INCH_TO_M', "Inches -> Meters (0.0254x)", "Scale by 0.0254"),
        ],
        default='MM_TO_M'
    )
    center_xy: bpy.props.BoolProperty(name="Center Product on X/Y Origin", default=True)
    snap_to_ground: bpy.props.BoolProperty(name="Snap Base to Floor (Z = 0)", default=True)
    auto_smooth_normals: bpy.props.BoolProperty(name="Weighted Normals (Clean Fillets)", default=True)

    def draw(self, context):
        layout = self.layout
        ready = is_cad_engine_ready()

        box = layout.box()
        box.label(text="CAD Engine Ready" if ready else "CAD Engine will setup automatically on Import", icon='CHECKMARK' if ready else 'INFO')
        box.prop(self, "tess_preset", text="Quality")
        if self.tess_preset == 'CUSTOM':
            col = box.column(align=True)
            col.prop(self, "linear_deflection")
            col.prop(self, "angular_deflection")

        box2 = layout.box()
        box2.label(text="Orientation & Units", icon='ORIENTATION_GLOBAL')
        box2.prop(self, "up_axis")
        box2.prop(self, "unit_scale")

        box3 = layout.box()
        box3.label(text="Auto-Prep Alignment", icon='MOD_REMESH')
        box3.prop(self, "center_xy")
        box3.prop(self, "snap_to_ground")
        box3.prop(self, "auto_smooth_normals")

    def execute(self, context):
        filepath = self.filepath
        ext = os.path.splitext(filepath)[1].lower()
        base_name = os.path.splitext(os.path.basename(filepath))[0]

        if self.tess_preset == 'ULTRA':
            lin_tol, ang_tol = 0.02, 10.0
        elif self.tess_preset == 'HIGH':
            lin_tol, ang_tol = 0.08, 15.0
        elif self.tess_preset == 'MEDIUM':
            lin_tol, ang_tol = 0.25, 25.0
        else:
            lin_tol, ang_tol = self.linear_deflection, self.angular_deflection

        ang_rad = math.radians(ang_tol)
        before_objs = set(context.scene.objects)
        warn_breps = 0
        detected_scale = 1.0

        if ext in {'.step', '.stp', '.iges', '.igs'}:
            try:
                execute_universal_cad_import(context, filepath, lin_tol, ang_rad)
            except Exception as e:
                self.report({'ERROR'}, str(e))
                return {'CANCELLED'}
        elif ext == '.3dm':
            try:
                rhino_objs, warn_breps, detected_scale = import_rhino_3dm(filepath, context)
            except Exception as e:
                self.report({'ERROR'}, str(e))
                return {'CANCELLED'}
        elif ext == '.stl':
            safe_import_stl(filepath)
        elif ext == '.obj':
            safe_import_obj(filepath)
        elif ext == '.fbx':
            bpy.ops.import_scene.fbx(filepath=filepath)
        elif ext in {'.glb', '.gltf'}:
            bpy.ops.import_scene.gltf(filepath=filepath)
        elif ext == '.ply':
            safe_import_ply(filepath)
        else:
            self.report({'ERROR'}, f"Unsupported format: {ext}")
            return {'CANCELLED'}

        new_objs = [obj for obj in context.scene.objects if obj not in before_objs]
        if not new_objs:
            if ext == '.3dm' and warn_breps > 0:
                self.report({'WARNING'}, "No render meshes found in .3dm (saved in Wireframe/Save Small mode). Please save in Shaded mode in Rhino or export as .STEP.")
            else:
                self.report({'WARNING'}, "No geometry found in CAD file.")
            return {'CANCELLED'}

        cad_coll = bpy.data.collections.new(f"CAD_{base_name}")
        context.scene.collection.children.link(cad_coll)
        for obj in new_objs:
            for c in list(obj.users_collection):
                c.objects.unlink(obj)
            cad_coll.objects.link(obj)

        root_objs = [obj for obj in new_objs if obj.parent not in new_objs]
        assembly_root = bpy.data.objects.new(f"Assembly_{base_name}", None)
        assembly_root.empty_display_type = 'ARROWS'
        assembly_root.empty_display_size = 0.2
        cad_coll.objects.link(assembly_root)

        for r_obj in root_objs:
            r_obj.parent = assembly_root

        if self.up_axis == 'Y_UP' and ext not in {'.glb', '.gltf', '.3dm'}:
            assembly_root.rotation_euler.x += math.radians(90.0)

        scale_map = {'MM_TO_M': 0.001, 'CM_TO_M': 0.01, 'INCH_TO_M': 0.0254, 'KEEP': 1.0}
        scale_factor = scale_map.get(self.unit_scale, 1.0)
        if ext == '.3dm' and self.unit_scale == 'MM_TO_M' and detected_scale and detected_scale > 0:
            scale_factor = detected_scale
        if scale_factor != 1.0:
            assembly_root.scale *= scale_factor

        context.view_layer.update()

        mesh_objs = [obj for obj in new_objs if obj.type == 'MESH']
        if self.auto_smooth_normals:
            for m_obj in mesh_objs:
                for poly in m_obj.data.polygons:
                    poly.use_smooth = True
                if not m_obj.data.has_custom_normals:
                    wn = m_obj.modifiers.new(name="RenderFlo_WeightedNormal", type='WEIGHTED_NORMAL')
                    wn.keep_sharp = True

        if mesh_objs and (self.center_xy or self.snap_to_ground):
            depsgraph = context.evaluated_depsgraph_get()
            min_x = min_y = min_z = float('inf')
            max_x = max_y = max_z = float('-inf')

            for m_obj in mesh_objs:
                eval_obj = m_obj.evaluated_get(depsgraph)
                for corner in eval_obj.bound_box:
                    world_pt = eval_obj.matrix_world @ Vector(corner)
                    min_x, max_x = min(min_x, world_pt.x), max(max_x, world_pt.x)
                    min_y, max_y = min(min_y, world_pt.y), max(max_y, world_pt.y)
                    min_z, max_z = min(min_z, world_pt.z), max(max_z, world_pt.z)

            offset = Vector((0.0, 0.0, 0.0))
            if self.center_xy:
                offset.x = -((min_x + max_x) * 0.5)
                offset.y = -((min_y + max_y) * 0.5)
            if self.snap_to_ground:
                offset.z = -min_z

            assembly_root.location += offset
            context.view_layer.update()

            target = ensure_light_target(context)
            target.location = Vector((0.0, 0.0, (max_z - min_z) * 0.5 if self.snap_to_ground else (min_z + max_z) * 0.5))

        if ext == '.3dm' and warn_breps > 0:
            self.report({'WARNING'}, f"Imported '{base_name}', but {warn_breps} parts had no cached render meshes (Wireframe/Save Small mode). Save in Shaded mode in Rhino or export as .STEP.")
        else:
            self.report({'INFO'}, f"ID RenderFlo: Imported '{base_name}' ({len(mesh_objs)} parts) into Model Set '{cad_coll.name}'")
        return {'FINISHED'}

# ------------------------------------------------------------------------
# Studio Manager Helpers & Ground Plane / Backdrop
# ------------------------------------------------------------------------

def ensure_collection(scene, coll_name):
    coll = bpy.data.collections.get(coll_name)
    if not coll:
        coll = bpy.data.collections.new(coll_name)
        scene.collection.children.link(coll)
    elif coll.name not in scene.collection.children:
        try:
            scene.collection.children.link(coll)
        except Exception:
            pass
    return coll

def ensure_studio_light_collection(context, studio):
    master_coll = ensure_collection(context.scene, MASTER_LIGHT_COLL)
    if studio.light_collection_name:
        sub_coll = bpy.data.collections.get(studio.light_collection_name)
        if sub_coll:
            return sub_coll

    coll_name = f"Lights_{studio.name}"
    sub_coll = bpy.data.collections.get(coll_name)
    if not sub_coll:
        sub_coll = bpy.data.collections.new(coll_name)
    if sub_coll.name not in master_coll.children:
        try:
            master_coll.children.link(sub_coll)
        except Exception:
            pass
    studio.light_collection_name = sub_coll.name
    return sub_coll

def create_camera_for_studio(context, studio_name, match_viewport=True):
    scene = context.scene
    cam_coll = ensure_collection(scene, MASTER_CAM_COLL)

    cam_data = bpy.data.cameras.new(name=f"Cam_{studio_name}")
    cam_data.lens = 85.0
    cam_data.passepartout_alpha = 0.85

    cam_obj = bpy.data.objects.new(name=f"Cam_{studio_name}", object_data=cam_data)
    cam_coll.objects.link(cam_obj)

    placed = False
    if scene.camera and not match_viewport:
        cam_obj.matrix_world = scene.camera.matrix_world.copy()
        if scene.camera.data and hasattr(scene.camera.data, "lens"):
            cam_data.lens = scene.camera.data.lens
        placed = True

    if not placed and context.screen:
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D' and space.region_3d:
                        cam_obj.matrix_world = space.region_3d.view_matrix.inverted()
                        placed = True
                        break
                if placed:
                    break

    if not placed:
        cam_obj.location = (0.0, -3.5, 1.5)
        cam_obj.rotation_euler = (math.radians(70.0), 0.0, 0.0)

    scene.camera = cam_obj
    return cam_obj

def ensure_light_target(context):
    target = bpy.data.objects.get(TARGET_EMPTY_NAME)
    if not target:
        target = bpy.data.objects.new(TARGET_EMPTY_NAME, None)
        target.empty_display_type = 'SPHERE'
        target.empty_display_size = 0.25
        target.location = (0.0, 0.0, 0.0)
        master_coll = ensure_collection(context.scene, MASTER_LIGHT_COLL)
        master_coll.objects.link(target)
    return target

def switch_exclusive_studio_lights(context, active_studio):
    scene = context.scene
    active_coll_name = active_studio.light_collection_name
    for s in scene.rf_studios:
        if s.light_collection_name:
            coll = bpy.data.collections.get(s.light_collection_name)
            if coll:
                is_current = (coll.name == active_coll_name)
                coll.hide_viewport = not is_current
                coll.hide_render = not is_current

def record_materials_into_collection(scene, mat_collection_prop):
    mat_collection_prop.clear()
    for obj in list(scene.objects):
        if obj.name in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
            continue
        if obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT'} and len(obj.material_slots) > 0:
            obj_item = mat_collection_prop.add()
            obj_item.object_name = obj.name
            for idx, slot in enumerate(obj.material_slots):
                slot_item = obj_item.slots.add()
                slot_item.slot_index = idx
                slot_item.material_name = slot.material.name if slot.material else ""

def restore_materials_from_collection(mat_collection_prop):
    for obj_item in mat_collection_prop:
        obj = bpy.data.objects.get(obj_item.object_name)
        if obj:
            for slot_item in obj_item.slots:
                if slot_item.slot_index < len(obj.material_slots):
                    mat = bpy.data.materials.get(slot_item.material_name) if slot_item.material_name else None
                    obj.material_slots[slot_item.slot_index].material = mat

def apply_cmf_to_scene(scene, studio):
    if not studio.use_materials or studio.cmf_mode == 'NONE':
        return
    if studio.cmf_mode == 'CUSTOM':
        restore_materials_from_collection(studio.object_materials)
    else:
        cmf = next((c for c in scene.rf_cmf_presets if c.name == studio.cmf_mode), None)
        if cmf:
            restore_materials_from_collection(cmf.object_materials)

def apply_image_style_to_scene(scene, studio):
    scene.view_settings.exposure = studio.exposure
    if hasattr(studio, "contrast") and hasattr(scene.view_settings, "look"):
        try:
            scene.view_settings.look = studio.contrast
        except Exception:
            pass
    scene.render.film_transparent = studio.film_transparent

def rebuild_studio_hdri_nodes(studio, scene=None, force=False):
    global _IS_INTERNAL_UPDATE
    if _IS_INTERNAL_UPDATE and not force:
        return

    world_name = studio.world_name or f"World_{bpy.path.clean_name(studio.name)}"
    world = bpy.data.worlds.get(world_name)
    if not world:
        world = bpy.data.worlds.new(world_name)
    studio.world_name = world.name

    if scene:
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            if scene.rf_studios[scene.rf_studio_index] == studio:
                if scene.world != world:
                    scene.world = world

    if studio.is_locked and not force:
        return

    world.use_nodes = True
    nt = world.node_tree
    nt.nodes.clear()

    if not studio.use_hdri_dome:
        bg = nt.nodes.new("ShaderNodeBackground")
        bg.location = (0, 0)
        bg.inputs["Color"].default_value = (
            studio.hdri_base_color[0],
            studio.hdri_base_color[1],
            studio.hdri_base_color[2],
            1.0,
        )
        bg.inputs["Strength"].default_value = studio.hdri_base_energy
        out = nt.nodes.new("ShaderNodeOutputWorld")
        out.location = (300, 0)
        nt.links.new(bg.outputs["Background"], out.inputs["Surface"])
        return

    # 1. TexCoord -> Normalize to get unit direction vector D
    tc = nt.nodes.new("ShaderNodeTexCoord")
    tc.location = (-1200, 0)

    norm = nt.nodes.new("ShaderNodeVectorMath")
    norm.operation = "NORMALIZE"
    norm.location = (-1000, 0)
    nt.links.new(tc.outputs["Generated"], norm.inputs[0])

    # 2. Base background: Custom HDRI environment texture OR procedural ambient color * energy
    if getattr(studio, "use_custom_hdri", False) and studio.hdri_image:
        mapping = nt.nodes.new("ShaderNodeMapping")
        mapping.location = (-1000, 250)
        mapping.vector_type = 'TEXTURE'
        mapping.inputs["Rotation"].default_value = (0, 0, math.radians(studio.hdri_rotation))
        nt.links.new(tc.outputs["Generated"], mapping.inputs["Vector"])

        env_tex = nt.nodes.new("ShaderNodeTexEnvironment")
        env_tex.location = (-800, 250)
        env_tex.image = studio.hdri_image
        nt.links.new(mapping.outputs["Vector"], env_tex.inputs["Vector"])

        scale_env = nt.nodes.new("ShaderNodeVectorMath")
        scale_env.operation = "SCALE"
        scale_env.location = (-600, 250)
        scale_env.inputs["Scale"].default_value = max(0.0, getattr(studio, "hdri_image_strength", 1.0))
        nt.links.new(env_tex.outputs["Color"], scale_env.inputs["Vector"])

        curr_accum_socket = scale_env.outputs["Vector"]
    else:
        base_node = nt.nodes.new("ShaderNodeCombineXYZ")
        base_node.location = (-800, 200)
        base_node.inputs[0].default_value = studio.hdri_base_color[0] * studio.hdri_base_energy
        base_node.inputs[1].default_value = studio.hdri_base_color[1] * studio.hdri_base_energy
        base_node.inputs[2].default_value = studio.hdri_base_color[2] * studio.hdri_base_energy
        curr_accum_socket = base_node.outputs["Vector"]

    # 3. Accumulate procedural pins
    x_offset = -600
    y_step = -250

    enabled_pins = [p for p in studio.hdri_pins if p.enabled]
    last_x = x_offset

    for idx, pin in enumerate(enabled_pins):
        theta = math.radians(pin.azimuth + studio.hdri_rotation)
        phi = math.radians(pin.elevation)
        cos_phi = math.cos(phi)
        sin_phi = math.sin(phi)
        cos_th = math.cos(theta)
        sin_th = math.sin(theta)

        px = cos_phi * cos_th
        py = cos_phi * sin_th
        pz = sin_phi
        p_vec = Vector((px, py, pz))

        pin_y = idx * y_step

        glow = max(0.01, getattr(studio, "hdri_glow_size", 1.0))

        if pin.pin_shape == 'CIRCLE':
            dot_node = nt.nodes.new("ShaderNodeVectorMath")
            dot_node.operation = "DOT_PRODUCT"
            dot_node.location = (x_offset, pin_y)
            dot_node.inputs[1].default_value = (px, py, pz)
            nt.links.new(norm.outputs["Vector"], dot_node.inputs[0])

            mr_node = nt.nodes.new("ShaderNodeMapRange")
            mr_node.interpolation_type = "SMOOTHSTEP"
            mr_node.clamp = True
            mr_node.location = (x_offset + 200, pin_y)
            nt.links.new(dot_node.outputs["Value"], mr_node.inputs["Value"])

            r_core = max(0.0005, pin.radius * glow)
            r_outer = min(math.pi * 0.999, r_core + max(0.0001, pin.falloff * glow))
            mr_node.inputs["From Min"].default_value = math.cos(r_outer)
            mr_node.inputs["From Max"].default_value = math.cos(r_core)
            mr_node.inputs["To Min"].default_value = 0.0
            mr_node.inputs["To Max"].default_value = 1.0

            mask_socket = mr_node.outputs["Result"]
            last_x = x_offset + 400

        else:  # 'RECT' Softbox Strip
            if abs(cos_phi) > 1e-4:
                u0 = Vector((-sin_th, cos_th, 0.0))
            else:
                u0 = Vector((1.0, 0.0, 0.0))
            v0 = p_vec.cross(u0).normalized()

            psi = math.radians(pin.rotation)
            cos_psi = math.cos(psi)
            sin_psi = math.sin(psi)
            u_vec = (cos_psi * u0 + sin_psi * v0).normalized()
            v_vec = (-sin_psi * u0 + cos_psi * v0).normalized()

            w = max(0.0005, pin.radius * glow * max(0.05, pin.aspect))
            h = max(0.0005, pin.radius * glow)
            f = max(0.0001, pin.falloff * glow)

            # U component
            dot_u = nt.nodes.new("ShaderNodeVectorMath")
            dot_u.operation = "DOT_PRODUCT"
            dot_u.location = (x_offset, pin_y + 80)
            dot_u.inputs[1].default_value = (u_vec.x, u_vec.y, u_vec.z)
            nt.links.new(norm.outputs["Vector"], dot_u.inputs[0])

            abs_u = nt.nodes.new("ShaderNodeMath")
            abs_u.operation = "ABSOLUTE"
            abs_u.location = (x_offset + 180, pin_y + 80)
            nt.links.new(dot_u.outputs["Value"], abs_u.inputs[0])

            mr_u = nt.nodes.new("ShaderNodeMapRange")
            mr_u.interpolation_type = "SMOOTHSTEP"
            mr_u.clamp = True
            mr_u.location = (x_offset + 340, pin_y + 80)
            nt.links.new(abs_u.outputs["Value"], mr_u.inputs["Value"])
            mr_u.inputs["From Min"].default_value = math.sin(min(math.pi * 0.49, w + f))
            mr_u.inputs["From Max"].default_value = math.sin(min(math.pi * 0.49, w))
            mr_u.inputs["To Min"].default_value = 0.0
            mr_u.inputs["To Max"].default_value = 1.0

            # V component
            dot_v = nt.nodes.new("ShaderNodeVectorMath")
            dot_v.operation = "DOT_PRODUCT"
            dot_v.location = (x_offset, pin_y - 80)
            dot_v.inputs[1].default_value = (v_vec.x, v_vec.y, v_vec.z)
            nt.links.new(norm.outputs["Vector"], dot_v.inputs[0])

            abs_v = nt.nodes.new("ShaderNodeMath")
            abs_v.operation = "ABSOLUTE"
            abs_v.location = (x_offset + 180, pin_y - 80)
            nt.links.new(dot_v.outputs["Value"], abs_v.inputs[0])

            mr_v = nt.nodes.new("ShaderNodeMapRange")
            mr_v.interpolation_type = "SMOOTHSTEP"
            mr_v.clamp = True
            mr_v.location = (x_offset + 340, pin_y - 80)
            nt.links.new(abs_v.outputs["Value"], mr_v.inputs["Value"])
            mr_v.inputs["From Min"].default_value = math.sin(min(math.pi * 0.49, h + f))
            mr_v.inputs["From Max"].default_value = math.sin(min(math.pi * 0.49, h))
            mr_v.inputs["To Min"].default_value = 0.0
            mr_v.inputs["To Max"].default_value = 1.0

            # Forward hemisphere mask
            dot_f = nt.nodes.new("ShaderNodeVectorMath")
            dot_f.operation = "DOT_PRODUCT"
            dot_f.location = (x_offset, pin_y - 200)
            dot_f.inputs[1].default_value = (px, py, pz)
            nt.links.new(norm.outputs["Vector"], dot_f.inputs[0])

            mr_f = nt.nodes.new("ShaderNodeMapRange")
            mr_f.interpolation_type = "LINEAR"
            mr_f.clamp = True
            mr_f.location = (x_offset + 180, pin_y - 200)
            nt.links.new(dot_f.outputs["Value"], mr_f.inputs["Value"])
            mr_f.inputs["From Min"].default_value = 0.0
            mr_f.inputs["From Max"].default_value = 0.02
            mr_f.inputs["To Min"].default_value = 0.0
            mr_f.inputs["To Max"].default_value = 1.0

            mul_uv = nt.nodes.new("ShaderNodeMath")
            mul_uv.operation = "MULTIPLY"
            mul_uv.location = (x_offset + 520, pin_y)
            nt.links.new(mr_u.outputs["Result"], mul_uv.inputs[0])
            nt.links.new(mr_v.outputs["Result"], mul_uv.inputs[1])

            mul_f = nt.nodes.new("ShaderNodeMath")
            mul_f.operation = "MULTIPLY"
            mul_f.location = (x_offset + 680, pin_y)
            nt.links.new(mul_uv.outputs["Value"], mul_f.inputs[0])
            nt.links.new(mr_f.outputs["Result"], mul_f.inputs[1])

            mask_socket = mul_f.outputs["Value"]
            last_x = x_offset + 840

        # Scale mask by pin.color * pin.energy
        scale_node = nt.nodes.new("ShaderNodeVectorMath")
        scale_node.operation = "SCALE"
        scale_node.location = (last_x, pin_y)
        scale_node.inputs["Vector"].default_value = (
            pin.color[0] * pin.energy,
            pin.color[1] * pin.energy,
            pin.color[2] * pin.energy,
        )
        nt.links.new(mask_socket, scale_node.inputs["Scale"])

        # Add to cumulative accumulation
        add_node = nt.nodes.new("ShaderNodeVectorMath")
        add_node.operation = "ADD"
        add_node.location = (last_x + 200, pin_y)
        nt.links.new(curr_accum_socket, add_node.inputs[0])
        nt.links.new(scale_node.outputs["Vector"], add_node.inputs[1])

        curr_accum_socket = add_node.outputs["Vector"]
        last_x += 400

    # 4. Final Background & OutputWorld
    final_x = max(200, last_x + 200)
    bg = nt.nodes.new("ShaderNodeBackground")
    bg.location = (final_x, 0)
    bg.inputs["Strength"].default_value = 1.0
    nt.links.new(curr_accum_socket, bg.inputs["Color"])

    out = nt.nodes.new("ShaderNodeOutputWorld")
    out.location = (final_x + 200, 0)
    nt.links.new(bg.outputs["Background"], out.inputs["Surface"])


def generate_hdri_equirectangular_preview(studio, width=256, height=128):
    if not getattr(studio, "use_hdri_dome", True):
        return None

    img_name = f"_RenderFlo_HDRI_Map_{bpy.path.clean_name(studio.name)}"
    img = bpy.data.images.get(img_name)
    if not img or img.size[0] != width or img.size[1] != height:
        if img:
            bpy.data.images.remove(img)
        img = bpy.data.images.new(img_name, width=width, height=height, float_buffer=False)
        img.use_fake_user = True

    try:
        import numpy as np

        xs = np.linspace(-math.pi, math.pi, width, endpoint=False)
        ys = np.linspace(-math.pi * 0.5, math.pi * 0.5, height, endpoint=False)
        X, Y = np.meshgrid(xs, ys)

        base_energy = max(0.0, studio.hdri_base_energy)
        base_r = studio.hdri_base_color[0] * base_energy
        base_g = studio.hdri_base_color[1] * base_energy
        base_b = studio.hdri_base_color[2] * base_energy

        sky_grad = np.clip((np.sin(Y) + 1.0) * 0.5, 0.25, 1.0)
        rgb = np.zeros((height, width, 3), dtype=np.float32)
        rgb[:, :, 0] = base_r * sky_grad
        rgb[:, :, 1] = base_g * sky_grad
        rgb[:, :, 2] = base_b * sky_grad

        dome_rot = math.radians(studio.hdri_rotation)
        enabled_pins = [p for p in studio.hdri_pins if p.enabled]

        for pin in enabled_pins:
            p_th = math.radians(pin.azimuth) + dome_rot
            while p_th > math.pi:
                p_th -= 2.0 * math.pi
            while p_th < -math.pi:
                p_th += 2.0 * math.pi
            p_phi = math.radians(pin.elevation)

            cos_phi_p = math.cos(p_phi)
            sin_phi_p = math.sin(p_phi)
            cos_dist = np.clip(np.sin(Y) * sin_phi_p + np.cos(Y) * cos_phi_p * np.cos(X - p_th), -1.0, 1.0)

            if pin.pin_shape == 'CIRCLE':
                dist = np.arccos(cos_dist)
                r_core = max(0.005, pin.radius)
                r_outer = max(r_core + 0.001, pin.radius + pin.falloff)
                mask = np.clip((r_outer - dist) / (r_outer - r_core), 0.0, 1.0)
                mask = mask * mask * (3.0 - 2.0 * mask)
            else:
                d_th = np.abs(X - p_th)
                d_th = np.minimum(d_th, 2.0 * math.pi - d_th) * np.cos(Y)
                d_phi = np.abs(Y - p_phi)

                w_core = max(0.005, pin.radius * max(0.1, pin.aspect))
                w_outer = w_core + pin.falloff
                h_core = max(0.005, pin.radius)
                h_outer = h_core + pin.falloff

                cos_r = math.cos(math.radians(pin.rotation))
                sin_r = math.sin(math.radians(pin.rotation))
                rot_u = np.abs(d_th * cos_r + d_phi * sin_r)
                rot_v = np.abs(-d_th * sin_r + d_phi * cos_r)

                mask_u = np.clip((w_outer - rot_u) / max(0.001, w_outer - w_core), 0.0, 1.0)
                mask_v = np.clip((h_outer - rot_v) / max(0.001, h_outer - h_core), 0.0, 1.0)
                mask = (mask_u * mask_u * (3.0 - 2.0 * mask_u)) * (mask_v * mask_v * (3.0 - 2.0 * mask_v))
                mask *= (cos_dist > 0.0).astype(np.float32)

            rgb[:, :, 0] += mask * pin.color[0] * pin.energy
            rgb[:, :, 1] += mask * pin.color[1] * pin.energy
            rgb[:, :, 2] += mask * pin.color[2] * pin.energy

        rgb = rgb / (1.0 + rgb)

        h_idx = height // 2
        rgb[h_idx, :, :] = np.clip(rgb[h_idx, :, :] * 0.75 + 0.25, 0.0, 1.0)

        m_idx = width // 2
        rgb[:, m_idx, :] = np.clip(rgb[:, m_idx, :] * 0.8 + 0.2, 0.0, 1.0)

        for pin in enabled_pins:
            p_th = math.radians(pin.azimuth) + dome_rot
            while p_th > math.pi:
                p_th -= 2.0 * math.pi
            while p_th < -math.pi:
                p_th += 2.0 * math.pi
            p_phi = math.radians(pin.elevation)

            cx = int(((p_th + math.pi) / (2.0 * math.pi)) * width) % width
            cy = int(((p_phi + math.pi * 0.5) / math.pi) * height)
            cy = max(0, min(height - 1, cy))

            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    nx = (cx + dx) % width
                    ny = max(0, min(height - 1, cy + dy))
                    rgb[ny, nx, :] = [1.0, 1.0, 1.0] if (dx == 0 or dy == 0) else [0.0, 0.0, 0.0]

        rgba = np.ones((height, width, 4), dtype=np.float32)
        rgba[:, :, :3] = rgb
        flat = rgba.flatten()
        img.pixels.foreach_set(flat)
        img.update()
        try:
            prev = img.preview_ensure()
            prev.image_size = (width, height)
            prev.image_pixels_float = flat
            prev.icon_size = (32, 32)
            prev.icon_pixels_float = rgba[::max(1, height // 32), ::max(1, width // 32), :].flatten()
        except Exception:
            pass
        studio.hdri_preview_image = img
        return img
    except Exception:
        return None

def update_studio_dome_visualizer(studio=None, context=None):
    # Safely clean up any leftover 3D visualizer objects from the scene
    dome_obj = bpy.data.objects.get(DOME_VISUALIZER_OBJ)
    if dome_obj:
        try:
            bpy.data.objects.remove(dome_obj, do_unlink=True)
        except Exception:
            pass
    for obj in list(bpy.data.objects):
        if obj.name.startswith(DOME_PIN_PREFIX):
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except Exception:
                pass

def capture_studio_state(context, studio):
    if studio.is_locked:
        return

    global _IS_INTERNAL_UPDATE
    prev_flag = _IS_INTERNAL_UPDATE
    _IS_INTERNAL_UPDATE = True
    try:
        scene = context.scene
        ensure_studio_light_collection(context, studio)
        sync_studio_cmf_toggles(scene, studio)

        if scene.camera:
            studio.camera_obj = scene.camera
        if not studio.world_name:
            studio.world_name = scene.world.name if scene.world else f"World_{bpy.path.clean_name(studio.name)}"

        ignored_colls = {s.light_collection_name for s in scene.rf_studios if s.light_collection_name}
        ignored_colls.add(MASTER_LIGHT_COLL)
        ignored_colls.add(MASTER_CAM_COLL)

        studio.collection_states.clear()
        for coll in bpy.data.collections:
            if coll.name in ignored_colls:
                continue
            item = studio.collection_states.add()
            item.name = coll.name
            item.hide_viewport = coll.hide_viewport
            item.hide_render = coll.hide_render

        record_materials_into_collection(scene, studio.object_materials)
        if studio.cmf_mode not in {'NONE', 'CUSTOM'}:
            cmf = next((c for c in scene.rf_cmf_presets if c.name == studio.cmf_mode), None)
            if cmf:
                record_materials_into_collection(scene, cmf.object_materials)

        studio.object_transforms.clear()
        for obj in list(scene.objects):
            if obj.type in {'MESH', 'CURVE', 'SURFACE', 'EMPTY'} and obj.name not in {TARGET_EMPTY_NAME, GROUND_PLANE_NAME, BACKDROP_OBJ_NAME, DOME_VISUALIZER_OBJ} and not obj.name.startswith(DOME_PIN_PREFIX):
                t_item = studio.object_transforms.add()
                t_item.object_name = obj.name
                t_item.location = obj.location
                t_item.rotation_euler = obj.rotation_euler
                t_item.scale = obj.scale

        studio.light_states.clear()
        for obj in list(scene.objects):
            if obj.type == 'LIGHT':
                l_item = studio.light_states.add()
                l_item.light_obj_name = obj.name
                l_item.location = obj.location
                l_item.rotation_euler = obj.rotation_euler
                l_item.scale = obj.scale
                l_item.energy = obj.data.energy
                l_item.color = obj.data.color
                if hasattr(obj.data, "size"):
                    l_item.size = obj.data.size
                l_item.hide_viewport = obj.hide_get()
                l_item.hide_render = obj.hide_render
    finally:
        _IS_INTERNAL_UPDATE = prev_flag

def apply_studio_state(context, studio):
    global _IS_INTERNAL_UPDATE
    prev_flag = _IS_INTERNAL_UPDATE
    _IS_INTERNAL_UPDATE = True
    try:
        scene = context.scene
        sync_studio_cmf_toggles(scene, studio)

        if studio.use_camera and studio.camera_obj and studio.camera_obj.type == 'CAMERA':
            scene.camera = studio.camera_obj

        if studio.use_resolution:
            scene.render.resolution_x = studio.res_x
            scene.render.resolution_y = studio.res_y
            scene.render.resolution_percentage = studio.res_scale
            if scene.camera and scene.camera.data:
                scene.camera.data.sensor_fit = 'VERTICAL' if (studio.res_y > studio.res_x) else 'HORIZONTAL'

        if studio.use_lights:
            world = None
            if studio.world_name:
                world = bpy.data.worlds.get(studio.world_name)
            if not world:
                world_name = f"World_{bpy.path.clean_name(studio.name)}"
                world = bpy.data.worlds.get(world_name)
                if not world:
                    world = bpy.data.worlds.new(world_name)
                studio.world_name = world.name
            scene.world = world

            rebuild_studio_hdri_nodes(studio, scene, force=True)
            update_studio_dome_visualizer(studio, context)

            switch_exclusive_studio_lights(context, studio)

            for l_item in studio.light_states:
                obj = bpy.data.objects.get(l_item.light_obj_name)
                if obj and obj.type == 'LIGHT':
                    obj.location = l_item.location
                    obj.rotation_euler = l_item.rotation_euler
                    obj.scale = l_item.scale
                    obj.data.energy = l_item.energy
                    obj.data.color = l_item.color
                    if hasattr(obj.data, "size"):
                        obj.data.size = l_item.size
                    obj.hide_set(l_item.hide_viewport)
                    obj.hide_render = l_item.hide_render

        if studio.use_collections:
            for st in studio.collection_states:
                coll = bpy.data.collections.get(st.name)
                if coll:
                    coll.hide_viewport = st.hide_viewport
                    coll.hide_render = st.hide_render

        if studio.use_transforms:
            for t_item in studio.object_transforms:
                obj = bpy.data.objects.get(t_item.object_name)
                if obj:
                    obj.location = t_item.location
                    obj.rotation_euler = t_item.rotation_euler
                    obj.scale = t_item.scale

        apply_cmf_to_scene(scene, studio)

        if studio.use_image_style:
            apply_image_style_to_scene(scene, studio)
        if getattr(studio, "viewport_show_dome", False):
            scene.render.film_transparent = False

        target_samples = studio.studio_samples if studio.use_custom_samples else scene.rf_render_samples
        apply_render_quality_settings(scene, target_samples)
    finally:
        _IS_INTERNAL_UPDATE = prev_flag

# ------------------------------------------------------------------------
# Real-Time Auto-Save Handler for Camera & Lighting Changes
# ------------------------------------------------------------------------

@bpy.app.handlers.persistent
def renderflo_auto_save_handler(scene, depsgraph):
    global _IS_INTERNAL_UPDATE
    if _IS_INTERNAL_UPDATE:
        return

    if not getattr(scene, "rf_auto_save_studios", True):
        return

    studios = getattr(scene, "rf_studios", None)
    if not studios or not (0 <= scene.rf_studio_index < len(studios)):
        return

    active_studio = studios[scene.rf_studio_index]
    if active_studio.is_locked:
        return

    needs_save = False

    cam_obj = active_studio.camera_obj or scene.camera
    cam_name = cam_obj.name if cam_obj else None

    light_coll_name = active_studio.light_collection_name
    light_coll = bpy.data.collections.get(light_coll_name) if light_coll_name else None
    light_names = {obj.name for obj in light_coll.objects if obj.type == 'LIGHT'} if light_coll else set()

    for update in depsgraph.updates:
        uid = update.id
        if isinstance(uid, bpy.types.Object):
            if (cam_name and uid.name == cam_name) or (uid.name in light_names):
                needs_save = True
                break
        elif isinstance(uid, bpy.types.Light):
            if uid.name in light_names:
                needs_save = True
                break
        elif isinstance(uid, bpy.types.Camera):
            if cam_obj and cam_obj.data and uid.name == cam_obj.data.name:
                needs_save = True
                break

    if needs_save:
        if cam_obj:
            active_studio.camera_obj = cam_obj

        active_studio.light_states.clear()
        for obj in list(scene.objects):
            if obj.type == 'LIGHT' and obj.name in light_names:
                l_item = active_studio.light_states.add()
                l_item.light_obj_name = obj.name
                l_item.location = obj.location
                l_item.rotation_euler = obj.rotation_euler
                l_item.scale = obj.scale
                l_item.energy = obj.data.energy
                l_item.color = obj.data.color
                if hasattr(obj.data, "size"):
                    l_item.size = obj.data.size
                l_item.hide_viewport = obj.hide_get()
                l_item.hide_render = obj.hide_render

# ------------------------------------------------------------------------
# Studio Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_toggle_render_preview(bpy.types.Operator):
    bl_idname = "renderflo.toggle_render_preview"
    bl_label = "Toggle Render Preview"

    def execute(self, context):
        configure_cycles_gpu(context.scene, force_gpu=context.scene.rf_force_gpu)
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.shading.type = 'SOLID' if space.shading.type == 'RENDERED' else 'RENDERED'
        return {'FINISHED'}

class RENDERFLO_OT_add_curved_backdrop(bpy.types.Operator):
    bl_idname = "renderflo.add_curved_backdrop"
    bl_label = "Add Studio Curved Backdrop"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        target = ensure_light_target(context)
        b_obj = bpy.data.objects.get(BACKDROP_OBJ_NAME)

        if not b_obj:
            mesh = bpy.data.meshes.new(BACKDROP_OBJ_NAME)
            w, d, h = 10.0, 6.0, 5.0
            verts = [(-w, -d, 0.0), (w, -d, 0.0), (w, d*0.5, 0.0), (-w, d*0.5, 0.0), (-w, d*0.5, h), (w, d*0.5, h)]
            faces = [(0, 1, 2, 3), (3, 2, 5, 4)]
            mesh.from_pydata(verts, [], faces)
            mesh.update()

            b_obj = bpy.data.objects.new(BACKDROP_OBJ_NAME, mesh)
            scene.collection.objects.link(b_obj)

            bev = b_obj.modifiers.new(name="Bevel", type='BEVEL')
            bev.width = 2.5
            bev.segments = 16

            sub = b_obj.modifiers.new(name="Subsurf", type='SUBSURF')
            sub.levels = 1

            for p in mesh.polygons:
                p.use_smooth = True

            mat = bpy.data.materials.new(name="RenderFlo_Backdrop_Mat")
            mat.use_nodes = True
            bsdf = mat.node_tree.nodes.get("Principled BSDF")
            if bsdf:
                col_socket = bsdf.inputs.get("Base Color") or bsdf.inputs.get("Color")
                if col_socket:
                    col_socket.default_value = (0.85, 0.85, 0.85, 1.0)
                rough_socket = bsdf.inputs.get("Roughness")
                if rough_socket:
                    rough_socket.default_value = 0.6
            b_obj.data.materials.append(mat)

        b_obj.location = (target.location.x, target.location.y, 0.0)
        self.report({'INFO'}, "Created/Aligned Studio Backdrop")
        return {'FINISHED'}

class RENDERFLO_OT_toggle_studio_light(bpy.types.Operator):
    bl_idname = "renderflo.toggle_studio_light"
    bl_label = "Toggle Studio Light"
    bl_description = "Turn this physical light on/off in both Viewport and Render view"
    bl_options = {'REGISTER', 'UNDO'}

    light_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.light_name)
        if not obj:
            return {'CANCELLED'}

        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if studio.is_locked:
                self.report({'WARNING'}, "Active Studio is locked.")
                return {'CANCELLED'}

        is_hidden = obj.hide_viewport or obj.hide_render or obj.hide_get()
        new_hide = not is_hidden

        obj.hide_viewport = new_hide
        obj.hide_render = new_hide
        try:
            obj.hide_set(new_hide)
        except Exception:
            pass

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if not studio.is_locked:
                capture_studio_state(context, studio)

        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        state_str = "OFF (Viewport & Render)" if new_hide else "ON (Viewport & Render)"
        self.report({'INFO'}, f"Light '{obj.name}' turned {state_str}")
        return {'FINISHED'}

class RENDERFLO_OT_remove_studio_light(bpy.types.Operator):
    bl_idname = "renderflo.remove_studio_light"
    bl_label = "Delete Studio Light"
    bl_description = "Delete this physical light from the scene and studio collection"
    bl_options = {'REGISTER', 'UNDO'}

    light_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.light_name)
        if not obj:
            return {'CANCELLED'}

        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if studio.is_locked:
                self.report({'WARNING'}, "Active Studio is locked.")
                return {'CANCELLED'}

        l_name = obj.name
        l_data = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if l_data and l_data.users == 0:
            bpy.data.lights.remove(l_data)

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if not studio.is_locked:
                capture_studio_state(context, studio)

        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        self.report({'INFO'}, f"Deleted Light '{l_name}'")
        return {'FINISHED'}

class RENDERFLO_OT_place_highlight_modal(bpy.types.Operator):
    bl_idname = "renderflo.place_highlight_modal"
    bl_label = "Click on Model to Place Highlight"
    bl_options = {'REGISTER', 'UNDO'}

    light_name: bpy.props.StringProperty()
    distance: bpy.props.FloatProperty(default=2.5, min=0.2, max=20.0)

    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'MOUSEMOVE', 'LEFTMOUSE'}:
            region = context.region
            rv3d = context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, obj, matrix = context.scene.ray_cast(depsgraph, ray_origin, view_vector)

            if result and obj and obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                light_obj = bpy.data.objects.get(self.light_name)
                target = ensure_light_target(context)
                if light_obj:
                    incident = (location - ray_origin).normalized()
                    n = normal.normalized()
                    reflect_vec = (incident - 2.0 * incident.dot(n) * n).normalized()
                    dist = max((light_obj.location - target.location).length, self.distance)
                    light_obj.location = location + reflect_vec * dist
                    target.location = location

                if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                    context.window.cursor_modal_restore()
                    if 0 <= context.scene.rf_studio_index < len(context.scene.rf_studios):
                        capture_studio_state(context, context.scene.rf_studios[context.scene.rf_studio_index])
                    self.report({'INFO'}, f"Placed highlight on '{obj.name}'")
                    return {'FINISHED'}

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            context.window.cursor_modal_restore()
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            context.window.cursor_modal_set('EYEDROPPER')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        return {'CANCELLED'}

class RENDERFLO_OT_place_hdri_pin_modal(bpy.types.Operator):
    bl_idname = "renderflo.place_hdri_pin_modal"
    bl_label = "Click on Model to Place HDRI Pin"
    bl_options = {'REGISTER', 'UNDO'}

    pin_index: bpy.props.IntProperty(default=0)
    _orig_azimuth: float = 0.0
    _orig_elevation: float = 0.0

    def modal(self, context, event):
        context.area.tag_redraw()
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            context.window.cursor_modal_restore()
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if not (0 <= self.pin_index < len(studio.hdri_pins)):
            context.window.cursor_modal_restore()
            return {'CANCELLED'}

        pin = studio.hdri_pins[self.pin_index]

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            context.window.cursor_modal_restore()
            pin.azimuth = self._orig_azimuth
            pin.elevation = self._orig_elevation
            rebuild_studio_hdri_nodes(studio, scene)
            update_studio_dome_visualizer(studio, context)
            return {'CANCELLED'}

        if event.type in {'MOUSEMOVE', 'LEFTMOUSE'}:
            region = context.region
            rv3d = context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, obj, matrix = scene.ray_cast(depsgraph, ray_origin, view_vector)

            if result and obj and obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                incident = (location - ray_origin).normalized()
                n = normal.normalized()
                r_vec = (incident - 2.0 * incident.dot(n) * n).normalized()

                az_deg = math.degrees(math.atan2(r_vec.y, r_vec.x)) - studio.hdri_rotation
                while az_deg > 180.0:
                    az_deg -= 360.0
                while az_deg < -180.0:
                    az_deg += 360.0

                el_deg = math.degrees(math.asin(max(-1.0, min(1.0, r_vec.z))))

                pin.azimuth = az_deg
                pin.elevation = el_deg
                rebuild_studio_hdri_nodes(studio, scene)
                update_studio_dome_visualizer(studio, context)

                if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                    context.window.cursor_modal_restore()
                    if getattr(scene, "rf_auto_save_studios", True) and not studio.is_locked:
                        capture_studio_state(context, studio)
                    self.report({'INFO'}, f"Placed HDRI Pin '{pin.name}' on '{obj.name}' ({az_deg:.1f}°, {el_deg:.1f}°)")
                    return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            self.report({'WARNING'}, "No active Studio.")
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        if not (0 <= self.pin_index < len(studio.hdri_pins)):
            self.report({'WARNING'}, "Invalid HDRI Pin index.")
            return {'CANCELLED'}

        pin = studio.hdri_pins[self.pin_index]
        self._orig_azimuth = pin.azimuth
        self._orig_elevation = pin.elevation

        if context.area.type == 'VIEW_3D':
            context.window.cursor_modal_set('EYEDROPPER')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}

        return {'CANCELLED'}

# ------------------------------------------------------------------------
# 2D GPU Drawing Helpers for KeyShot-Style Interactive HDRI Dome Canvas
# ------------------------------------------------------------------------

def get_2d_gpu_shader():
    try:
        return gpu.shader.from_builtin('UNIFORM_COLOR')
    except Exception:
        return gpu.shader.from_builtin('2D_UNIFORM_COLOR')

def draw_2d_quad(x1, y1, x2, y2, color):
    shader = get_2d_gpu_shader()
    batch = batch_for_shader(shader, 'TRI_FAN', {
        "pos": [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
    })
    gpu.state.blend_set('ALPHA')
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set('NONE')

def draw_2d_line(x1, y1, x2, y2, color, line_width=1.0):
    shader = get_2d_gpu_shader()
    batch = batch_for_shader(shader, 'LINES', {
        "pos": [(x1, y1), (x2, y2)]
    })
    gpu.state.blend_set('ALPHA')
    try:
        gpu.state.line_width_set(line_width)
    except Exception:
        pass
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    try:
        gpu.state.line_width_set(1.0)
    except Exception:
        pass
    gpu.state.blend_set('NONE')

def draw_2d_circle(cx, cy, radius, color, segments=24, fill=True):
    coords = []
    if fill:
        coords.append((cx, cy))
    for i in range(segments + 1):
        ang = (2.0 * math.pi * i) / segments
        coords.append((cx + math.cos(ang) * radius, cy + math.sin(ang) * radius))

    shader = get_2d_gpu_shader()
    mode = 'TRI_FAN' if fill else 'LINE_STRIP'
    batch = batch_for_shader(shader, mode, {"pos": coords})
    gpu.state.blend_set('ALPHA')
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set('NONE')

def draw_2d_rect_pin(cx, cy, radius, aspect, rotation_deg, color, fill=True):
    hw = max(1.5, radius * 45.0 * max(0.1, aspect))
    hh = max(1.5, radius * 45.0)
    rad = math.radians(rotation_deg)
    cos_r = math.cos(rad)
    sin_r = math.sin(rad)

    corners = [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]
    rot_corners = []
    for lx, ly in corners:
        rx = cx + lx * cos_r - ly * sin_r
        ry = cy + lx * sin_r + ly * cos_r
        rot_corners.append((rx, ry))

    if fill:
        pts = rot_corners
        mode = 'TRI_FAN'
    else:
        pts = rot_corners + [rot_corners[0]]
        mode = 'LINE_STRIP'

    shader = get_2d_gpu_shader()
    batch = batch_for_shader(shader, mode, {"pos": pts})
    gpu.state.blend_set('ALPHA')
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set('NONE')

def draw_2d_text(text, x, y, size=11, color=(1.0, 1.0, 1.0, 1.0)):
    font_id = 0
    try:
        blf.size(font_id, size)
    except Exception:
        pass
    blf.color(font_id, *color)
    blf.position(font_id, x, y, 0)
    blf.draw(font_id, text)

def draw_2d_image_quad(img, x1, y1, x2, y2, rotation_deg=0.0):
    try:
        sh = gpu.shader.from_builtin('IMAGE')
    except Exception:
        try:
            sh = gpu.shader.from_builtin('2D_IMAGE')
        except Exception:
            return False

    try:
        if hasattr(img, "gl_load"):
            img.gl_load()
    except Exception:
        pass

    try:
        tex = gpu.texture.from_image(img)
    except Exception:
        return False

    u_rot = (rotation_deg / 360.0) % 1.0
    if u_rot < 0.0:
        u_rot += 1.0

    gpu.state.blend_set('ALPHA')
    sh.bind()
    try:
        sh.uniform_sampler('image', tex)
    except Exception:
        pass
    try:
        sh.uniform_float('color', (1.0, 1.0, 1.0, 1.0))
    except Exception:
        pass

    width = x2 - x1
    if u_rot <= 0.001 or u_rot >= 0.999:
        batch = batch_for_shader(sh, 'TRI_FAN', {
            "pos": [(x1, y1), (x2, y1), (x2, y2), (x1, y2)],
            "texCoord": [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)],
        })
        batch.draw(sh)
    else:
        x_split = x1 + u_rot * width

        batch1 = batch_for_shader(sh, 'TRI_FAN', {
            "pos": [(x1, y1), (x_split, y1), (x_split, y2), (x1, y2)],
            "texCoord": [(1.0 - u_rot, 0.0), (1.0, 0.0), (1.0, 1.0), (1.0 - u_rot, 1.0)],
        })
        batch1.draw(sh)

        batch2 = batch_for_shader(sh, 'TRI_FAN', {
            "pos": [(x_split, y1), (x2, y1), (x2, y2), (x_split, y2)],
            "texCoord": [(0.0, 0.0), (1.0 - u_rot, 0.0), (1.0 - u_rot, 1.0), (0.0, 1.0)],
        })
        batch2.draw(sh)

    gpu.state.blend_set('NONE')
    return True

class RENDERFLO_OT_interactive_hdri_canvas(bpy.types.Operator):
    bl_idname = "renderflo.interactive_hdri_canvas"
    bl_label = "KeyShot Interactive HDRI Dome Pin Canvas"
    bl_description = "Open interactive 2D rectangular HDRI dome canvas in 3D Viewport to directly click, drag, add, and manipulate lighting pins"
    bl_options = {'REGISTER'}

    _handle = None
    _is_running = False
    _target_area = None

    canvas_x: int = 50
    canvas_y: int = 50
    canvas_w: int = 400
    canvas_h: int = 200
    title_h: int = 26
    footer_h: int = 22
    dragging_pin: int = -1
    hover_pin: int = -1
    dragging_window: bool = False
    drag_offset_x: int = 0
    drag_offset_y: int = 0
    is_collapsed: bool = False
    size_mode: str = 'STANDARD'

    SIZE_PRESETS = {
        'COMPACT': (320, 160),
        'STANDARD': (400, 200),
        'LARGE': (500, 250),
    }

    def draw_canvas(self, context):
        try:
            self._draw_canvas_impl(context)
        except Exception:
            pass

    def _draw_canvas_impl(self, context):
        # 1. Multi-viewport isolation: strictly draw only inside the viewport where launched
        curr_area = getattr(bpy.context, "area", None) or getattr(context, "area", None)
        if RENDERFLO_OT_interactive_hdri_canvas._target_area is not None and curr_area is not None:
            if curr_area != RENDERFLO_OT_interactive_hdri_canvas._target_area:
                return

        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            return
        studio = scene.rf_studios[scene.rf_studio_index]
        if not studio.use_hdri_dome:
            return

        cx = self.canvas_x
        cy = self.canvas_y
        cw = self.canvas_w
        ch = self.canvas_h
        th = self.title_h
        fh = self.footer_h

        has_hdr = getattr(studio, "use_custom_hdri", False) and bool(studio.hdri_image)

        # Title bar vertical span
        t_y1 = cy if self.is_collapsed else (cy + ch)
        t_y2 = t_y1 + th

        # Outer Frame & Drop Shadow (HardOps pro aesthetic)
        if self.is_collapsed:
            draw_2d_quad(cx - 2, t_y1 - 2, cx + cw + 2, t_y2 + 2, (0.01, 0.01, 0.02, 0.75))
            draw_2d_quad(cx - 1, t_y1 - 1, cx + cw + 1, t_y2 + 1, (0.22, 0.26, 0.35, 0.95))
        else:
            draw_2d_quad(cx - 3, cy - fh - 3, cx + cw + 3, cy + ch + th + 3, (0.01, 0.01, 0.02, 0.8))
            draw_2d_quad(cx - 1, cy - fh - 1, cx + cw + 1, cy + ch + th + 1, (0.22, 0.25, 0.32, 0.95))

        # Title Bar (Shared between collapsed and expanded modes)
        draw_2d_quad(cx, t_y1, cx + cw, t_y2, (0.12, 0.13, 0.16, 0.98))

        # Collapse / Expand Button on Left [ + ] / [ - ]
        min_icon = "+" if self.is_collapsed else "-"
        draw_2d_quad(cx + 4, t_y1 + 3, cx + 22, t_y2 - 3, (0.22, 0.24, 0.30, 0.95))
        draw_2d_text(min_icon, cx + 9, t_y1 + 6, size=11, color=(0.85, 0.9, 1.0, 1.0))

        # Title & Studio Badge
        draw_2d_text("KeyShot HDRI", cx + 28, t_y1 + 7, size=10, color=(0.95, 0.95, 0.98, 1.0))
        draw_2d_text(f"[{studio.name}]", cx + 112, t_y1 + 7, size=9, color=(0.35, 0.75, 1.0, 1.0))

        if self.is_collapsed:
            active_p_cnt = sum(1 for p in studio.hdri_pins if p.enabled)
            draw_2d_text(f"({active_p_cnt}/{len(studio.hdri_pins)} Pins)", cx + 175, t_y1 + 7, size=9, color=(0.7, 0.75, 0.85, 0.9))

        # Right-side Action Badges:
        # Close 'X' Button
        bx_close1 = cx + cw - 24
        bx_close2 = cx + cw - 4
        draw_2d_quad(bx_close1, t_y1 + 3, bx_close2, t_y2 - 3, (0.75, 0.2, 0.2, 0.9))
        draw_2d_text("X", bx_close1 + 6, t_y1 + 6, size=10, color=(1.0, 1.0, 1.0, 1.0))

        # '+ Pin' Button
        bx_add1 = cx + cw - 72
        bx_add2 = cx + cw - 28
        draw_2d_quad(bx_add1, t_y1 + 3, bx_add2, t_y2 - 3, (0.18, 0.45, 0.75, 0.95))
        draw_2d_text("+ Pin", bx_add1 + 6, t_y1 + 6, size=9, color=(1.0, 1.0, 1.0, 1.0))

        # 'HDR: ON' / '+ HDR' Button
        bx_hdr1 = cx + cw - 138
        bx_hdr2 = cx + cw - 76
        hdr_col = (0.15, 0.52, 0.32, 0.95) if has_hdr else (0.24, 0.26, 0.32, 0.95)
        hdr_txt = "HDR: ON" if has_hdr else "+ HDR"
        draw_2d_quad(bx_hdr1, t_y1 + 3, bx_hdr2, t_y2 - 3, hdr_col)
        draw_2d_text(hdr_txt, bx_hdr1 + 6, t_y1 + 6, size=9, color=(1.0, 1.0, 1.0, 1.0))

        # Size Preset Switcher 'Sz:S / M / L'
        bx_sz1 = cx + cw - 176
        bx_sz2 = cx + cw - 142
        draw_2d_quad(bx_sz1, t_y1 + 3, bx_sz2, t_y2 - 3, (0.2, 0.26, 0.36, 0.9))
        sz_tag = "S" if self.size_mode == 'COMPACT' else ("M" if self.size_mode == 'STANDARD' else "L")
        draw_2d_text(f"Sz:{sz_tag}", bx_sz1 + 5, t_y1 + 6, size=9, color=(0.85, 0.92, 1.0, 1.0))

        # IF COLLAPSED: Finish drawing here to leave viewport totally unobstructed!
        if self.is_collapsed:
            return

        # 2. Equirectangular 2:1 Panorama Background
        drawn_custom = False
        if has_hdr:
            draw_2d_quad(cx, cy, cx + cw, cy + ch, (0.04, 0.04, 0.05, 1.0))
            drawn_custom = draw_2d_image_quad(studio.hdri_image, cx, cy, cx + cw, cy + ch, studio.hdri_rotation)

        if not drawn_custom:
            bg_col = (
                max(0.02, min(0.3, studio.hdri_base_color[0] * 0.2 + 0.05)),
                max(0.02, min(0.3, studio.hdri_base_color[1] * 0.2 + 0.05)),
                max(0.02, min(0.3, studio.hdri_base_color[2] * 0.2 + 0.06)),
                0.96
            )
            draw_2d_quad(cx, cy, cx + cw, cy + ch, bg_col)

            # Upper Sky Gradient Tone
            sky_tint = (
                max(0.04, min(0.5, studio.hdri_base_color[0] * 0.35 + 0.08)),
                max(0.04, min(0.5, studio.hdri_base_color[1] * 0.35 + 0.08)),
                max(0.04, min(0.5, studio.hdri_base_color[2] * 0.35 + 0.10)),
                0.45
            )
            draw_2d_quad(cx, cy + ch * 0.5, cx + cw, cy + ch, sky_tint)

        # Subtle Grid Lines: Horizon (0°), Meridian (0° Front)
        draw_2d_line(cx, cy + ch * 0.5, cx + cw, cy + ch * 0.5, (0.7, 0.72, 0.78, 0.65), line_width=1.5)
        draw_2d_line(cx + cw * 0.5, cy, cx + cw * 0.5, cy + ch, (0.75, 0.82, 0.95, 0.75), line_width=1.5)

        # Latitude & Longitude Subdivisions
        draw_2d_line(cx + cw * 0.25, cy, cx + cw * 0.25, cy + ch, (0.4, 0.42, 0.48, 0.35), line_width=1.0)
        draw_2d_line(cx + cw * 0.75, cy, cx + cw * 0.75, cy + ch, (0.4, 0.42, 0.48, 0.35), line_width=1.0)
        draw_2d_line(cx, cy + ch * 0.75, cx + cw, cy + ch * 0.75, (0.4, 0.42, 0.48, 0.3), line_width=1.0)
        draw_2d_line(cx, cy + ch * 0.25, cx + cw, cy + ch * 0.25, (0.4, 0.42, 0.48, 0.3), line_width=1.0)

        # Cardinal Coordinates
        draw_2d_text("-180° Back", cx + 4, cy + ch * 0.5 + 4, size=9, color=(0.7, 0.7, 0.75, 0.85))
        draw_2d_text("-90° Left", cx + cw * 0.25 - 18, cy + ch * 0.5 + 4, size=9, color=(0.7, 0.7, 0.75, 0.85))
        draw_2d_text("0° Front", cx + cw * 0.5 - 18, cy + ch * 0.5 + 4, size=10, color=(0.9, 0.95, 1.0, 0.95))
        draw_2d_text("+90° Right", cx + cw * 0.75 - 20, cy + ch * 0.5 + 4, size=9, color=(0.7, 0.7, 0.75, 0.85))
        draw_2d_text("+180° Back", cx + cw - 56, cy + ch * 0.5 + 4, size=9, color=(0.7, 0.7, 0.75, 0.85))
        draw_2d_text("Zenith (+90°)", cx + cw * 0.5 - 28, cy + ch - 13, size=9, color=(0.65, 0.7, 0.8, 0.75))
        draw_2d_text("Nadir (-90°)", cx + cw * 0.5 - 24, cy + 4, size=9, color=(0.65, 0.7, 0.8, 0.75))

        # 3. Draw Pins on 2D Panorama Canvas
        dome_rot = studio.hdri_rotation
        glow_scale = getattr(studio, "hdri_glow_size", 1.0)
        scale_factor = cw / 480.0
        for idx, pin in enumerate(studio.hdri_pins):
            norm_x = (((pin.azimuth + dome_rot + 180.0) % 360.0) / 360.0)
            norm_y = (pin.elevation + 90.0) / 180.0
            px = cx + norm_x * cw
            py = cy + norm_y * ch

            p_col = (pin.color[0], pin.color[1], pin.color[2], 1.0)
            eff_r = pin.radius * glow_scale
            vis_r = max(2.5, min(75.0, eff_r * 55.0 * scale_factor))
            vis_falloff = max(1.0, min(35.0, pin.falloff * glow_scale * 55.0 * scale_factor))

            if pin.enabled:
                if pin.pin_shape == 'RECT':
                    draw_2d_rect_pin(px, py, eff_r + pin.falloff * glow_scale, pin.aspect, pin.rotation, (p_col[0], p_col[1], p_col[2], 0.2), fill=True)
                    draw_2d_rect_pin(px, py, eff_r, pin.aspect, pin.rotation, (p_col[0], p_col[1], p_col[2], 0.65), fill=True)
                    draw_2d_rect_pin(px, py, eff_r, pin.aspect, pin.rotation, (1.0, 1.0, 1.0, 0.8), fill=False)
                else:
                    draw_2d_circle(px, py, vis_r + vis_falloff, (p_col[0], p_col[1], p_col[2], 0.18), fill=True)
                    draw_2d_circle(px, py, vis_r, (p_col[0], p_col[1], p_col[2], 0.65), fill=True)

                # Center Grab Handle
                handle_r = max(2.5, min(5.0, vis_r * 0.5))
                draw_2d_circle(px, py, handle_r, p_col, fill=True)
                draw_2d_circle(px, py, handle_r, (1.0, 1.0, 1.0, 0.95), fill=False)
            else:
                draw_2d_circle(px, py, 3.5, (0.4, 0.4, 0.4, 0.5), fill=True)
                draw_2d_circle(px, py, 3.5, (0.6, 0.6, 0.6, 0.7), fill=False)

            # Hover or Dragging Ring & Crosshair
            if idx == self.dragging_pin or idx == self.hover_pin:
                draw_2d_circle(px, py, max(8.0, vis_r + 4.0), (0.2, 0.85, 1.0, 0.95), fill=False)
                draw_2d_line(px - 12, py, px + 12, py, (0.2, 0.85, 1.0, 0.8), line_width=1.0)
                draw_2d_line(px, py - 12, px, py + 12, (0.2, 0.85, 1.0, 0.8), line_width=1.0)

            # Pin Label Text
            lbl = f"{pin.name} ({pin.energy:.0f}W)"
            draw_2d_text(lbl, px + 8, py + 3, size=10, color=(1.0, 1.0, 1.0, 0.95))

        # 4. Footer Bar
        draw_2d_quad(cx, cy - fh, cx + cw, cy, (0.11, 0.12, 0.14, 0.98))
        if 0 <= self.hover_pin < len(studio.hdri_pins):
            hp = studio.hdri_pins[self.hover_pin]
            txt = f"Selected: '{hp.name}' | Azimuth: {hp.azimuth:.1f}° | Elevation: {hp.elevation:.1f}° | Energy: {hp.energy:.1f}W | Size: {hp.radius:.3f} | Glow: {hp.falloff:.3f}"
            draw_2d_text(txt, cx + 8, cy - fh + 6, size=9, color=(0.4, 0.85, 1.0, 1.0))
        else:
            if has_hdr:
                hdr_name = studio.hdri_image.name if len(studio.hdri_image.name) <= 14 else studio.hdri_image.name[:12] + ".."
                txt = f"HDR: '{hdr_name}' | M: Minimize | S: Size | Drag: Move | Click: Add | Scroll: Size | ESC: Close"
            else:
                txt = "M: Minimize | S: Size | LMB Drag: Move Pin | Click: Add Pin | Scroll: Size | Ctrl+Scroll: Glow | ESC: Close"
            draw_2d_text(txt, cx + 8, cy - fh + 6, size=9, color=(0.7, 0.72, 0.78, 0.9))

    def modal(self, context, event):
        # 1. Multi-viewport isolation: ignore events happening in other viewport areas!
        try:
            target = RENDERFLO_OT_interactive_hdri_canvas._target_area
            if target is not None:
                screen_areas = list(context.screen.areas) if (context and context.screen) else []
                if target not in screen_areas:
                    self.cancel_modal(context)
                    return {'CANCELLED'}
                if context.area != target:
                    return {'PASS_THROUGH'}
        except Exception:
            pass

        context.area.tag_redraw()
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            self.cancel_modal(context)
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        mx = event.mouse_region_x
        my = event.mouse_region_y

        cx = self.canvas_x
        cy = self.canvas_y
        cw = self.canvas_w
        ch = self.canvas_h
        th = self.title_h
        fh = self.footer_h

        t_y1 = cy if self.is_collapsed else (cy + ch)
        t_y2 = t_y1 + th

        # Keyboard hotkeys
        if event.type == 'ESC' and event.value == 'PRESS':
            self.cancel_modal(context)
            self.report({'INFO'}, "Closed HDRI Pin Canvas.")
            return {'FINISHED'}

        if event.type in {'M', 'H'} and event.value == 'PRESS':
            self.is_collapsed = not self.is_collapsed
            if context.region:
                tot_h = self.title_h if self.is_collapsed else (self.canvas_h + self.title_h + self.footer_h)
                self.canvas_y = max(10, min(self.canvas_y, context.region.height - tot_h - 10))
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'S' and event.value == 'PRESS' and not event.ctrl and not event.shift:
            cycle = {'COMPACT': 'STANDARD', 'STANDARD': 'LARGE', 'LARGE': 'COMPACT'}
            self.size_mode = cycle.get(self.size_mode, 'STANDARD')
            w, h = self.SIZE_PRESETS[self.size_mode]
            self.canvas_w = w
            self.canvas_h = h
            if context.region:
                self.canvas_x = max(10, min(self.canvas_x, context.region.width - self.canvas_w - 10))
                tot_h = self.title_h if self.is_collapsed else (self.canvas_h + self.title_h + self.footer_h)
                self.canvas_y = max(10, min(self.canvas_y, context.region.height - tot_h - 10))
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        # Calculate hit testing bounding boxes
        in_title = (cx <= mx <= cx + cw) and (t_y1 <= my <= t_y2)
        in_min = (cx + 4 <= mx <= cx + 22) and (t_y1 + 3 <= my <= t_y2 - 3)
        in_close = (cx + cw - 24 <= mx <= cx + cw - 4) and (t_y1 + 3 <= my <= t_y2 - 3)
        in_add = (cx + cw - 72 <= mx <= cx + cw - 28) and (t_y1 + 3 <= my <= t_y2 - 3)
        in_hdr = (cx + cw - 138 <= mx <= cx + cw - 76) and (t_y1 + 3 <= my <= t_y2 - 3)
        in_sz = (cx + cw - 176 <= mx <= cx + cw - 142) and (t_y1 + 3 <= my <= t_y2 - 3)

        if self.is_collapsed:
            in_window = in_title
            in_canvas = False
        else:
            in_canvas = (cx <= mx <= cx + cw) and (cy <= my <= cy + ch)
            in_window = (cx <= mx <= cx + cw) and (cy - fh <= my <= cy + ch + th)

        # 1. MOUSEMOVE
        if event.type == 'MOUSEMOVE':
            if self.dragging_window:
                self.canvas_x = mx - self.drag_offset_x
                self.canvas_y = my - self.drag_offset_y
                if context.region:
                    tot_h = self.title_h if self.is_collapsed else (self.canvas_h + self.title_h + self.footer_h)
                    self.canvas_x = max(5, min(self.canvas_x, context.region.width - self.canvas_w - 5))
                    self.canvas_y = max(5, min(self.canvas_y, context.region.height - tot_h - 5))
                return {'RUNNING_MODAL'}

            if not self.is_collapsed and 0 <= self.dragging_pin < len(studio.hdri_pins):
                pin = studio.hdri_pins[self.dragging_pin]
                nx = max(0.0, min(1.0, (mx - cx) / cw))
                ny = max(0.0, min(1.0, (my - cy) / ch))

                az = (nx * 360.0 - 180.0) - studio.hdri_rotation
                while az > 180.0:
                    az -= 360.0
                while az < -180.0:
                    az += 360.0
                el = max(-90.0, min(90.0, ny * 180.0 - 90.0))

                pin.azimuth = az
                pin.elevation = el
                rebuild_studio_hdri_nodes(studio, scene)
                return {'RUNNING_MODAL'}

            # Hover detection
            prev_hover = self.hover_pin
            self.hover_pin = -1
            if in_canvas:
                dome_rot = studio.hdri_rotation
                for idx, pin in enumerate(studio.hdri_pins):
                    norm_x = (((pin.azimuth + dome_rot + 180.0) % 360.0) / 360.0)
                    norm_y = (pin.elevation + 90.0) / 180.0
                    px = cx + norm_x * cw
                    py = cy + norm_y * ch
                    hit_r = max(14.0, pin.radius * 45.0)
                    if (mx - px)**2 + (my - py)**2 <= hit_r**2:
                        self.hover_pin = idx
                        break

            if prev_hover != self.hover_pin:
                context.area.tag_redraw()

            if in_window:
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        # 2. LEFTMOUSE PRESS
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if in_close:
                self.cancel_modal(context)
                self.report({'INFO'}, "Closed HDRI Pin Canvas.")
                return {'FINISHED'}

            if in_min:
                self.is_collapsed = not self.is_collapsed
                if context.region:
                    tot_h = self.title_h if self.is_collapsed else (self.canvas_h + self.title_h + self.footer_h)
                    self.canvas_y = max(10, min(self.canvas_y, context.region.height - tot_h - 10))
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}

            if in_sz:
                cycle = {'COMPACT': 'STANDARD', 'STANDARD': 'LARGE', 'LARGE': 'COMPACT'}
                self.size_mode = cycle.get(self.size_mode, 'STANDARD')
                w, h = self.SIZE_PRESETS[self.size_mode]
                self.canvas_w = w
                self.canvas_h = h
                if context.region:
                    self.canvas_x = max(10, min(self.canvas_x, context.region.width - self.canvas_w - 10))
                    tot_h = self.title_h if self.is_collapsed else (self.canvas_h + self.title_h + self.footer_h)
                    self.canvas_y = max(10, min(self.canvas_y, context.region.height - tot_h - 10))
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}

            if in_hdr:
                bpy.ops.renderflo.load_hdri_image('INVOKE_DEFAULT')
                return {'RUNNING_MODAL'}

            if in_add:
                new_pin = studio.hdri_pins.add()
                new_pin.name = f"Pin_{len(studio.hdri_pins):02d}"
                new_pin.azimuth = 0.0
                new_pin.elevation = 30.0
                new_pin.energy = 15.0
                new_pin.radius = 0.18
                new_pin.falloff = 0.15
                new_pin.enabled = True
                self.dragging_pin = len(studio.hdri_pins) - 1
                self.hover_pin = self.dragging_pin
                rebuild_studio_hdri_nodes(studio, scene)
                return {'RUNNING_MODAL'}

            if in_title:
                self.dragging_window = True
                self.drag_offset_x = mx - self.canvas_x
                self.drag_offset_y = my - self.canvas_y
                return {'RUNNING_MODAL'}

            if in_canvas:
                if self.hover_pin >= 0:
                    self.dragging_pin = self.hover_pin
                    return {'RUNNING_MODAL'}
                else:
                    # Click empty canvas -> spawn new pin at exact clicked coordinate!
                    nx = max(0.0, min(1.0, (mx - cx) / cw))
                    ny = max(0.0, min(1.0, (my - cy) / ch))
                    az = (nx * 360.0 - 180.0) - studio.hdri_rotation
                    while az > 180.0:
                        az -= 360.0
                    while az < -180.0:
                        az += 360.0
                    el = max(-90.0, min(90.0, ny * 180.0 - 90.0))

                    new_pin = studio.hdri_pins.add()
                    new_pin.name = f"Pin_{len(studio.hdri_pins):02d}"
                    new_pin.azimuth = az
                    new_pin.elevation = el
                    new_pin.energy = 15.0
                    new_pin.radius = 0.18
                    new_pin.falloff = 0.15
                    new_pin.enabled = True
                    self.dragging_pin = len(studio.hdri_pins) - 1
                    self.hover_pin = self.dragging_pin
                    rebuild_studio_hdri_nodes(studio, scene)
                    return {'RUNNING_MODAL'}

            return {'PASS_THROUGH'}

        # 3. LEFTMOUSE RELEASE
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            if self.dragging_pin >= 0:
                if getattr(scene, "rf_auto_save_studios", True) and not studio.is_locked:
                    capture_studio_state(context, studio)
                self.dragging_pin = -1
                return {'RUNNING_MODAL'}
            if self.dragging_window:
                self.dragging_window = False
                return {'RUNNING_MODAL'}

        # 4. SCROLL WHEEL (Resize / Energy / Glow)
        if not self.is_collapsed and event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            target_pin = self.hover_pin if self.hover_pin >= 0 else self.dragging_pin
            if 0 <= target_pin < len(studio.hdri_pins):
                pin = studio.hdri_pins[target_pin]
                if event.ctrl:
                    f_delta = 0.005 if event.type == 'WHEELUPMOUSE' else -0.005
                    pin.falloff = max(0.0001, min(1.0, pin.falloff + f_delta))
                elif event.shift:
                    e_delta = 2.0 if event.type == 'WHEELUPMOUSE' else -2.0
                    pin.energy = max(0.0, pin.energy + e_delta)
                else:
                    mult = 1.15 if event.type == 'WHEELUPMOUSE' else 0.85
                    pin.radius = max(0.0005, min(1.5, pin.radius * mult))
                rebuild_studio_hdri_nodes(studio, scene)
                return {'RUNNING_MODAL'}
            elif in_window:
                return {'RUNNING_MODAL'}

        # 5. RIGHTMOUSE (Toggle Pin Enabled)
        if not self.is_collapsed and event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
            if 0 <= self.hover_pin < len(studio.hdri_pins):
                pin = studio.hdri_pins[self.hover_pin]
                pin.enabled = not pin.enabled
                rebuild_studio_hdri_nodes(studio, scene)
                update_studio_dome_visualizer(studio, context)
                return {'RUNNING_MODAL'}
            elif in_window:
                return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        if context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Interactive HDRI Canvas must be opened in 3D Viewport.")
            return {'CANCELLED'}

        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            self.report({'WARNING'}, "No active Studio.")
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if not studio.use_hdri_dome:
            studio.use_hdri_dome = True
            rebuild_studio_hdri_nodes(studio, scene)

        # If already running, close existing instance
        if RENDERFLO_OT_interactive_hdri_canvas._is_running:
            self.cancel_modal(context)
            return {'FINISHED'}

        if context.region:
            if context.region.width < 460:
                self.size_mode = 'COMPACT'
            w, h = self.SIZE_PRESETS[self.size_mode]
            self.canvas_w = w
            self.canvas_h = h
            self.canvas_x = max(20, min(50, context.region.width - self.canvas_w - 40))
            self.canvas_y = max(30, min(50, context.region.height - self.canvas_h - self.title_h - 40))
        else:
            self.canvas_x = 50
            self.canvas_y = 50

        self.dragging_pin = -1
        self.hover_pin = -1
        self.dragging_window = False
        self.drag_offset_x = 0
        self.drag_offset_y = 0
        self.is_collapsed = False

        RENDERFLO_OT_interactive_hdri_canvas._is_running = True
        RENDERFLO_OT_interactive_hdri_canvas._target_area = context.area
        RENDERFLO_OT_interactive_hdri_canvas._handle = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_canvas, (context,), 'WINDOW', 'POST_PIXEL'
        )
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'}, "KeyShot HDRI Canvas Active: Drag pins, press 'M' to minimize, 'S' for size, ESC to close.")
        return {'RUNNING_MODAL'}

    def cancel_modal(self, context):
        if RENDERFLO_OT_interactive_hdri_canvas._handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(RENDERFLO_OT_interactive_hdri_canvas._handle, 'WINDOW')
            RENDERFLO_OT_interactive_hdri_canvas._handle = None
        RENDERFLO_OT_interactive_hdri_canvas._is_running = False
        RENDERFLO_OT_interactive_hdri_canvas._target_area = None
        if context and context.area:
            context.area.tag_redraw()

class RENDERFLO_OT_add_hdri_pin(bpy.types.Operator):
    bl_idname = "renderflo.add_hdri_pin"
    bl_label = "Add HDRI Pin"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            self.report({'WARNING'}, "No active Studio to add HDRI pin.")
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        new_pin = studio.hdri_pins.add()
        new_pin.name = f"Pin_{len(studio.hdri_pins):02d}"
        new_pin.azimuth = 45.0 + (len(studio.hdri_pins) - 1) * 30.0
        while new_pin.azimuth > 180.0:
            new_pin.azimuth -= 360.0
        new_pin.elevation = 35.0
        new_pin.radius = 0.18
        new_pin.falloff = 0.15
        new_pin.energy = 15.0
        new_pin.color = (1.0, 1.0, 1.0)
        new_pin.enabled = True

        rebuild_studio_hdri_nodes(studio, scene)
        update_studio_dome_visualizer(studio, context)
        self.report({'INFO'}, f"Added '{new_pin.name}' to '{studio.name}'")
        return {'FINISHED'}

class RENDERFLO_OT_remove_hdri_pin(bpy.types.Operator):
    bl_idname = "renderflo.remove_hdri_pin"
    bl_label = "Remove HDRI Pin"
    bl_options = {'REGISTER', 'UNDO'}

    pin_index: bpy.props.IntProperty(default=0)

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        if 0 <= self.pin_index < len(studio.hdri_pins):
            p_name = studio.hdri_pins[self.pin_index].name
            studio.hdri_pins.remove(self.pin_index)
            rebuild_studio_hdri_nodes(studio, scene)
            update_studio_dome_visualizer(studio, context)
            self.report({'INFO'}, f"Removed HDRI Pin '{p_name}'")
        return {'FINISHED'}

class RENDERFLO_OT_duplicate_hdri_pin(bpy.types.Operator):
    bl_idname = "renderflo.duplicate_hdri_pin"
    bl_label = "Duplicate HDRI Pin"
    bl_options = {'REGISTER', 'UNDO'}

    pin_index: bpy.props.IntProperty(default=0)

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        if 0 <= self.pin_index < len(studio.hdri_pins):
            src = studio.hdri_pins[self.pin_index]
            dup = studio.hdri_pins.add()
            dup.name = f"{src.name}_Copy"
            dup.enabled = src.enabled
            dup.pin_shape = src.pin_shape
            dup.azimuth = src.azimuth + 15.0
            while dup.azimuth > 180.0:
                dup.azimuth -= 360.0
            dup.elevation = src.elevation
            dup.radius = src.radius
            dup.aspect = src.aspect
            dup.rotation = src.rotation
            dup.falloff = src.falloff
            dup.energy = src.energy
            dup.color = src.color

            rebuild_studio_hdri_nodes(studio, scene)
            update_studio_dome_visualizer(studio, context)
            self.report({'INFO'}, f"Duplicated '{src.name}' -> '{dup.name}'")
        return {'FINISHED'}

class RENDERFLO_OT_load_hdri_image(bpy.types.Operator, ImportHelper):
    bl_idname = "renderflo.load_hdri_image"
    bl_label = "Load HDRI Environment"
    bl_description = "Browse and load an external .hdr, .exr, or panorama image for the studio environment"
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob: bpy.props.StringProperty(
        default="*.hdr;*.exr;*.png;*.jpg;*.jpeg;*.tif;*.tiff",
        options={'HIDDEN'},
        maxlen=255,
    )

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            self.report({'WARNING'}, "No active Studio.")
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        if not self.filepath:
            return {'CANCELLED'}

        try:
            img = bpy.data.images.load(self.filepath, check_existing=True)
            try:
                if hasattr(img, "gl_load"):
                    img.gl_load()
            except Exception:
                pass
            studio.hdri_image = img
            studio.use_custom_hdri = True
            rebuild_studio_hdri_nodes(studio, scene, force=True)
            for screen in bpy.data.screens:
                for area in screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
            self.report({'INFO'}, f"Loaded HDRI: '{img.name}'")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load image: {e}")
            return {'CANCELLED'}

class RENDERFLO_OT_clear_hdri_image(bpy.types.Operator):
    bl_idname = "renderflo.clear_hdri_image"
    bl_label = "Clear HDRI"
    bl_description = "Remove custom HDRI environment map from this studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        studio.hdri_image = None
        studio.use_custom_hdri = False
        rebuild_studio_hdri_nodes(studio, scene, force=True)
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        self.report({'INFO'}, "Cleared custom HDRI map.")
        return {'FINISHED'}

class RENDERFLO_OT_refresh_hdri_preview(bpy.types.Operator):
    bl_idname = "renderflo.refresh_hdri_preview"
    bl_label = "Refresh HDRI Preview"
    bl_description = "Force regeneration of the 2D equirectangular panorama map and 3D visualizer dome"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            rebuild_studio_hdri_nodes(studio, scene, force=True)
            generate_hdri_equirectangular_preview(studio)
            update_studio_dome_visualizer(studio, context)
            for area in context.screen.areas:
                area.tag_redraw()
            self.report({'INFO'}, f"Regenerated HDRI Preview for '{studio.name}'")
        return {'FINISHED'}

class RENDERFLO_OT_snap_shadow_floor(bpy.types.Operator):
    bl_idname = "renderflo.snap_shadow_floor"
    bl_label = "Snap Shadow Catcher Floor to Product"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        min_z = None
        center_x, center_y = 0.0, 0.0
        mesh_count = 0

        depsgraph = context.evaluated_depsgraph_get()
        for obj in list(scene.objects):
            if obj.type == 'MESH' and obj.visible_get() and obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                eval_obj = obj.evaluated_get(depsgraph)
                for corner in eval_obj.bound_box:
                    pt = eval_obj.matrix_world @ Vector(corner)
                    if min_z is None or pt.z < min_z:
                        min_z = pt.z
                center_x += obj.matrix_world.translation.x
                center_y += obj.matrix_world.translation.y
                mesh_count += 1

        if min_z is None:
            min_z = 0.0
        if mesh_count > 0:
            center_x /= mesh_count
            center_y /= mesh_count

        floor_obj = bpy.data.objects.get(GROUND_PLANE_NAME)
        if not floor_obj:
            bpy.ops.mesh.primitive_plane_add(size=25.0, location=(center_x, center_y, min_z))
            floor_obj = context.active_object
            floor_obj.name = GROUND_PLANE_NAME
        else:
            floor_obj.location = (center_x, center_y, min_z)

        floor_obj.is_shadow_catcher = True
        floor_obj.display_type = 'WIRE'
        self.report({'INFO'}, f"Shadow Catcher Floor snapped to Z = {min_z:.3f}")
        return {'FINISHED'}

class RENDERFLO_OT_add_studio(bpy.types.Operator):
    bl_idname = "renderflo.add_studio"
    bl_label = "Create New Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global _IS_INTERNAL_UPDATE
        _IS_INTERNAL_UPDATE = True
        try:
            scene = context.scene
            prev_studio = scene.rf_studios[scene.rf_studio_index] if (0 <= scene.rf_studio_index < len(scene.rf_studios)) else None

            if len(scene.rf_cmf_presets) == 0:
                first_cmf = scene.rf_cmf_presets.add()
                first_cmf.name = "CMF_01_Default"
                record_materials_into_collection(scene, first_cmf.object_materials)

            new_studio = scene.rf_studios.add()
            new_studio.name = f"Studio_{len(scene.rf_studios):02d}"
            new_studio.studio_samples = scene.rf_render_samples

            new_world_name = f"World_{new_studio.name}"
            new_world = bpy.data.worlds.new(new_world_name)
            new_studio.world_name = new_world.name

            if prev_studio:
                new_studio.aspect_preset = prev_studio.aspect_preset
                new_studio.base_resolution = prev_studio.base_resolution
                new_studio.res_x = prev_studio.res_x
                new_studio.res_y = prev_studio.res_y
                new_studio.res_scale = prev_studio.res_scale
                new_studio.exposure = prev_studio.exposure
                new_studio.contrast = getattr(prev_studio, "contrast", 'None')
                new_studio.film_transparent = prev_studio.film_transparent

                new_studio.use_hdri_dome = prev_studio.use_hdri_dome
                new_studio.hdri_base_color = prev_studio.hdri_base_color
                new_studio.hdri_base_energy = prev_studio.hdri_base_energy
                new_studio.hdri_rotation = prev_studio.hdri_rotation

                if scene.rf_studio_clone_lights:
                    for p in prev_studio.hdri_pins:
                        new_p = new_studio.hdri_pins.add()
                        new_p.name = p.name
                        new_p.enabled = p.enabled
                        new_p.pin_shape = p.pin_shape
                        new_p.azimuth = p.azimuth
                        new_p.elevation = p.elevation
                        new_p.radius = p.radius
                        new_p.aspect = p.aspect
                        new_p.rotation = p.rotation
                        new_p.falloff = p.falloff
                        new_p.energy = p.energy
                        new_p.color = p.color
                else:
                    p0 = new_studio.hdri_pins.add()
                    p0.name = "Key_Pin"
                    p0.azimuth = 45.0
                    p0.elevation = 35.0
                    p0.radius = 0.18
                    p0.falloff = 0.15
                    p0.energy = 15.0
                    p0.color = (1.0, 1.0, 1.0)
            else:
                new_studio.res_x = scene.render.resolution_x
                new_studio.res_y = scene.render.resolution_y
                new_studio.exposure = scene.view_settings.exposure
                new_studio.contrast = getattr(scene.view_settings, "look", 'None') or 'None'
                new_studio.film_transparent = scene.render.film_transparent

                p0 = new_studio.hdri_pins.add()
                p0.name = "Key_Pin"
                p0.azimuth = 45.0
                p0.elevation = 35.0
                p0.radius = 0.18
                p0.falloff = 0.15
                p0.energy = 15.0
                p0.color = (1.0, 1.0, 1.0)

            if scene.rf_studio_new_cam_mode == 'NEW_VIEW':
                new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=True)
            elif scene.rf_studio_new_cam_mode == 'NEW_COPY':
                new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=False)
            else:
                if prev_studio and prev_studio.camera_obj:
                    new_studio.camera_obj = prev_studio.camera_obj
                elif scene.camera:
                    new_studio.camera_obj = scene.camera
                else:
                    new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=True)

            new_light_coll = ensure_studio_light_collection(context, new_studio)
            if scene.rf_studio_clone_lights and prev_studio and prev_studio.light_collection_name:
                prev_coll = bpy.data.collections.get(prev_studio.light_collection_name)
                if prev_coll:
                    for obj in list(prev_coll.objects):
                        if obj.type == 'LIGHT':
                            new_obj = obj.copy()
                            new_obj.data = obj.data.copy()
                            new_obj.name = f"{new_studio.name}_{obj.name}"
                            new_light_coll.objects.link(new_obj)

            if prev_studio and prev_studio.cmf_mode:
                new_studio.cmf_mode = prev_studio.cmf_mode
            else:
                new_studio.cmf_mode = scene.rf_cmf_presets[0].name

            for s in scene.rf_studios:
                sync_studio_cmf_toggles(scene, s)

            scene.rf_studio_index = len(scene.rf_studios) - 1
            scene.world = new_world
            switch_exclusive_studio_lights(context, new_studio)
            capture_studio_state(context, new_studio)
            apply_studio_state(context, new_studio)
        finally:
            _IS_INTERNAL_UPDATE = False

        self.report({'INFO'}, f"ID RenderFlo: Created '{new_studio.name}'")
        return {'FINISHED'}

class RENDERFLO_OT_make_unique_camera(bpy.types.Operator):
    bl_idname = "renderflo.make_unique_camera"
    bl_label = "Spawn Dedicated Camera for This Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            studio.camera_obj = create_camera_for_studio(context, studio.name, match_viewport=False)
        return {'FINISHED'}

class RENDERFLO_OT_save_new_cmf(bpy.types.Operator):
    bl_idname = "renderflo.save_new_cmf"
    bl_label = "Save Current Materials as New CMF"
    bl_options = {'REGISTER', 'UNDO'}

    cmf_name: bpy.props.StringProperty(name="CMF Name", default="CMF_New_Colorway")

    def invoke(self, context, event):
        self.cmf_name = f"CMF_{len(context.scene.rf_cmf_presets) + 1:02d}"
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene
        new_cmf = scene.rf_cmf_presets.add()
        existing_names = {c.name for c in scene.rf_cmf_presets if c != new_cmf}
        base_name = self.cmf_name
        counter = 1
        while base_name in existing_names:
            base_name = f"{self.cmf_name}_{counter}"
            counter += 1
        new_cmf.name = base_name
        record_materials_into_collection(scene, new_cmf.object_materials)

        for s in scene.rf_studios:
            sync_studio_cmf_toggles(scene, s)

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            scene.rf_studios[scene.rf_studio_index].cmf_mode = new_cmf.name
        return {'FINISHED'}

class RENDERFLO_OT_update_active_cmf(bpy.types.Operator):
    bl_idname = "renderflo.update_active_cmf"
    bl_label = "Overwrite CMF Preset with Current Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if studio.cmf_mode == 'CUSTOM':
                record_materials_into_collection(scene, studio.object_materials)
            elif studio.cmf_mode != 'NONE':
                cmf = next((c for c in scene.rf_cmf_presets if c.name == studio.cmf_mode), None)
                if cmf:
                    record_materials_into_collection(scene, cmf.object_materials)
        return {'FINISHED'}

class RENDERFLO_OT_spawn_studio_light(bpy.types.Operator):
    bl_idname = "renderflo.spawn_studio_light"
    bl_label = "Add Studio Light"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(
        items=[
            ('KEY', "Key Softbox", "Primary 45-degree softbox light"),
            ('RIM', "Rim / Edge", "Back/Side high-contrast edge highlight light"),
            ('FILL', "Top Fill", "Soft overhead diffused fill light"),
        ],
        default='KEY'
    )

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            bpy.ops.renderflo.add_studio()

        studio = scene.rf_studios[scene.rf_studio_index]
        light_coll = ensure_studio_light_collection(context, studio)
        target = ensure_light_target(context)

        if self.preset == 'KEY':
            l_name, offset, energy, size, color = f"{studio.name}_KeyLight", Vector((2.2, -2.2, 1.8)), 150.0, 1.5, (1.0, 0.98, 0.95)
        elif self.preset == 'RIM':
            l_name, offset, energy, size, color = f"{studio.name}_RimLight", Vector((-2.0, 2.2, 1.2)), 250.0, 0.6, (0.95, 0.98, 1.0)
        else:
            l_name, offset, energy, size, color = f"{studio.name}_TopFill", Vector((0.0, 0.0, 3.0)), 80.0, 2.5, (1.0, 1.0, 1.0)

        light_data = bpy.data.lights.new(name=l_name, type='AREA')
        light_data.energy = energy
        light_data.size = size
        light_data.color = color
        light_data.shape = 'RECTANGLE'
        light_data.size_y = size * 0.65

        light_obj = bpy.data.objects.new(name=l_name, object_data=light_data)
        light_obj.location = target.location + offset
        light_coll.objects.link(light_obj)

        track = light_obj.constraints.new(type='TRACK_TO')
        track.target = target
        track.track_axis = 'TRACK_NEGATIVE_Z'
        track.up_axis = 'UP_Y'

        for o in context.selected_objects:
            o.select_set(False)
        light_obj.select_set(True)
        context.view_layer.objects.active = light_obj
        capture_studio_state(context, studio)
        return {'FINISHED'}

class RENDERFLO_OT_update_studio(bpy.types.Operator):
    bl_idname = "renderflo.update_studio"
    bl_label = "Update Studio State"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        if 0 <= self.index < len(scene.rf_studios):
            studio = scene.rf_studios[self.index]
            sync_studio_cmf_toggles(scene, studio)
            capture_studio_state(context, studio)
            self.report({'INFO'}, f"Saved state for '{studio.name}'")
        return {'FINISHED'}

class RENDERFLO_OT_activate_studio(bpy.types.Operator):
    bl_idname = "renderflo.activate_studio"
    bl_label = "Activate Studio"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        if getattr(scene, "rf_auto_save_studios", True) and (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            prev_studio = scene.rf_studios[scene.rf_studio_index]
            if not prev_studio.is_locked:
                capture_studio_state(context, prev_studio)

        if 0 <= self.index < len(scene.rf_studios):
            studio = scene.rf_studios[self.index]
            scene.rf_studio_index = self.index
            sync_studio_cmf_toggles(scene, studio)
            apply_studio_state(context, studio)
        return {'FINISHED'}

class RENDERFLO_OT_remove_studio(bpy.types.Operator):
    bl_idname = "renderflo.remove_studio"
    bl_label = "Remove Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        idx = scene.rf_studio_index
        if 0 <= idx < len(scene.rf_studios):
            studio = scene.rf_studios[idx]
            if studio.light_collection_name:
                coll = bpy.data.collections.get(studio.light_collection_name)
                if coll:
                    for obj in list(coll.objects):
                        bpy.data.objects.remove(obj, do_unlink=True)
                    bpy.data.collections.remove(coll)
            if studio.world_name:
                w_obj = bpy.data.worlds.get(studio.world_name)
                if w_obj:
                    bpy.data.worlds.remove(w_obj)
            scene.rf_studios.remove(idx)
            scene.rf_studio_index = max(0, min(idx, len(scene.rf_studios) - 1))
            if len(scene.rf_studios) > 0:
                apply_studio_state(context, scene.rf_studios[scene.rf_studio_index])
        return {'FINISHED'}

class RENDERFLO_OT_select_target(bpy.types.Operator):
    bl_idname = "renderflo.select_target"
    bl_label = "Select Light Target"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        target = ensure_light_target(context)
        for o in context.selected_objects:
            o.select_set(False)
        target.select_set(True)
        context.view_layer.objects.active = target
        return {'FINISHED'}

class RENDERFLO_OT_activate_gpu_now(bpy.types.Operator):
    bl_idname = "renderflo.activate_gpu_now"
    bl_label = "Verify & Activate GPU Now"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        hw_label = configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)
        apply_render_quality_settings(scene, scene.rf_render_samples)
        self.report({'INFO'}, f"ID RenderFlo: Render device set to {hw_label} @ {scene.rf_render_samples} Samples")
        return {'FINISHED'}

# ------------------------------------------------------------------------
# Non-Blocking Modal Batch Render Queue
# ------------------------------------------------------------------------

class RENDERFLO_OT_cancel_batch_render(bpy.types.Operator):
    bl_idname = "renderflo.cancel_batch_render"
    bl_label = "Cancel Batch Queue"

    def execute(self, context):
        context.scene.rf_is_batch_rendering = False
        return {'FINISHED'}

class RENDERFLO_OT_batch_render(bpy.types.Operator):
    bl_idname = "renderflo.batch_render"
    bl_label = "Batch Render Studios (GPU Modal Queue)"

    matrix_mode: bpy.props.BoolProperty(default=False)

    _timer = None
    _jobs = []
    _current_job_idx = 0
    _is_rendering_frame = False
    _frame_finished = False
    _render_cancelled = False
    _orig_filepath = ""
    _orig_res_x = 1920
    _orig_res_y = 1080
    _orig_res_scale = 100
    _orig_samples = 256
    _orig_world = None
    _base_dir = ""

    def _on_render_complete(self, scene, depsgraph=None):
        self._frame_finished = True

    def _on_render_cancel(self, scene, depsgraph=None):
        self._render_cancelled = True

    def _cleanup(self, context):
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None

        if self._on_render_complete in bpy.app.handlers.render_complete:
            bpy.app.handlers.render_complete.remove(self._on_render_complete)
        if self._on_render_cancel in bpy.app.handlers.render_cancel:
            bpy.app.handlers.render_cancel.remove(self._on_render_cancel)

        scene = context.scene
        scene.render.filepath = self._orig_filepath
        scene.render.resolution_x = self._orig_res_x
        scene.render.resolution_y = self._orig_res_y
        scene.render.resolution_percentage = self._orig_res_scale
        if hasattr(scene, "cycles"):
            scene.cycles.samples = self._orig_samples
        if self._orig_world:
            scene.world = self._orig_world

        scene.rf_is_batch_rendering = False
        scene.rf_batch_status_text = ""
        for area in context.screen.areas:
            area.tag_redraw()

    def invoke(self, context, event):
        scene = context.scene
        if scene.rf_is_batch_rendering:
            self.report({'WARNING'}, "Batch Render is already running!")
            return {'CANCELLED'}

        for s in scene.rf_studios:
            sync_studio_cmf_toggles(scene, s)

        if getattr(scene, "rf_auto_save_studios", True) and (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            active_s = scene.rf_studios[scene.rf_studio_index]
            if not active_s.is_locked:
                capture_studio_state(context, active_s)

        self._orig_filepath = scene.render.filepath
        if not self._orig_filepath:
            self.report({'ERROR'}, "Please set an Output Folder in Render Output Properties first.")
            return {'CANCELLED'}

        self._base_dir = bpy.path.abspath(self._orig_filepath)
        if not self._base_dir.endswith(os.sep):
            base_dir = os.path.dirname(self._base_dir)
            self._base_dir = base_dir
        os.makedirs(self._base_dir, exist_ok=True)

        self._orig_res_x = scene.render.resolution_x
        self._orig_res_y = scene.render.resolution_y
        self._orig_res_scale = scene.render.resolution_percentage
        self._orig_samples = scene.cycles.samples if hasattr(scene, "cycles") else 256
        self._orig_world = scene.world

        hw_status = configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)
        self._jobs = []

        for s_idx, studio in enumerate(scene.rf_studios):
            if not studio.render_enabled:
                continue

            s_name = bpy.path.clean_name(studio.name)
            res_tag = f"{studio.res_x}x{studio.res_y}"

            if self.matrix_mode:
                if studio.use_materials and len(studio.cmf_matrix_toggles) > 0:
                    selected_cmfs = [t.cmf_name for t in studio.cmf_matrix_toggles if t.enabled]
                    if selected_cmfs:
                        for cmf_name in selected_cmfs:
                            c_name = bpy.path.clean_name(cmf_name)
                            out_path = os.path.join(self._base_dir, f"{s_name}_{c_name}_{res_tag}")
                            self._jobs.append((s_idx, cmf_name, out_path, f"{studio.name} + {cmf_name}"))
                    else:
                        out_path = os.path.join(self._base_dir, f"{s_name}_Default_{res_tag}")
                        self._jobs.append((s_idx, None, out_path, f"{studio.name} (Default)"))
                else:
                    out_path = os.path.join(self._base_dir, f"{s_name}_Default_{res_tag}")
                    self._jobs.append((s_idx, None, out_path, f"{studio.name} (Default)"))
            else:
                out_path = os.path.join(self._base_dir, f"{s_name}_{res_tag}")
                self._jobs.append((s_idx, None, out_path, f"{studio.name}"))

        if not self._jobs:
            self.report({'WARNING'}, "No checked Studios to render.")
            return {'CANCELLED'}

        if not scene.camera and not any(s.camera_obj for s in scene.rf_studios):
            self.report({'ERROR'}, "No Camera in scene! Please assign or create a Studio Camera first.")
            return {'CANCELLED'}

        self._current_job_idx = 0
        self._is_rendering_frame = False
        self._frame_finished = False
        self._render_cancelled = False

        bpy.app.handlers.render_complete.append(self._on_render_complete)
        bpy.app.handlers.render_cancel.append(self._on_render_cancel)

        scene.rf_is_batch_rendering = True
        scene.rf_batch_progress = 0.0
        scene.rf_batch_status_text = f"Starting {hw_status} Queue (0 / {len(self._jobs)})..."

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.5, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        scene = context.scene

        if event.type == 'ESC' or self._render_cancelled or not scene.rf_is_batch_rendering:
            self._cleanup(context)
            self.report({'WARNING'}, "Batch Render Cancelled.")
            return {'CANCELLED'}

        if event.type != 'TIMER':
            return {'PASS_THROUGH'}

        if self._is_rendering_frame:
            if self._frame_finished:
                self._is_rendering_frame = False
                self._frame_finished = False
                self._current_job_idx += 1
            else:
                return {'PASS_THROUGH'}

        total_jobs = len(self._jobs)
        if self._current_job_idx >= total_jobs:
            self._cleanup(context)
            self.report({'INFO'}, f"ID RenderFlo: Batch Render Complete! ({total_jobs} images saved to {self._base_dir})")
            return {'FINISHED'}

        s_idx, cmf_override, out_path, job_label = self._jobs[self._current_job_idx]
        studio = scene.rf_studios[s_idx]

        scene.rf_studio_index = s_idx
        apply_studio_state(context, studio)

        if cmf_override:
            cmf = next((c for c in scene.rf_cmf_presets if c.name == cmf_override), None)
            if cmf:
                restore_materials_from_collection(cmf.object_materials)

        shot_samples = studio.studio_samples if studio.use_custom_samples else scene.rf_render_samples
        apply_render_quality_settings(scene, shot_samples)
        scene.render.filepath = out_path

        scene.rf_batch_progress = (self._current_job_idx / total_jobs) * 100.0
        scene.rf_batch_status_text = f"Rendering [{self._current_job_idx + 1}/{total_jobs}]: {job_label} ({shot_samples} samples)"
        for area in context.screen.areas:
            area.tag_redraw()

        self._is_rendering_frame = True
        self._frame_finished = False

        res = bpy.ops.render.render('INVOKE_DEFAULT', write_still=True)
        if 'RUNNING_MODAL' not in res:
            bpy.ops.render.render(write_still=True)
            self._frame_finished = True

        return {'PASS_THROUGH'}

# ------------------------------------------------------------------------
# UI Lists & Sidebar Panel
# ------------------------------------------------------------------------

class RENDERFLO_UL_studio_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "render_enabled", text="")
            row.prop(item, "name", text="", emboss=False, icon='RENDERLAYERS')

            sub = row.row(align=True)
            sub.scale_x = 0.85
            aspect_tag = item.aspect_preset.replace('_', ':') if item.aspect_preset != 'CUSTOM' else f"{item.res_x}x{item.res_y}"
            cam_label = item.camera_obj.name if item.camera_obj else "NoCam"
            sub.label(text=f"[{aspect_tag} | {cam_label}]")

            lock_icon = 'LOCKED' if item.is_locked else 'UNLOCKED'
            row.prop(item, "is_locked", text="", icon=lock_icon, emboss=False)

            op_act = row.operator("renderflo.activate_studio", text="", icon='PLAY')
            op_act.index = index

            upd_sub = row.row(align=True)
            upd_sub.enabled = not item.is_locked
            op_upd = upd_sub.operator("renderflo.update_studio", text="", icon='FILE_REFRESH')
            op_upd.index = index

class RENDERFLO_PT_main_panel(bpy.types.Panel):
    bl_label = "ID RenderFlo"
    bl_idname = "RENDERFLO_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ID RenderFlo'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        top_row = layout.row(align=True)
        top_row.operator("renderflo.toggle_render_preview", icon='SHADING_RENDERED', text="Toggle Viewport Render Preview")

        # 0. NATIVE CAD BRIDGE BOX
        cad_box = layout.box()
        ready = is_cad_engine_ready()
        cad_header = cad_box.row(align=True)
        cad_icon = "DOWNARROW_HLT" if scene.rf_fold_cad else "RIGHTARROW"
        cad_header.prop(scene, "rf_fold_cad", text="Native CAD Engine Active" if ready else "CAD Engine Setup Ready", icon=cad_icon, emboss=False)

        if scene.rf_fold_cad:
            cad_col = cad_box.column(align=True)
            imp_row = cad_col.row(align=True)
            imp_row.scale_y = 1.3
            imp_row.operator("renderflo.import_cad", icon='IMPORT', text="Import CAD (.STEP / .IGES / .3DM / .STL)")

            if not ready:
                cad_col.operator("renderflo.bootstrap_cad_kernel", icon='PREFERENCES', text="Verify & Download CAD Engine")

        # 1. Create Studio Controls
        create_box = layout.box()
        col = create_box.column(align=True)
        row = col.row(align=True)
        row.scale_y = 1.3
        row.operator("renderflo.add_studio", icon='ADD', text="Create New Studio")

        ns_header = col.row(align=True)
        ns_icon = "DOWNARROW_HLT" if scene.rf_fold_new_studio else "RIGHTARROW"
        ns_header.prop(scene, "rf_fold_new_studio", text="New Studio Defaults & Auto-Save", icon=ns_icon, emboss=False)
        if scene.rf_fold_new_studio:
            col.prop(scene, "rf_studio_new_cam_mode", text="Cam")
            col.prop(scene, "rf_studio_clone_lights", text="Clone Current Studio Lights")
            col.prop(scene, "rf_auto_save_studios", text="Live Auto-Save (Cam & Lights)")

        # 2. Studio List
        row = layout.row()
        row.template_list("RENDERFLO_UL_studio_list", "", scene, "rf_studios", scene, "rf_studio_index", rows=5)

        col = row.column(align=True)
        col.operator("renderflo.remove_studio", icon='REMOVE', text="")
        col.separator()
        col.operator("renderflo.snap_shadow_floor", icon='IMPORT', text="")

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            active_studio = scene.rf_studios[scene.rf_studio_index]

            # 3. PER-STUDIO ASPECT RATIO & FORMAT (COLLAPSIBLE)
            res_box = layout.box()
            res_header = res_box.row(align=True)
            res_icon = "DOWNARROW_HLT" if scene.rf_fold_format else "RIGHTARROW"
            res_header.prop(scene, "rf_fold_format", text=f"1. Format & Aspect ({active_studio.res_x}x{active_studio.res_y})", icon=res_icon, emboss=False)
            res_header.prop(active_studio, "use_resolution", text="")

            if scene.rf_fold_format and active_studio.use_resolution:
                res_col = res_box.column(align=True)
                res_col.prop(active_studio, "aspect_preset", text="Ratio")
                if active_studio.aspect_preset == 'CUSTOM':
                    xy_row = res_col.row(align=True)
                    xy_row.prop(active_studio, "res_x", text="W")
                    xy_row.prop(active_studio, "res_y", text="H")
                else:
                    res_col.prop(active_studio, "base_resolution", text="Long Edge (px)")
                res_col.prop(active_studio, "res_scale", text="Render Scale")

            # 4. CAMERA MODULE (COLLAPSIBLE)
            cam_box = layout.box()
            cam_header = cam_box.row(align=True)
            cam_icon = "DOWNARROW_HLT" if scene.rf_fold_camera else "RIGHTARROW"
            cam_name = active_studio.camera_obj.name if active_studio.camera_obj else "No Camera"
            cam_header.prop(scene, "rf_fold_camera", text=f"2. Studio Camera ({cam_name})", icon=cam_icon, emboss=False)

            if active_studio.camera_obj:
                shared_count = sum(1 for s in scene.rf_studios if s.camera_obj == active_studio.camera_obj)
                cam_header.label(text=f"Shared ({shared_count})" if shared_count > 1 else "Unique", icon='LINKED' if shared_count > 1 else 'UNLINKED')
            cam_header.prop(active_studio, "use_camera", text="")

            if scene.rf_fold_camera and active_studio.use_camera:
                cam_row = cam_box.row(align=True)
                cam_row.prop(active_studio, "camera_obj", text="")
                cam_row.operator("renderflo.make_unique_camera", text="", icon='DUPLICATE')

                if active_studio.camera_obj and active_studio.camera_obj.type == 'CAMERA':
                    cam_data = active_studio.camera_obj.data
                    cam_settings = cam_box.row(align=True)
                    cam_settings.prop(cam_data, "lens", text="Focal (mm)")
                    if context.space_data and context.space_data.type == 'VIEW_3D':
                        cam_settings.prop(context.space_data, "lock_camera", text="Lock View", icon='LOCKVIEW_ON')

            # 5. CMF MODULE (COLLAPSIBLE)
            cmf_box = layout.box()
            cmf_header = cmf_box.row(align=True)
            cmf_icon = "DOWNARROW_HLT" if scene.rf_fold_cmf else "RIGHTARROW"
            cmf_header.prop(scene, "rf_fold_cmf", text=f"3. CMF Colorway ({active_studio.cmf_mode})", icon=cmf_icon, emboss=False)
            cmf_header.prop(active_studio, "use_materials", text="")

            if scene.rf_fold_cmf and active_studio.use_materials:
                cmf_row = cmf_box.row(align=True)
                cmf_row.prop(active_studio, "cmf_mode", text="")
                cmf_row.operator("renderflo.update_active_cmf", text="", icon='FILE_REFRESH')
                cmf_row.operator("renderflo.save_new_cmf", text="+ New CMF", icon='ADD')

                active_obj = context.active_object
                if active_obj and active_obj.type == 'MESH' and active_obj.active_material:
                    mat_box = cmf_box.box()
                    mat_box.label(text=f"Selected Part: {active_obj.name}", icon='OBJECT_DATA')
                    m_row = mat_box.row(align=True)
                    m_row.prop(active_obj, "active_material", text="")
                    m_row.operator("renderflo.clone_active_material", text="Clone", icon='DUPLICATE')

                    bsdf = active_obj.active_material.node_tree.nodes.get("Principled BSDF") if active_obj.active_material.use_nodes else None
                    if bsdf:
                        col_socket = bsdf.inputs.get("Base Color") or bsdf.inputs.get("Color")
                        if col_socket:
                            mat_box.prop(col_socket, "default_value", text="Color")

                if len(scene.rf_cmf_presets) > 0:
                    cmf_list_col = cmf_box.column(align=True)
                    cmf_list_col.label(text=f"Matrix Colorways for '{active_studio.name}':")
                    if len(active_studio.cmf_matrix_toggles) == len(scene.rf_cmf_presets):
                        grid = cmf_list_col.grid_flow(columns=2, align=True)
                        for t in active_studio.cmf_matrix_toggles:
                            grid.prop(t, "enabled", text=t.cmf_name)
                    else:
                        cmf_list_col.operator("renderflo.sync_cmf_matrix", icon='FILE_REFRESH', text="Sync Colorway List for Studio")
            elif scene.rf_fold_cmf and not active_studio.use_materials:
                cmf_box.label(text="Colorways unchecked: will render default materials in Matrix", icon='INFO')

            # 6. LIGHTING MODULE (KeyShot-style HDRI Dome & Physical Lamps - COLLAPSIBLE)
            light_box = layout.box()
            l_header = light_box.row(align=True)
            light_icon = "DOWNARROW_HLT" if scene.rf_fold_lighting else "RIGHTARROW"
            l_header.prop(scene, "rf_fold_lighting", text=f"4. Lighting Rig ({active_studio.name})", icon=light_icon, emboss=False)
            l_header.operator("renderflo.select_target", text="", icon='PIVOT_CURSOR')
            l_header.prop(active_studio, "use_lights", text="")

            if scene.rf_fold_lighting and active_studio.use_lights:
                if active_studio.is_locked:
                    lock_bar = light_box.row(align=True)
                    lock_bar.alert = True
                    lock_bar.prop(active_studio, "is_locked", text="Studio Padlock Active — Click to Unlock Auto-Save", icon='LOCKED')

                # Segmented Sub-Header Tabs (HardOps / Photographer Style)
                tab_row = light_box.row(align=True)
                tab_row.prop(active_studio, "lighting_tab", expand=True)

                if active_studio.lighting_tab == 'HDRI':
                    # --- PROCEDURAL HDRI DOME & PIN EDITOR ---
                    hdri_box = light_box.box()
                    h_header = hdri_box.row(align=True)
                    h_header.prop(active_studio, "use_hdri_dome", text="Procedural HDRI Dome", icon='WORLD')

                    add_sub = h_header.row(align=True)
                    add_sub.operator("renderflo.add_hdri_pin", text="+ Add Pin", icon='ADD')

                    if active_studio.use_hdri_dome:
                        dome_col = hdri_box.column(align=True)

                        try:
                            # 1. 2D Interactive Canvas Launch & Viewport Dome Toggle
                            action_row = dome_col.row(align=True)
                            action_row.scale_y = 1.35
                            is_canvas_open = getattr(RENDERFLO_OT_interactive_hdri_canvas, "_is_running", False)
                            action_row.operator(
                                "renderflo.interactive_hdri_canvas",
                                text="Close 2D Pin Canvas" if is_canvas_open else "Open 2D Pin Canvas (KeyShot-Style)",
                                icon='RESTRICT_SELECT_OFF' if is_canvas_open else 'WINDOW'
                            )
                            action_row.prop(
                                active_studio, "viewport_show_dome",
                                text="Show Dome",
                                icon='VIEW_CAMERA' if active_studio.viewport_show_dome else 'RESTRICT_VIEW_ON'
                            )

                            # 2. Environment Map / Base Dome Settings
                            custom_box = dome_col.box()
                            hdr_header = custom_box.row(align=True)
                            hdr_header.prop(active_studio, "use_custom_hdri", text="External HDRI Map", icon='IMAGE_DATA')
                            if active_studio.use_custom_hdri:
                                hdr_col = custom_box.column(align=True)
                                load_row = hdr_col.row(align=True)
                                load_row.operator("renderflo.load_hdri_image", text="Browse HDR / EXR...", icon='FILE_FOLDER')
                                if active_studio.hdri_image:
                                    load_row.operator("renderflo.clear_hdri_image", text="", icon='X')

                                img_row = hdr_col.row(align=True)
                                img_row.prop(active_studio, "hdri_image", text="")

                                if active_studio.hdri_image:
                                    s_row = hdr_col.row(align=True)
                                    s_row.prop(active_studio, "hdri_image_strength", text="Intensity")
                                    s_row.prop(active_studio, "hdri_rotation", text="Rotation")
                            else:
                                base_row = custom_box.row(align=True)
                                base_row.prop(active_studio, "hdri_base_color", text="")
                                base_row.prop(active_studio, "hdri_base_energy", text="Base Energy")
                                base_row.prop(active_studio, "hdri_rotation", text="Dome Rot")

                            # 3. Global Highlight Glow & Distance Scale
                            glow_row = dome_col.row(align=True)
                            glow_row.prop(active_studio, "hdri_glow_size", text="Glow / Distance Scale", icon='LIGHT_SUN', slider=True)

                            # 4. Highlight Pins List & Sliders
                            if len(active_studio.hdri_pins) == 0:
                                dome_col.label(text="No pins yet. Click '+ Add Pin' or open the 2D Canvas.", icon='INFO')
                            else:
                                pin_header_row = dome_col.row(align=True)
                                active_count = sum(1 for p in active_studio.hdri_pins if p.enabled)
                                pin_header_row.label(text=f"Highlight Pins ({active_count}/{len(active_studio.hdri_pins)} active):", icon='LIGHT_SUN')
                                pin_header_row.operator("renderflo.add_hdri_pin", text="+ Add Pin", icon='ADD')

                                for p_idx, pin in enumerate(active_studio.hdri_pins):
                                    p_box = dome_col.box()
                                    p_top = p_box.row(align=True)
                                    p_top.prop(pin, "enabled", text="")
                                    p_top.prop(pin, "name", text="", emboss=False)
                                    p_top.prop(pin, "pin_shape", text="")
                                    p_top.prop(pin, "color", text="")

                                    op_eye = p_top.operator("renderflo.place_hdri_pin_modal", text="", icon='EYEDROPPER')
                                    op_eye.pin_index = p_idx

                                    op_dup = p_top.operator("renderflo.duplicate_hdri_pin", text="", icon='DUPLICATE')
                                    op_dup.pin_index = p_idx

                                    op_del = p_top.operator("renderflo.remove_hdri_pin", text="", icon='X')
                                    op_del.pin_index = p_idx

                                    if pin.enabled:
                                        s_col = p_box.column(align=True)
                                        s_row1 = s_col.row(align=True)
                                        s_row1.prop(pin, "energy", text="Energy")
                                        s_row1.prop(pin, "radius", text="Size")
                                        s_row1.prop(pin, "falloff", text="Glow")

                                        if pin.pin_shape == 'RECT':
                                            s_row2 = s_col.row(align=True)
                                            s_row2.prop(pin, "aspect", text="Aspect")
                                            s_row2.prop(pin, "rotation", text="Tilt")
                        except Exception as err:
                            dome_col.label(text=f"HDRI Editor Error: {err}", icon='ERROR')

                else:
                    # --- PHYSICAL LIGHTS MODULE ---
                    phys_box = light_box.box()
                    phys_header = phys_box.row(align=True)
                    phys_header.label(text="Physical Studio Lamps", icon='LIGHT_SUN')

                    spawn_row = phys_box.row(align=True)
                    op_key = spawn_row.operator("renderflo.spawn_studio_light", text="+ Key", icon='LIGHT_SUN')
                    op_key.preset = 'KEY'
                    op_rim = spawn_row.operator("renderflo.spawn_studio_light", text="+ Rim", icon='LIGHT_SPOT')
                    op_rim.preset = 'RIM'
                    op_fill = spawn_row.operator("renderflo.spawn_studio_light", text="+ Fill", icon='LIGHT_HEMI')
                    op_fill.preset = 'FILL'

                    studio_coll = bpy.data.collections.get(active_studio.light_collection_name)
                    has_phys_lights = False
                    if studio_coll and len(studio_coll.objects) > 0:
                        l_col = phys_box.column(align=True)
                        for l_obj in studio_coll.objects:
                            if l_obj.type == 'LIGHT':
                                has_phys_lights = True
                                is_off = l_obj.hide_render or l_obj.hide_viewport or l_obj.hide_get()
                                l_row = l_col.row(align=True)
                                op_toggle = l_row.operator(
                                    "renderflo.toggle_studio_light",
                                    text="",
                                    icon='HIDE_ON' if is_off else 'HIDE_OFF',
                                    emboss=False
                                )
                                op_toggle.light_name = l_obj.name

                                sub = l_row.row(align=True)
                                sub.enabled = not is_off
                                sub.prop(l_obj, "name", text="")
                                sub.prop(l_obj.data, "energy", text="W")
                                sub.prop(l_obj.data, "color", text="")
                                op_hl = sub.operator("renderflo.place_highlight_modal", text="", icon='EYEDROPPER')
                                op_hl.light_name = l_obj.name

                                op_del = l_row.operator("renderflo.remove_studio_light", text="", icon='X')
                                op_del.light_name = l_obj.name

                    if not has_phys_lights:
                        phys_box.label(text="No physical lamps in this studio. Click '+ Key' above to spawn one.", icon='INFO')

            # 7. ENVIRONMENT & STUDIO BACKDROP (COLLAPSIBLE)
            env_box = layout.box()
            env_header = env_box.row(align=True)
            env_icon = "DOWNARROW_HLT" if scene.rf_fold_env else "RIGHTARROW"
            env_header.prop(scene, "rf_fold_env", text="5. Environment, Floor & Backdrop", icon=env_icon, emboss=False)

            if scene.rf_fold_env:
                style_row = env_box.row(align=True)
                style_row.prop(active_studio, "exposure", text="Exposure")
                style_row.prop(active_studio, "contrast", text="Contrast")
                style_row.prop(active_studio, "film_transparent", text="Transparent PNG")
                toggle_row = env_box.row(align=True)
                toggle_row.prop(active_studio, "use_collections", text="Model Sets")
                toggle_row.prop(active_studio, "use_transforms", text="Exploded / Part Pos")

                floor_row = env_box.row(align=True)
                floor_row.operator("renderflo.snap_shadow_floor", icon='MESH_PLANE', text="Floor Shadow Catcher")
                floor_row.operator("renderflo.add_curved_backdrop", icon='MOD_BEVEL', text="Curved Backdrop")

        layout.separator()

        # 8. GPU HARDWARE & SAMPLE CONTROLS (COLLAPSIBLE)
        gpu_box = layout.box()
        gpu_header = gpu_box.row(align=True)
        gpu_icon = "DOWNARROW_HLT" if scene.rf_fold_gpu else "RIGHTARROW"
        dev_str = scene.cycles.device if hasattr(scene, "cycles") else "N/A"
        gpu_header.prop(scene, "rf_fold_gpu", text=f"6. GPU & Render Quality ({dev_str})", icon=gpu_icon, emboss=False)

        if scene.rf_fold_gpu:
            gpu_col = gpu_box.column(align=True)
            hw_row = gpu_col.row(align=True)
            hw_row.prop(scene, "rf_force_gpu", text="Force GPU Compute")
            hw_row.operator("renderflo.activate_gpu_now", text="Activate GPU", icon='CHECKMARK')

            samp_row = gpu_col.row(align=True)
            samp_row.prop(scene, "rf_render_samples", text="Render Samples")
            samp_row.prop(scene, "rf_viewport_samples", text="Viewport")

            dn_row = gpu_col.row(align=True)
            dn_row.prop(scene, "rf_use_denoiser", text="Denoiser")
            dn_row.prop(scene, "rf_noise_threshold", text="Noise Limit")

            if 0 <= scene.rf_studio_index < len(scene.rf_studios):
                active_studio = scene.rf_studios[scene.rf_studio_index]
                ovr_row = gpu_col.row(align=True)
                ovr_row.prop(active_studio, "use_custom_samples", text=f"Custom Samples for '{active_studio.name}'")
                if active_studio.use_custom_samples:
                    ovr_row.prop(active_studio, "studio_samples", text="Samples")

        # 9. Non-Blocking Modal Batch Render Queue
        render_box = layout.box()
        render_col = render_box.column(align=True)

        if scene.rf_is_batch_rendering:
            render_col.label(text=scene.rf_batch_status_text, icon='TIME')
            render_col.prop(scene, "rf_batch_progress", text="Batch Progress", slider=True)
            cancel_row = render_col.row(align=True)
            cancel_row.scale_y = 1.4
            cancel_row.operator("renderflo.cancel_batch_render", icon='CANCEL', text="Cancel Batch Render (or Press ESC)")
        else:
            btn_std = render_col.row(align=True)
            btn_std.scale_y = 1.4
            op_std = btn_std.operator("renderflo.batch_render", icon='RENDER_STILL', text="Batch Render Checked Studios (GPU)")
            op_std.matrix_mode = False

            btn_mat = render_col.row(align=True)
            btn_mat.scale_y = 1.3
            op_mat = btn_mat.operator("renderflo.batch_render", icon='GRID', text="Matrix Render (Studios x CMFs)")
            op_mat.matrix_mode = True

def menu_func_import_cad(self, context):
    self.layout.operator(RENDERFLO_OT_import_cad.bl_idname, text="CAD Assembly (.step, .stp, .iges, .3dm, .stl)")

classes = (
    RENDERFLO_PG_collection_state,
    RENDERFLO_PG_material_slot,
    RENDERFLO_PG_object_materials,
    RENDERFLO_PG_object_transform,
    RENDERFLO_PG_cmf_preset,
    RENDERFLO_PG_studio_cmf_toggle,
    RENDERFLO_PG_light_state,
    RENDERFLO_PG_hdri_pin,
    RENDERFLO_PG_studio_item,
    RENDERFLO_OT_sync_cmf_matrix,
    RENDERFLO_OT_clone_active_material,
    RENDERFLO_OT_toggle_render_preview,
    RENDERFLO_OT_add_curved_backdrop,
    RENDERFLO_OT_bootstrap_cad_kernel,
    RENDERFLO_OT_import_cad,
    RENDERFLO_OT_toggle_studio_light,
    RENDERFLO_OT_remove_studio_light,
    RENDERFLO_OT_place_highlight_modal,
    RENDERFLO_OT_place_hdri_pin_modal,
    RENDERFLO_OT_interactive_hdri_canvas,
    RENDERFLO_OT_load_hdri_image,
    RENDERFLO_OT_clear_hdri_image,
    RENDERFLO_OT_add_hdri_pin,
    RENDERFLO_OT_remove_hdri_pin,
    RENDERFLO_OT_duplicate_hdri_pin,
    RENDERFLO_OT_refresh_hdri_preview,
    RENDERFLO_OT_snap_shadow_floor,
    RENDERFLO_OT_add_studio,
    RENDERFLO_OT_make_unique_camera,
    RENDERFLO_OT_save_new_cmf,
    RENDERFLO_OT_update_active_cmf,
    RENDERFLO_OT_spawn_studio_light,
    RENDERFLO_OT_update_studio,
    RENDERFLO_OT_activate_studio,
    RENDERFLO_OT_remove_studio,
    RENDERFLO_OT_select_target,
    RENDERFLO_OT_activate_gpu_now,
    RENDERFLO_OT_cancel_batch_render,
    RENDERFLO_OT_batch_render,
    RENDERFLO_UL_studio_list,
    RENDERFLO_PT_main_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import_cad)

    bpy.types.Scene.rf_studios = bpy.props.CollectionProperty(type=RENDERFLO_PG_studio_item)
    bpy.types.Scene.rf_cmf_presets = bpy.props.CollectionProperty(type=RENDERFLO_PG_cmf_preset)
    bpy.types.Scene.rf_studio_index = bpy.props.IntProperty(
        name="Active Studio Index",
        default=0,
        update=on_active_studio_index_change
    )

    # Collapsible Section Properties (HardOps / Pro-Addon Clean Navigation)
    bpy.types.Scene.rf_fold_cad = bpy.props.BoolProperty(name="CAD Engine", default=False)
    bpy.types.Scene.rf_fold_new_studio = bpy.props.BoolProperty(name="New Studio Defaults", default=False)
    bpy.types.Scene.rf_fold_format = bpy.props.BoolProperty(name="Format & Aspect", default=True)
    bpy.types.Scene.rf_fold_camera = bpy.props.BoolProperty(name="Studio Camera", default=True)
    bpy.types.Scene.rf_fold_cmf = bpy.props.BoolProperty(name="CMF Variations", default=True)
    bpy.types.Scene.rf_fold_lighting = bpy.props.BoolProperty(name="Lighting Rig", default=True)
    bpy.types.Scene.rf_fold_env = bpy.props.BoolProperty(name="Environment & Backdrop", default=False)
    bpy.types.Scene.rf_fold_gpu = bpy.props.BoolProperty(name="GPU & Render Settings", default=False)

    bpy.types.Scene.rf_studio_new_cam_mode = bpy.props.EnumProperty(
        name="New Studio Camera",
        items=[
            ('LINK_CURRENT', "Link Current Camera (Shared)", "Use the exact same Camera object as the current Studio"),
            ('NEW_COPY', "Spawn New Camera (Copy Angle)", "Create a new independent Camera starting at the current camera's angle"),
            ('NEW_VIEW', "Spawn New Camera (From 3D View)", "Create a new independent Camera matching your current 3D Viewport angle"),
        ],
        default='LINK_CURRENT'
    )
    bpy.types.Scene.rf_studio_clone_lights = bpy.props.BoolProperty(name="Clone Current Studio Lights", default=False)
    bpy.types.Scene.rf_auto_save_studios = bpy.props.BoolProperty(
        name="Live Auto-Save Studios",
        description="Continuously save changes to camera and lights automatically into the active Studio",
        default=True
    )

    bpy.types.Scene.rf_force_gpu = bpy.props.BoolProperty(
        name="Force GPU Compute",
        description="Configure Cycles to use dedicated GPU (OptiX / CUDA / HIP / Metal)",
        default=True,
        update=update_global_render_settings
    )
    bpy.types.Scene.rf_render_samples = bpy.props.IntProperty(
        name="Render Samples",
        description="Cycles sample count for final Studio renders",
        default=256,
        min=1,
        max=65536,
        update=update_global_render_settings
    )
    bpy.types.Scene.rf_viewport_samples = bpy.props.IntProperty(
        name="Viewport Samples",
        description="Cycles sample count for 3D Viewport preview",
        default=64,
        min=1,
        max=4096,
        update=update_global_render_settings
    )
    bpy.types.Scene.rf_use_denoiser = bpy.props.BoolProperty(
        name="Use Denoiser",
        description="Enable Cycles AI Denoising for clean studio renders",
        default=True,
        update=update_global_render_settings
    )
    bpy.types.Scene.rf_noise_threshold = bpy.props.FloatProperty(
        name="Adaptive Noise Limit",
        description="Stop sampling pixels once they reach this noise threshold",
        default=0.01,
        min=0.0001,
        max=1.0,
        update=update_global_render_settings
    )

    bpy.types.Scene.rf_is_batch_rendering = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.rf_batch_progress = bpy.props.FloatProperty(default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE')
    bpy.types.Scene.rf_batch_status_text = bpy.props.StringProperty(default="")

    if renderflo_auto_save_handler not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(renderflo_auto_save_handler)

def unregister():
    if renderflo_auto_save_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(renderflo_auto_save_handler)

    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import_cad)
    for prop in (
        "rf_fold_gpu", "rf_fold_env", "rf_fold_lighting", "rf_fold_cmf",
        "rf_fold_camera", "rf_fold_format", "rf_fold_new_studio", "rf_fold_cad",
        "rf_batch_status_text", "rf_batch_progress", "rf_is_batch_rendering",
        "rf_noise_threshold", "rf_use_denoiser", "rf_viewport_samples",
        "rf_render_samples", "rf_force_gpu", "rf_auto_save_studios",
        "rf_studio_clone_lights", "rf_studio_new_cam_mode", "rf_studio_index",
        "rf_cmf_presets", "rf_studios"
    ):
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

if __name__ == "__main__":
    register()