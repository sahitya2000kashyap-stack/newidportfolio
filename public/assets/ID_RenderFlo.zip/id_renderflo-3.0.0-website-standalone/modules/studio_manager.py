# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.0.0 — Studio Manager & Staging Engine.
Multi-Studio snapshots, Camera Framing & Aspect Ratios, Live Auto-Save,
Studio Lock, and Floor/Backdrop Staging.
"""

import bpy
import math
from mathutils import Vector

from ..state import (
    MASTER_LIGHT_COLL,
    MASTER_CAM_COLL,
    MASTER_CUTAWAY_COLL,
    TARGET_EMPTY_NAME,
    GROUND_PLANE_NAME,
    BACKDROP_OBJ_NAME,
    DOME_VISUALIZER_OBJ,
    DOME_PIN_PREFIX,
    CUTAWAY_BOX_NAME,
    ASPECT_PRESETS,
    is_internal_update,
    internal_update_guard,
)


# ------------------------------------------------------------------------
# Studio Scene Collections & Cameras
# ------------------------------------------------------------------------

def ensure_collection(scene, coll_name):
    coll = bpy.data.collections.get(coll_name)
    if not coll:
        coll = bpy.data.collections.new(coll_name)
        scene.collection.children.link(coll)
    elif coll.name not in scene.collection.children:
        try:
            scene.collection.children.link(coll)
        except Exception:
            pass
    return coll


def ensure_studio_light_collection(context, studio):
    master_coll = ensure_collection(context.scene, MASTER_LIGHT_COLL)
    if studio.light_collection_name:
        sub_coll = bpy.data.collections.get(studio.light_collection_name)
        if sub_coll:
            return sub_coll

    coll_name = f"Lights_{studio.name}"
    sub_coll = bpy.data.collections.get(coll_name)
    if not sub_coll:
        sub_coll = bpy.data.collections.new(coll_name)
    if sub_coll.name not in master_coll.children:
        try:
            master_coll.children.link(sub_coll)
        except Exception:
            pass
    studio.light_collection_name = sub_coll.name
    return sub_coll


def create_camera_for_studio(context, studio_name, match_viewport=True):
    scene = context.scene
    cam_coll = ensure_collection(scene, MASTER_CAM_COLL)

    cam_data = bpy.data.cameras.new(name=f"Cam_{studio_name}")
    cam_data.lens = 85.0
    cam_data.passepartout_alpha = 0.85

    cam_obj = bpy.data.objects.new(name=f"Cam_{studio_name}", object_data=cam_data)
    cam_coll.objects.link(cam_obj)

    placed = False
    if scene.camera and not match_viewport:
        cam_obj.matrix_world = scene.camera.matrix_world.copy()
        if scene.camera.data and hasattr(scene.camera.data, "lens"):
            cam_data.lens = scene.camera.data.lens
        placed = True

    if not placed and context.screen:
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D' and space.region_3d:
                        cam_obj.matrix_world = space.region_3d.view_matrix.inverted()
                        placed = True
                        break
                if placed:
                    break

    if not placed:
        cam_obj.location = (0.0, -3.5, 1.5)
        cam_obj.rotation_euler = (math.radians(70.0), 0.0, 0.0)

    scene.camera = cam_obj
    return cam_obj


def ensure_light_target(context):
    target = bpy.data.objects.get(TARGET_EMPTY_NAME)
    if not target:
        target = bpy.data.objects.new(TARGET_EMPTY_NAME, None)
        target.empty_display_type = 'SPHERE'
        target.empty_display_size = 0.25
        target.location = (0.0, 0.0, 0.0)
        master_coll = ensure_collection(context.scene, MASTER_LIGHT_COLL)
        master_coll.objects.link(target)
    return target


def switch_exclusive_studio_lights(context, active_studio):
    scene = context.scene
    active_coll_name = active_studio.light_collection_name
    for s in scene.rf_studios:
        if s.light_collection_name:
            coll = bpy.data.collections.get(s.light_collection_name)
            if coll:
                is_current = (coll.name == active_coll_name)
                coll.hide_viewport = not is_current
                coll.hide_render = not is_current


# ------------------------------------------------------------------------
# Aspect Ratio & Framing Logic
# ------------------------------------------------------------------------

def update_studio_aspect_ratio(self, context):
    if is_internal_update():
        return
    with internal_update_guard():
        if self.aspect_preset != 'CUSTOM':
            for code, _, _, w, h in ASPECT_PRESETS:
                if code == self.aspect_preset:
                    base = self.base_resolution
                    if w >= h:
                        self.res_x = base
                        self.res_y = int(round(base * (h / w)))
                    else:
                        self.res_y = base
                        self.res_x = int(round(base * (w / h)))
                    break

        if context and context.scene:
            scene = context.scene
            if 0 <= scene.rf_studio_index < len(scene.rf_studios):
                if scene.rf_studios[scene.rf_studio_index] == self and self.use_resolution:
                    scene.render.resolution_x = self.res_x
                    scene.render.resolution_y = self.res_y
                    scene.render.resolution_percentage = self.res_scale
                    if scene.camera and scene.camera.data:
                        scene.camera.data.sensor_fit = 'VERTICAL' if (self.res_y > self.res_x) else 'HORIZONTAL'


def on_studio_camera_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    if self.camera_obj and self.camera_obj.type == 'CAMERA':
        context.scene.camera = self.camera_obj


def on_studio_image_style_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    if self.use_image_style:
        apply_image_style_to_scene(context.scene, self)


def apply_image_style_to_scene(scene, studio):
    scene.view_settings.exposure = studio.exposure
    if hasattr(studio, "contrast") and hasattr(scene.view_settings, "look"):
        try:
            scene.view_settings.look = studio.contrast
        except Exception:
            pass
    scene.render.film_transparent = studio.film_transparent
    if studio.film_transparent:
        scene.render.image_settings.file_format = 'PNG'
        scene.render.image_settings.color_mode = 'RGBA'


def on_studio_lock_change(self, context):
    if not context or not context.scene:
        return
    if self.camera_obj:
        for i in range(3):
            self.camera_obj.lock_location[i] = self.is_locked
            self.camera_obj.lock_rotation[i] = self.is_locked
            self.camera_obj.lock_scale[i] = self.is_locked

    if self.light_collection_name:
        coll = bpy.data.collections.get(self.light_collection_name)
        if coll:
            for obj in coll.objects:
                if obj.type == 'LIGHT':
                    for i in range(3):
                        obj.lock_location[i] = self.is_locked
                        obj.lock_rotation[i] = self.is_locked
                        obj.lock_scale[i] = self.is_locked


def get_all_layer_collections(layer_coll):
    """Traverse all nested layer collections in the view layer."""
    yield layer_coll
    for child in layer_coll.children:
        yield from get_all_layer_collections(child)


def apply_collection_states(context, studio):
    """Apply collection visibility / isolation (Model Sets)."""
    state_map = {item.name: item for item in studio.collection_states}
    if context and hasattr(context, "view_layer") and context.view_layer:
        root_layer_coll = context.view_layer.layer_collection
        for lc in get_all_layer_collections(root_layer_coll):
            if lc.collection.name in state_map:
                st = state_map[lc.collection.name]
                lc.exclude = st.hide_viewport
                lc.hide_viewport = False
                lc.collection.hide_viewport = False
                lc.collection.hide_render = st.hide_render
    else:
        for st in studio.collection_states:
            coll = bpy.data.collections.get(st.name)
            if coll:
                coll.hide_viewport = st.hide_viewport
                coll.hide_render = st.hide_render


def apply_object_transforms(studio):
    """Apply saved object positions / rotations (Exploded Views)."""
    for t_item in studio.object_transforms:
        obj = bpy.data.objects.get(t_item.object_name)
        if obj:
            obj.location = t_item.location
            obj.rotation_euler = t_item.rotation_euler
            obj.scale = t_item.scale


def on_studio_use_collections_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    scene = context.scene
    if 0 <= scene.rf_studio_index < len(scene.rf_studios) and scene.rf_studios[scene.rf_studio_index] == self:
        if self.use_collections:
            apply_collection_states(context, self)


def on_studio_use_transforms_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    scene = context.scene
    if 0 <= scene.rf_studio_index < len(scene.rf_studios) and scene.rf_studios[scene.rf_studio_index] == self:
        if self.use_transforms:
            capture_studio_state(context, self)


def on_active_studio_index_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    scene = context.scene
    if len(scene.rf_studios) == 0:
        return
    # Clamp index safely
    clamped_idx = max(0, min(scene.rf_studio_index, len(scene.rf_studios) - 1))
    if scene.rf_studio_index != clamped_idx:
        scene.rf_studio_index = clamped_idx
        return

    studio = scene.rf_studios[clamped_idx]
    from .cmf_materials import sync_studio_cmf_toggles
    sync_studio_cmf_toggles(scene, studio)

    # Sync ribbon dropdowns
    try:
        scene.rf_active_studio_enum = str(clamped_idx)
        scene.rf_active_aspect_preset_enum = studio.aspect_preset
        scene.rf_active_cmf_enum = studio.cmf_mode
    except Exception:
        pass


# ------------------------------------------------------------------------
# State Capture & Apply Pipelines
# ------------------------------------------------------------------------

def capture_studio_state(context, studio):
    if studio.is_locked:
        return

    with internal_update_guard():
        scene = context.scene
        ensure_studio_light_collection(context, studio)
        from .cmf_materials import sync_studio_cmf_toggles, record_materials_into_collection
        sync_studio_cmf_toggles(scene, studio)

        if scene.camera:
            studio.camera_obj = scene.camera
        if not studio.world_name:
            studio.world_name = scene.world.name if scene.world else f"World_{bpy.path.clean_name(studio.name)}"

        ignored_colls = {s.light_collection_name for s in scene.rf_studios if s.light_collection_name}
        ignored_colls.add(MASTER_LIGHT_COLL)
        ignored_colls.add(MASTER_CAM_COLL)
        ignored_colls.add(MASTER_CUTAWAY_COLL)

        studio.collection_states.clear()
        if context and hasattr(context, "view_layer") and context.view_layer:
            root_layer_coll = context.view_layer.layer_collection
            for lc in get_all_layer_collections(root_layer_coll):
                if lc == root_layer_coll or lc.collection.name in ignored_colls:
                    continue
                item = studio.collection_states.add()
                item.name = lc.collection.name
                item.hide_viewport = lc.exclude or lc.hide_viewport or lc.collection.hide_viewport
                item.hide_render = lc.collection.hide_render
        else:
            for coll in bpy.data.collections:
                if coll.name in ignored_colls:
                    continue
                item = studio.collection_states.add()
                item.name = coll.name
                item.hide_viewport = coll.hide_viewport
                item.hide_render = coll.hide_render

        # Only record into studio-specific material snapshot; do NOT overwrite global CMF presets
        record_materials_into_collection(scene, studio.object_materials)

        studio.object_transforms.clear()
        for obj in list(scene.objects):
            if (obj.type in {'MESH', 'CURVE', 'SURFACE', 'EMPTY'} and
                    obj.name not in {TARGET_EMPTY_NAME, GROUND_PLANE_NAME, BACKDROP_OBJ_NAME, DOME_VISUALIZER_OBJ, CUTAWAY_BOX_NAME} and
                    not obj.name.startswith(DOME_PIN_PREFIX)):
                t_item = studio.object_transforms.add()
                t_item.object_name = obj.name
                t_item.location = obj.location
                t_item.rotation_euler = obj.rotation_euler
                t_item.scale = obj.scale

        studio.light_states.clear()
        for obj in list(scene.objects):
            if obj.type == 'LIGHT':
                l_item = studio.light_states.add()
                l_item.light_obj_name = obj.name
                l_item.location = obj.location
                l_item.rotation_euler = obj.rotation_euler
                l_item.scale = obj.scale
                l_item.energy = obj.data.energy
                l_item.color = obj.data.color
                if hasattr(obj.data, "size"):
                    l_item.size = obj.data.size
                l_item.hide_viewport = obj.hide_get()
                l_item.hide_render = obj.hide_render


def apply_studio_state(context, studio):
    with internal_update_guard():
        scene = context.scene
        from .cmf_materials import sync_studio_cmf_toggles, apply_cmf_to_scene
        from .lighting_hdri import rebuild_studio_hdri_nodes, update_studio_dome_visualizer
        from .batch_queue import apply_render_quality_settings

        sync_studio_cmf_toggles(scene, studio)

        if studio.use_camera and studio.camera_obj and studio.camera_obj.type == 'CAMERA':
            scene.camera = studio.camera_obj

        if studio.use_resolution:
            scene.render.resolution_x = studio.res_x
            scene.render.resolution_y = studio.res_y
            scene.render.resolution_percentage = studio.res_scale
            if scene.camera and scene.camera.data:
                scene.camera.data.sensor_fit = 'VERTICAL' if (studio.res_y > studio.res_x) else 'HORIZONTAL'

        if studio.use_lights:
            world = None
            if studio.world_name:
                world = bpy.data.worlds.get(studio.world_name)
            if not world:
                world_name = f"World_{bpy.path.clean_name(studio.name)}"
                world = bpy.data.worlds.get(world_name)
                if not world:
                    world = bpy.data.worlds.new(world_name)
                studio.world_name = world.name
            scene.world = world

            rebuild_studio_hdri_nodes(studio, scene, force=True)
            update_studio_dome_visualizer(studio, context)
            switch_exclusive_studio_lights(context, studio)

            for l_item in studio.light_states:
                obj = bpy.data.objects.get(l_item.light_obj_name)
                if obj and obj.type == 'LIGHT':
                    obj.location = l_item.location
                    obj.rotation_euler = l_item.rotation_euler
                    obj.scale = l_item.scale
                    obj.data.energy = l_item.energy
                    obj.data.color = l_item.color
                    if hasattr(obj.data, "size"):
                        obj.data.size = l_item.size
                    obj.hide_set(l_item.hide_viewport)
                    obj.hide_render = l_item.hide_render

        if studio.use_collections:
            apply_collection_states(context, studio)

        if studio.use_transforms:
            apply_object_transforms(studio)

        apply_cmf_to_scene(scene, studio)

        if studio.use_image_style:
            apply_image_style_to_scene(scene, studio)
        if getattr(studio, "viewport_show_dome", False) and not studio.film_transparent:
            scene.render.film_transparent = False

        target_samples = studio.studio_samples if studio.use_custom_samples else scene.rf_render_samples
        apply_render_quality_settings(scene, target_samples)

        try:
            scene.rf_active_studio_enum = str(scene.rf_studio_index)
            scene.rf_active_aspect_preset_enum = studio.aspect_preset
            scene.rf_active_cmf_enum = studio.cmf_mode
        except Exception:
            pass


# ------------------------------------------------------------------------
# Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_toggle_render_preview(bpy.types.Operator):
    bl_idname = "renderflo.toggle_render_preview"
    bl_label = "Toggle Render Preview"

    def execute(self, context):
        from .batch_queue import configure_cycles_gpu
        configure_cycles_gpu(context.scene, force_gpu=context.scene.rf_force_gpu)
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.shading.type = 'SOLID' if space.shading.type == 'RENDERED' else 'RENDERED'
        return {'FINISHED'}


class RENDERFLO_OT_add_curved_backdrop(bpy.types.Operator):
    bl_idname = "renderflo.add_curved_backdrop"
    bl_label = "Add Studio Curved Backdrop"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        target = ensure_light_target(context)
        b_obj = bpy.data.objects.get(BACKDROP_OBJ_NAME)

        if not b_obj:
            mesh = bpy.data.meshes.new(BACKDROP_OBJ_NAME)
            w, d, h = 10.0, 6.0, 5.0
            verts = [(-w, -d, 0.0), (w, -d, 0.0), (w, d * 0.5, 0.0), (-w, d * 0.5, 0.0), (-w, d * 0.5, h), (w, d * 0.5, h)]
            faces = [(0, 1, 2, 3), (3, 2, 5, 4)]
            mesh.from_pydata(verts, [], faces)
            mesh.update()

            b_obj = bpy.data.objects.new(BACKDROP_OBJ_NAME, mesh)
            scene.collection.objects.link(b_obj)

            bev = b_obj.modifiers.new(name="Bevel", type='BEVEL')
            bev.width = 2.5
            bev.segments = 16

            sub = b_obj.modifiers.new(name="Subsurf", type='SUBSURF')
            sub.levels = 1

            for p in mesh.polygons:
                p.use_smooth = True

            mat = bpy.data.materials.new(name="RenderFlo_Backdrop_Mat")
            mat.use_nodes = True
            bsdf = mat.node_tree.nodes.get("Principled BSDF")
            if bsdf:
                col_socket = bsdf.inputs.get("Base Color") or bsdf.inputs.get("Color")
                if col_socket:
                    col_socket.default_value = (0.85, 0.85, 0.85, 1.0)
                rough_socket = bsdf.inputs.get("Roughness")
                if rough_socket:
                    rough_socket.default_value = 0.6
            b_obj.data.materials.append(mat)

        b_obj.location = (target.location.x, target.location.y, 0.0)
        self.report({'INFO'}, "Created/Aligned Studio Backdrop")
        return {'FINISHED'}


class RENDERFLO_OT_snap_shadow_floor(bpy.types.Operator):
    bl_idname = "renderflo.snap_shadow_floor"
    bl_label = "Snap Shadow Catcher Floor to Product"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        min_z = None
        center_x, center_y = 0.0, 0.0
        mesh_count = 0

        depsgraph = context.evaluated_depsgraph_get()
        for obj in list(scene.objects):
            if obj.type == 'MESH' and obj.visible_get() and obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                eval_obj = obj.evaluated_get(depsgraph)
                for corner in eval_obj.bound_box:
                    pt = eval_obj.matrix_world @ Vector(corner)
                    if min_z is None or pt.z < min_z:
                        min_z = pt.z
                center_x += obj.matrix_world.translation.x
                center_y += obj.matrix_world.translation.y
                mesh_count += 1

        if min_z is None:
            min_z = 0.0
        if mesh_count > 0:
            center_x /= mesh_count
            center_y /= mesh_count

        floor_obj = bpy.data.objects.get(GROUND_PLANE_NAME)
        if not floor_obj:
            bpy.ops.mesh.primitive_plane_add(size=25.0, location=(center_x, center_y, min_z))
            floor_obj = context.active_object
            floor_obj.name = GROUND_PLANE_NAME
        else:
            floor_obj.location = (center_x, center_y, min_z)

        floor_obj.is_shadow_catcher = True
        floor_obj.display_type = 'WIRE'
        self.report({'INFO'}, f"Shadow Catcher Floor snapped to Z = {min_z:.3f}")
        return {'FINISHED'}


class RENDERFLO_OT_add_studio(bpy.types.Operator):
    bl_idname = "renderflo.add_studio"
    bl_label = "Create New Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        with internal_update_guard():
            scene = context.scene
            prev_studio = scene.rf_studios[scene.rf_studio_index] if (0 <= scene.rf_studio_index < len(scene.rf_studios)) else None

            if prev_studio and not prev_studio.is_locked and getattr(scene, "rf_auto_save_studios", True):
                capture_studio_state(context, prev_studio)

            from .cmf_materials import record_materials_into_collection, sync_studio_cmf_toggles

            if len(scene.rf_cmf_presets) == 0:
                first_cmf = scene.rf_cmf_presets.add()
                first_cmf.name = "Default"
                record_materials_into_collection(scene, first_cmf.object_materials)

            new_studio = scene.rf_studios.add()
            new_studio.name = f"Studio_{len(scene.rf_studios):02d}"
            new_studio.studio_samples = scene.rf_render_samples

            new_world_name = f"World_{new_studio.name}"
            new_world = bpy.data.worlds.new(new_world_name)
            new_studio.world_name = new_world.name

            if prev_studio:
                new_studio.aspect_preset = prev_studio.aspect_preset
                new_studio.base_resolution = prev_studio.base_resolution
                new_studio.res_x = prev_studio.res_x
                new_studio.res_y = prev_studio.res_y
                new_studio.res_scale = prev_studio.res_scale
                new_studio.exposure = prev_studio.exposure
                new_studio.contrast = getattr(prev_studio, "contrast", 'None')
                new_studio.film_transparent = prev_studio.film_transparent
                new_studio.use_collections = prev_studio.use_collections
                new_studio.use_transforms = prev_studio.use_transforms

                new_studio.use_hdri_dome = prev_studio.use_hdri_dome
                new_studio.hdri_base_color = prev_studio.hdri_base_color
                new_studio.hdri_base_energy = prev_studio.hdri_base_energy
                new_studio.hdri_rotation = prev_studio.hdri_rotation

                if scene.rf_studio_clone_lights:
                    for p in prev_studio.hdri_pins:
                        new_p = new_studio.hdri_pins.add()
                        new_p.name = p.name
                        new_p.enabled = p.enabled
                        new_p.pin_shape = p.pin_shape
                        new_p.azimuth = p.azimuth
                        new_p.elevation = p.elevation
                        new_p.radius = p.radius
                        new_p.aspect = p.aspect
                        new_p.rotation = p.rotation
                        new_p.falloff = p.falloff
                        new_p.energy = p.energy
                        new_p.color = p.color
                else:
                    p0 = new_studio.hdri_pins.add()
                    p0.name = "Key_Pin"
                    p0.azimuth = 45.0
                    p0.elevation = 35.0
                    p0.radius = 0.18
                    p0.falloff = 0.15
                    p0.energy = 15.0
                    p0.color = (1.0, 1.0, 1.0)
            else:
                new_studio.res_x = scene.render.resolution_x
                new_studio.res_y = scene.render.resolution_y
                new_studio.exposure = scene.view_settings.exposure
                new_studio.contrast = getattr(scene.view_settings, "look", 'None') or 'None'
                new_studio.film_transparent = scene.render.film_transparent

                p0 = new_studio.hdri_pins.add()
                p0.name = "Key_Pin"
                p0.azimuth = 45.0
                p0.elevation = 35.0
                p0.radius = 0.18
                p0.falloff = 0.15
                p0.energy = 15.0
                p0.color = (1.0, 1.0, 1.0)

            if scene.rf_studio_new_cam_mode == 'NEW_VIEW':
                new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=True)
            elif scene.rf_studio_new_cam_mode == 'NEW_COPY':
                new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=False)
            else:
                if prev_studio and prev_studio.camera_obj:
                    new_studio.camera_obj = prev_studio.camera_obj
                elif scene.camera:
                    new_studio.camera_obj = scene.camera
                else:
                    new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=True)

            new_light_coll = ensure_studio_light_collection(context, new_studio)
            if scene.rf_studio_clone_lights and prev_studio and prev_studio.light_collection_name:
                prev_coll = bpy.data.collections.get(prev_studio.light_collection_name)
                if prev_coll:
                    for obj in list(prev_coll.objects):
                        if obj.type == 'LIGHT':
                            new_obj = obj.copy()
                            new_obj.data = obj.data.copy()
                            new_obj.name = f"{new_studio.name}_{obj.name}"
                            new_light_coll.objects.link(new_obj)

            if prev_studio and prev_studio.cmf_mode:
                new_studio.cmf_mode = prev_studio.cmf_mode
            elif len(scene.rf_cmf_presets) > 0:
                new_studio.cmf_mode = scene.rf_cmf_presets[0].name
            else:
                new_studio.cmf_mode = "Default"

            for s in scene.rf_studios:
                sync_studio_cmf_toggles(scene, s)

            scene.rf_studio_index = len(scene.rf_studios) - 1
            scene.world = new_world
            switch_exclusive_studio_lights(context, new_studio)
            capture_studio_state(context, new_studio)
            apply_studio_state(context, new_studio)

        self.report({'INFO'}, f"ID RenderFlo: Created '{new_studio.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_make_unique_camera(bpy.types.Operator):
    bl_idname = "renderflo.make_unique_camera"
    bl_label = "Spawn Dedicated Camera for This Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            studio.camera_obj = create_camera_for_studio(context, studio.name, match_viewport=False)
        return {'FINISHED'}


class RENDERFLO_OT_update_studio(bpy.types.Operator):
    bl_idname = "renderflo.update_studio"
    bl_label = "Update Studio State"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        if 0 <= self.index < len(scene.rf_studios):
            studio = scene.rf_studios[self.index]
            from .cmf_materials import sync_studio_cmf_toggles
            sync_studio_cmf_toggles(scene, studio)
            capture_studio_state(context, studio)
            self.report({'INFO'}, f"Saved state for '{studio.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_activate_studio(bpy.types.Operator):
    bl_idname = "renderflo.activate_studio"
    bl_label = "Activate Studio"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        prev_studio = None
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            prev_studio = scene.rf_studios[scene.rf_studio_index]
            if getattr(scene, "rf_auto_save_studios", True) and not prev_studio.is_locked:
                capture_studio_state(context, prev_studio)

        if 0 <= self.index < len(scene.rf_studios):
            studio = scene.rf_studios[self.index]
            scene.rf_studio_index = self.index
            from .cmf_materials import sync_studio_cmf_toggles
            sync_studio_cmf_toggles(scene, studio)

            # If switching away from an exploded studio to a normal studio, restore rest positions
            if prev_studio and prev_studio.use_transforms and not studio.use_transforms:
                if len(studio.object_transforms) > 0:
                    apply_object_transforms(studio)

            apply_studio_state(context, studio)
        return {'FINISHED'}


class RENDERFLO_OT_capture_studio_transforms(bpy.types.Operator):
    bl_idname = "renderflo.capture_studio_transforms"
    bl_label = "Store Current Positions"
    bl_description = "Capture current 3D component positions and rotations into this studio snapshot"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            with internal_update_guard():
                studio.use_transforms = True
            capture_studio_state(context, studio)
            self.report({'INFO'}, f"ID RenderFlo: Saved exploded part positions for '{studio.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_reset_studio_transforms(bpy.types.Operator):
    bl_idname = "renderflo.reset_studio_transforms"
    bl_label = "Reset to Assembled"
    bl_description = "Restore all product components back to their original assembled positions"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        rest_map = {}
        if len(scene.rf_studios) > 0 and len(scene.rf_studios[0].object_transforms) > 0:
            for t in scene.rf_studios[0].object_transforms:
                rest_map[t.object_name] = (t.location, t.rotation_euler, t.scale)

        from ..state import REST_LOCATION_PROP
        from .flex_deform import get_product_objects
        objs = get_product_objects(scene)
        for obj in objs:
            if obj.name in rest_map:
                loc, rot, scl = rest_map[obj.name]
                obj.location = loc.copy() if hasattr(loc, "copy") else loc
                obj.rotation_euler = rot.copy() if hasattr(rot, "copy") else rot
                obj.scale = scl.copy() if hasattr(scl, "copy") else scl
            elif REST_LOCATION_PROP in obj:
                try:
                    obj.location = Vector(obj[REST_LOCATION_PROP])
                except Exception:
                    pass

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            capture_studio_state(context, studio)

        self.report({'INFO'}, "ID RenderFlo: Reset parts to assembled positions")
        return {'FINISHED'}


class RENDERFLO_OT_remove_studio(bpy.types.Operator):
    bl_idname = "renderflo.remove_studio"
    bl_label = "Remove Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        idx = scene.rf_studio_index
        if 0 <= idx < len(scene.rf_studios):
            studio = scene.rf_studios[idx]
            if studio.light_collection_name:
                coll = bpy.data.collections.get(studio.light_collection_name)
                if coll:
                    for obj in list(coll.objects):
                        bpy.data.objects.remove(obj, do_unlink=True)
                    bpy.data.collections.remove(coll)
            if studio.world_name:
                w_obj = bpy.data.worlds.get(studio.world_name)
                if w_obj:
                    bpy.data.worlds.remove(w_obj)
            scene.rf_studios.remove(idx)
            scene.rf_studio_index = max(0, min(idx, len(scene.rf_studios) - 1))
            if len(scene.rf_studios) > 0:
                apply_studio_state(context, scene.rf_studios[scene.rf_studio_index])
        return {'FINISHED'}


class RENDERFLO_OT_select_target(bpy.types.Operator):
    bl_idname = "renderflo.select_target"
    bl_label = "Select Light Target"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        target = ensure_light_target(context)
        for o in context.selected_objects:
            o.select_set(False)
        target.select_set(True)
        context.view_layer.objects.active = target
        return {'FINISHED'}


class RENDERFLO_OT_activate_gpu_now(bpy.types.Operator):
    bl_idname = "renderflo.activate_gpu_now"
    bl_label = "Verify & Activate GPU Now"
    bl_options = {'REGISTER'}

    def execute(self, context):
        from .batch_queue import configure_cycles_gpu, apply_render_quality_settings
        scene = context.scene
        hw_label = configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)
        apply_render_quality_settings(scene, scene.rf_render_samples)
        self.report({'INFO'}, f"ID RenderFlo: Render device set to {hw_label} @ {scene.rf_render_samples} Samples")
        return {'FINISHED'}


studio_classes = (
    RENDERFLO_OT_toggle_render_preview,
    RENDERFLO_OT_add_curved_backdrop,
    RENDERFLO_OT_snap_shadow_floor,
    RENDERFLO_OT_add_studio,
    RENDERFLO_OT_make_unique_camera,
    RENDERFLO_OT_update_studio,
    RENDERFLO_OT_activate_studio,
    RENDERFLO_OT_capture_studio_transforms,
    RENDERFLO_OT_reset_studio_transforms,
    RENDERFLO_OT_remove_studio,
    RENDERFLO_OT_select_target,
    RENDERFLO_OT_activate_gpu_now,
)


def register():
    for cls in studio_classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(studio_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

