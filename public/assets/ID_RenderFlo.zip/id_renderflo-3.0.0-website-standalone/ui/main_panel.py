# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.0.0 — Zero-Scroll Tabbed N-Panel Inspector & Floating Studio Dashboard.
Tabbed navigation across Studios, CAD Bridge, CMF, Lighting, Decals/FX, and Batch Queue.
Wide Floating Studio Dashboard modal triggered via Alt+Shift+R.
"""

import bpy

from ..state import is_internal_update, DECAL_PREFIX


# ------------------------------------------------------------------------
# UI List Component
# ------------------------------------------------------------------------

class RENDERFLO_UL_studio_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "render_enabled", text="")
            row.prop(item, "name", text="", emboss=False, icon='RENDERLAYERS')

            sub = row.row(align=True)
            sub.scale_x = 0.85
            aspect_tag = item.aspect_preset.replace('_', ':') if item.aspect_preset != 'CUSTOM' else f"{item.res_x}x{item.res_y}"
            cam_label = item.camera_obj.name if item.camera_obj else "NoCam"
            sample_tag = f" | {item.studio_samples}s" if item.use_custom_samples else ""
            exp_tag = " | ExpPos" if item.use_transforms else ""
            sub.label(text=f"[{aspect_tag} | {cam_label}{sample_tag}{exp_tag}]")

            lock_icon = 'LOCKED' if item.is_locked else 'UNLOCKED'
            row.prop(item, "is_locked", text="", icon=lock_icon, emboss=False)

            op_act = row.operator("renderflo.activate_studio", text="", icon='PLAY')
            op_act.index = index

            upd_sub = row.row(align=True)
            upd_sub.enabled = not item.is_locked
            op_upd = upd_sub.operator("renderflo.update_studio", text="", icon='FILE_REFRESH')
            op_upd.index = index


# ------------------------------------------------------------------------
# Zero-Scroll Tabbed N-Panel Inspector
# ------------------------------------------------------------------------

class RENDERFLO_PT_main_panel(bpy.types.Panel):
    bl_label = "ID RenderFlo Suite"
    bl_idname = "RENDERFLO_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ID RenderFlo'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Top Bar: Dashboard Launcher
        top_row = layout.row(align=True)
        top_row.scale_y = 1.15
        top_row.operator("renderflo.studio_dashboard", icon='WINDOW', text="Studio Dashboard (Alt+Shift+R)")

        # Tabbed Dock (6 Work-Order Menus: CAD -> Studio -> Lighting -> CMF -> Decals -> Render & DXF)
        dock_box = layout.box()
        dock_col = dock_box.column(align=True)

        row1 = dock_col.row(align=True)
        row1.scale_y = 1.2
        row1.prop_enum(scene, "rf_ui_tab", 'CAD', text="CAD Bridge", icon='IMPORT')
        row1.prop_enum(scene, "rf_ui_tab", 'STUDIOS', text="Studio", icon='CAMERA_DATA')

        row2 = dock_col.row(align=True)
        row2.scale_y = 1.2
        row2.prop_enum(scene, "rf_ui_tab", 'LIGHTING', text="Lighting", icon='LIGHT_SUN')
        row2.prop_enum(scene, "rf_ui_tab", 'CMF', text="CMF", icon='MATERIAL')

        row3 = dock_col.row(align=True)
        row3.scale_y = 1.1
        row3.prop_enum(scene, "rf_ui_tab", 'DECALS', text="Decals & FX", icon='MOD_BOOLEAN')
        row3.prop_enum(scene, "rf_ui_tab", 'RENDER', text="Render & DXF", icon='RENDER_STILL')

        active_studio = scene.rf_studios[scene.rf_studio_index] if (0 <= scene.rf_studio_index < len(scene.rf_studios)) else None

        # ====================================================================
        # TAB 1: CAD BRIDGE (IMPORT & HOT-RELOAD)
        # ====================================================================
        if scene.rf_ui_tab == 'CAD':
            from ..modules.cad_bridge import is_cascadio_ready, is_rhino_ready, is_cad_engine_ready

            occ_ok = is_cascadio_ready()
            rhino_ok = is_rhino_ready()
            all_ok = occ_ok and rhino_ok

            # ----------------------------------------------------------------
            # CAD ENGINE STATUS & INSTALLER BOX (ALWAYS DISPLAYED)
            # ----------------------------------------------------------------
            cad_box = layout.box()
            if not all_ok:
                cad_box.alert = True
                hdr = cad_box.row(align=True)
                hdr.label(text="CAD Engine Setup Required", icon='ERROR')
                hdr.operator("renderflo.recheck_cad_engine", text="", icon='FILE_REFRESH')

                col = cad_box.column(align=True)
                r_occ = col.row()
                r_occ.label(text="• OpenCASCADE (STEP / IGES):", icon='CHECKMARK' if occ_ok else 'CANCEL')
                r_occ.label(text="Active" if occ_ok else "Not Installed")

                r_rh = col.row()
                r_rh.label(text="• Rhino3DM (.3dm geometry):", icon='CHECKMARK' if rhino_ok else 'CANCEL')
                r_rh.label(text="Active" if rhino_ok else "Not Installed")

                b_row = cad_box.row(align=True)
                b_row.scale_y = 1.35
                op_inst = b_row.operator("renderflo.bootstrap_cad_kernel", text="Install CAD Engines (Auto Download)", icon='IMPORT')
                op_inst.package = 'ALL'

                b_sub = cad_box.row(align=True)
                b_sub.operator("renderflo.browse_cad_wheel", text="Install from Offline Wheel / Archive...", icon='FILE_FOLDER')
            else:
                hdr = cad_box.row(align=True)
                hdr.label(text="Native CAD Engine Active (OCC & Rhino)", icon='CHECKMARK')
                hdr.operator("renderflo.recheck_cad_engine", text="", icon='FILE_REFRESH')

                sub_row = cad_box.row(align=True)
                op_reinst = sub_row.operator("renderflo.bootstrap_cad_kernel", text="Reinstall Engines", icon='IMPORT')
                op_reinst.package = 'ALL'
                sub_row.operator("renderflo.browse_cad_wheel", text="Offline Wheel...", icon='FILE_FOLDER')

            # ----------------------------------------------------------------
            # IMPORT & HOT-RELOAD ACTIONS
            # ----------------------------------------------------------------
            c_col = cad_box.column(align=True)
            imp_row = c_col.row(align=True)
            imp_row.scale_y = 1.3
            imp_row.operator("renderflo.import_cad", icon='IMPORT', text="Import CAD (.STEP / .3DM)")

            hot_row = c_col.row(align=True)
            hot_row.scale_y = 1.2
            hot_row.operator("renderflo.cad_hot_reload", icon='FILE_REFRESH', text="1-Click CAD Hot-Reload")

            if scene.rf_last_cad_filepath:
                info_box = cad_box.box()
                info_box.label(text="Active Assembly:", icon='FILE_CACHE')
                import os
                info_box.label(text=f"File: {os.path.basename(scene.rf_last_cad_filepath)}")
                info_box.label(text=f"Collection: {scene.rf_last_cad_collection}")

        # ====================================================================
        # TAB 2: STUDIOS & CAMERA FRAMING
        # ====================================================================
        elif scene.rf_ui_tab == 'STUDIOS':
            create_box = layout.box()
            col = create_box.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.25
            row.operator("renderflo.add_studio", icon='ADD', text="Create New Studio")

            ns_header = col.row(align=True)
            ns_icon = "DOWNARROW_HLT" if scene.rf_fold_new_studio else "RIGHTARROW"
            ns_header.prop(scene, "rf_fold_new_studio", text="New Studio Defaults & Auto-Save", icon=ns_icon, emboss=False)
            if scene.rf_fold_new_studio:
                col.prop(scene, "rf_studio_new_cam_mode", text="Cam")
                col.prop(scene, "rf_studio_clone_lights", text="Clone Current Lights")
                col.prop(scene, "rf_auto_save_studios", text="Live Auto-Save (Cam & Lights)")

            # Studio List
            row = layout.row()
            row.template_list("RENDERFLO_UL_studio_list", "", scene, "rf_studios", scene, "rf_studio_index", rows=4)

            col = row.column(align=True)
            col.operator("renderflo.remove_studio", icon='REMOVE', text="")
            col.separator()
            col.operator("renderflo.snap_shadow_floor", icon='MESH_PLANE', text="")

            if active_studio:
                # Aspect Ratio & Format
                res_box = layout.box()
                res_header = res_box.row(align=True)
                res_icon = "DOWNARROW_HLT" if scene.rf_fold_format else "RIGHTARROW"
                res_header.prop(scene, "rf_fold_format", text=f"Format & Aspect ({active_studio.res_x}x{active_studio.res_y})", icon=res_icon, emboss=False)
                res_header.prop(active_studio, "use_resolution", text="")

                if scene.rf_fold_format and active_studio.use_resolution:
                    res_col = res_box.column(align=True)
                    res_col.prop(active_studio, "aspect_preset", text="Ratio")
                    if active_studio.aspect_preset == 'CUSTOM':
                        xy_row = res_col.row(align=True)
                        xy_row.prop(active_studio, "res_x", text="W")
                        xy_row.prop(active_studio, "res_y", text="H")
                    else:
                        res_col.prop(active_studio, "base_resolution", text="Long Edge (px)")
                    res_col.prop(active_studio, "res_scale", text="Render Scale")

                # Camera
                cam_box = layout.box()
                cam_header = cam_box.row(align=True)
                cam_icon = "DOWNARROW_HLT" if scene.rf_fold_camera else "RIGHTARROW"
                cam_name = active_studio.camera_obj.name if active_studio.camera_obj else "No Camera"
                cam_header.prop(scene, "rf_fold_camera", text=f"Camera ({cam_name})", icon=cam_icon, emboss=False)
                cam_header.prop(active_studio, "use_camera", text="")

                if scene.rf_fold_camera and active_studio.use_camera:
                    cam_row = cam_box.row(align=True)
                    cam_row.prop(active_studio, "camera_obj", text="")
                    cam_row.operator("renderflo.make_unique_camera", text="", icon='DUPLICATE')

                    if active_studio.camera_obj and active_studio.camera_obj.type == 'CAMERA':
                        cam_data = active_studio.camera_obj.data
                        cam_settings = cam_box.row(align=True)
                        cam_settings.prop(cam_data, "lens", text="Focal (mm)")
                        if context.space_data and context.space_data.type == 'VIEW_3D':
                            cam_settings.prop(context.space_data, "lock_camera", text="Lock View", icon='LOCKVIEW_ON')

                # Custom Render Samples for Studio
                samp_box = layout.box()
                s_header = samp_box.row(align=True)
                s_header.prop(active_studio, "use_custom_samples", text="Custom Samples for Studio", icon='RESTRICT_RENDER_OFF')
                if active_studio.use_custom_samples:
                    s_col = samp_box.column(align=True)
                    s_col.prop(active_studio, "studio_samples", text="Samples")
                else:
                    samp_box.label(text=f"Using Global Quality ({scene.rf_render_samples} samples)", icon='INFO')

                # Model Sets & Exploded Positions
                part_box = layout.box()
                part_box.label(text="Model Sets & Exploded Positions", icon='OBJECT_DATAMODE')
                toggle_row = part_box.row(align=True)
                toggle_row.scale_y = 1.15
                toggle_row.prop(active_studio, "use_collections", text="Model Sets", toggle=True, icon='OUTLINER_COLLECTION')
                toggle_row.prop(active_studio, "use_transforms", text="Exploded / Part Pos", toggle=True, icon='ARROW_LEFTRIGHT')

                if active_studio.use_transforms:
                    pos_row = part_box.row(align=True)
                    pos_row.operator("renderflo.capture_studio_transforms", text="Store Current Positions", icon='FILE_REFRESH')
                    pos_row.operator("renderflo.reset_studio_transforms", text="Reset to Assembled", icon='LOOP_BACK')

                # Staging: Floor & Backdrop
                stg_box = layout.box()
                stg_box.label(text="Environment & Staging", icon='SCENE_DATA')
                env_row = stg_box.row(align=True)
                env_row.prop(active_studio, "exposure", text="Exposure")
                env_row.prop(active_studio, "contrast", text="Contrast")
                env_row.prop(active_studio, "film_transparent", text="Transparent PNG")
                floor_row = stg_box.row(align=True)
                floor_row.operator("renderflo.snap_shadow_floor", icon='MESH_PLANE', text="Floor Shadow Catcher")
                floor_row.operator("renderflo.add_curved_backdrop", icon='MOD_BEVEL', text="Curved Backdrop")

        # ====================================================================
        # TAB 3: LIGHTING RIG (HDRI Dome & Physical Softboxes)
        # ====================================================================
        elif scene.rf_ui_tab == 'LIGHTING':
            if active_studio:
                if active_studio.is_locked:
                    lock_bar = layout.row(align=True)
                    lock_bar.alert = True
                    lock_bar.prop(active_studio, "is_locked", text="Studio Padlock Active — Click to Unlock", icon='LOCKED')

                tab_row = layout.row(align=True)
                tab_row.prop(active_studio, "lighting_tab", expand=True)

                if active_studio.lighting_tab == 'HDRI':
                    # PROCEDURAL HDRI DOME & PINS
                    hdri_box = layout.box()
                    h_header = hdri_box.row(align=True)
                    h_header.prop(active_studio, "use_hdri_dome", text="Procedural HDRI Dome", icon='WORLD')
                    h_header.operator("renderflo.add_hdri_pin", text="+ Add Pin", icon='ADD')

                    dome_col = hdri_box.column(align=True)
                    action_row = dome_col.row(align=True)
                    action_row.scale_y = 1.3
                    action_row.operator("renderflo.interactive_hdri_canvas", text="Interactive 2D Pin Canvas", icon='WINDOW')
                    action_row.prop(active_studio, "viewport_show_dome", text="Show Dome", icon='VIEW_CAMERA')

                    # Custom HDRI Map or Base Energy
                    custom_box = dome_col.box()
                    custom_box.prop(active_studio, "use_custom_hdri", text="External HDRI Map", icon='IMAGE_DATA')
                    if active_studio.use_custom_hdri:
                        c_col = custom_box.column(align=True)
                        load_r = c_col.row(align=True)
                        load_r.operator("renderflo.load_hdri_image", text="Browse HDR / EXR...", icon='FILE_FOLDER')
                        if active_studio.hdri_image:
                            load_r.operator("renderflo.clear_hdri_image", text="", icon='X')
                        c_col.prop(active_studio, "hdri_image", text="")
                        if active_studio.hdri_image:
                            s_row = c_col.row(align=True)
                            s_row.prop(active_studio, "hdri_image_strength", text="Intensity")
                            s_row.prop(active_studio, "hdri_rotation", text="Rotation")
                    else:
                        b_row = custom_box.row(align=True)
                        b_row.prop(active_studio, "hdri_base_color", text="")
                        b_row.prop(active_studio, "hdri_base_energy", text="Base Energy")
                        b_row.prop(active_studio, "hdri_rotation", text="Dome Rot")

                    # Highlight Pins
                    pin_hdr = dome_col.row(align=True)
                    active_p_cnt = sum(1 for p in active_studio.hdri_pins if p.enabled)
                    pin_hdr.label(text=f"Pins ({active_p_cnt}/{len(active_studio.hdri_pins)} active):", icon='LIGHT_SUN')
                    pin_hdr.operator("renderflo.add_hdri_pin", text="+ Pin", icon='ADD')

                    for p_idx, pin in enumerate(active_studio.hdri_pins):
                        p_box = dome_col.box()
                        p_top = p_box.row(align=True)
                        p_top.prop(pin, "enabled", text="")
                        p_top.prop(pin, "name", text="", emboss=False)
                        p_top.prop(pin, "pin_shape", text="")
                        p_top.prop(pin, "color", text="")

                        op_eye = p_top.operator("renderflo.place_hdri_pin_modal", text="", icon='EYEDROPPER')
                        op_eye.pin_index = p_idx
                        op_dup = p_top.operator("renderflo.duplicate_hdri_pin", text="", icon='DUPLICATE')
                        op_dup.pin_index = p_idx
                        op_del = p_top.operator("renderflo.remove_hdri_pin", text="", icon='X')
                        op_del.pin_index = p_idx

                        if pin.enabled:
                            s_col = p_box.column(align=True)
                            s_row1 = s_col.row(align=True)
                            s_row1.prop(pin, "energy", text="Energy")
                            s_row1.prop(pin, "radius", text="Size")
                            s_row1.prop(pin, "falloff", text="Glow")

                            if pin.pin_shape == 'RECT':
                                s_row2 = s_col.row(align=True)
                                s_row2.prop(pin, "aspect", text="Aspect")
                                s_row2.prop(pin, "rotation", text="Tilt")

                else:
                    # PHYSICAL LIGHTS MODULE
                    phys_box = layout.box()
                    phys_box.label(text="Physical Studio Lamps", icon='LIGHT_SUN')

                    spawn_row = phys_box.row(align=True)
                    op_key = spawn_row.operator("renderflo.spawn_studio_light", text="+ Key", icon='LIGHT_SUN')
                    op_key.preset = 'KEY'
                    op_rim = spawn_row.operator("renderflo.spawn_studio_light", text="+ Rim", icon='LIGHT_SPOT')
                    op_rim.preset = 'RIM'
                    op_fill = spawn_row.operator("renderflo.spawn_studio_light", text="+ Fill", icon='LIGHT_HEMI')
                    op_fill.preset = 'FILL'

                    studio_coll = bpy.data.collections.get(active_studio.light_collection_name)
                    if studio_coll and len(studio_coll.objects) > 0:
                        l_col = phys_box.column(align=True)
                        for l_obj in studio_coll.objects:
                            if l_obj.type == 'LIGHT':
                                is_off = l_obj.hide_render or l_obj.hide_viewport or l_obj.hide_get()
                                l_row = l_col.row(align=True)
                                op_toggle = l_row.operator("renderflo.toggle_studio_light", text="", icon='HIDE_ON' if is_off else 'HIDE_OFF', emboss=False)
                                op_toggle.light_name = l_obj.name

                                sub = l_row.row(align=True)
                                sub.enabled = not is_off
                                sub.prop(l_obj, "name", text="")
                                sub.prop(l_obj.data, "energy", text="W")
                                sub.prop(l_obj.data, "color", text="")
                                op_hl = sub.operator("renderflo.place_highlight_modal", text="", icon='EYEDROPPER')
                                op_hl.light_name = l_obj.name

                                op_del = l_row.operator("renderflo.remove_studio_light", text="", icon='X')
                                op_del.light_name = l_obj.name
                    else:
                        phys_box.label(text="No lamps in this studio. Click '+ Key' to spawn one.", icon='INFO')

        # ====================================================================
        # TAB 4: CMF MATRIX & INDUSTRIAL FINISHES
        # ====================================================================
        elif scene.rf_ui_tab == 'CMF':
            cmf_box = layout.box()
            cmf_box.label(text="Active CMF Colorway:", icon='COLOR')

            cmf_row = cmf_box.row(align=True)
            cmf_row.prop(scene, "rf_active_cmf_enum", text="")
            op_ren = cmf_row.operator("renderflo.rename_cmf", text="", icon='GREASEPENCIL')
            op_ren.target_cmf_name = scene.rf_active_cmf_enum
            cmf_row.operator("renderflo.update_active_cmf", text="", icon='FILE_REFRESH')

            c_actions = cmf_box.column(align=True)
            c_actions.scale_y = 1.15
            c_actions.operator("renderflo.create_colorway_variant", text="New Colorway (Clone All Materials)", icon='DUPLICATE')
            c_actions.operator("renderflo.save_new_cmf", text="Save Current State as CMF", icon='ADD')

            # Colorway Library Management (Rename & Delete created presets)
            if len(scene.rf_cmf_presets) > 0:
                lib_box = layout.box()
                lib_box.label(text="Manage Colorway Presets:", icon='PRESET')
                col_lib = lib_box.column(align=True)
                for cmf in scene.rf_cmf_presets:
                    c_row = col_lib.row(align=True)
                    is_active = (cmf.name == scene.rf_active_cmf_enum)
                    act_icon = 'CHECKMARK' if is_active else 'BLANK1'
                    c_row.label(text=cmf.name, icon=act_icon)

                    ren_op = c_row.operator("renderflo.rename_cmf", text="", icon='GREASEPENCIL')
                    ren_op.target_cmf_name = cmf.name

                    del_op = c_row.operator("renderflo.delete_cmf", text="", icon='TRASH')
                    del_op.target_cmf_name = cmf.name

            if active_studio and len(scene.rf_cmf_presets) > 0:
                # Matrix Checkboxes
                cmf_list_col = cmf_box.column(align=True)
                cmf_list_col.label(text=f"Included in Matrix Render for '{active_studio.name}':")
                if len(active_studio.cmf_matrix_toggles) == len(scene.rf_cmf_presets):
                    grid = cmf_list_col.grid_flow(columns=2, align=True)
                    for t in active_studio.cmf_matrix_toggles:
                        grid.prop(t, "enabled", text=t.cmf_name)
                else:
                    cmf_list_col.operator("renderflo.sync_cmf_matrix", icon='FILE_REFRESH', text="Sync Colorway List")

            # Selected Part Multi-Material Slots Inspector
            active_obj = context.active_object
            if active_obj and active_obj.type in {'MESH', 'CURVE', 'SURFACE'}:
                mat_box = layout.box()
                mat_box.label(text=f"Selected Part: {active_obj.name}", icon='OBJECT_DATA')
                if len(active_obj.material_slots) > 0:
                    for s_idx, slot in enumerate(active_obj.material_slots):
                        s_row = mat_box.row(align=True)
                        s_row.label(text=f"Slot {s_idx}:")
                        s_row.prop(slot, "material", text="")
                    m_act = mat_box.row(align=True)
                    m_act.operator("renderflo.clone_active_material", text="Clone Active Slot Material", icon='DUPLICATE')
                else:
                    mat_box.label(text="No material slots on this part.")

        # ====================================================================
        # TAB 5: DECALS, CUTAWAYS & FLEX TOOLS
        # ====================================================================
        elif scene.rf_ui_tab == 'DECALS':
            # Conformal Decals & Stickers (Grant Abbitt Method)
            dec_box = layout.box()
            dec_box.label(text="1-Click Conformal Decals & Stickers", icon='IMAGE_DATA')
            d_col = dec_box.column(align=True)
            d_row = d_col.row(align=True)
            d_row.scale_y = 1.3
            d_row.operator("renderflo.load_decal_image", text="1-Click Drop Graphic on Surface", icon='FILE_IMAGE')

            d_row2 = d_col.row(align=True)
            d_row2.scale_y = 1.15
            d_row2.operator("renderflo.conform_decal_to_surface", text="1-Click Conform Selected Mesh", icon='MOD_SHRINKWRAP')

            # Active Decal Quick Inspector
            active_obj = context.active_object
            if active_obj and (active_obj.name.startswith(DECAL_PREFIX) or active_obj.modifiers.get("Decal_Shrinkwrap") or active_obj.modifiers.get("Conformal_Shrinkwrap")):
                adj_box = dec_box.box()
                adj_box.label(text=f"Active Decal: {active_obj.name}", icon='PREFERENCES')
                sw = active_obj.modifiers.get("Decal_Shrinkwrap") or active_obj.modifiers.get("Conformal_Shrinkwrap")
                sub = active_obj.modifiers.get("Decal_Subdivision")

                # 1. Graphic Texture & File Management
                img_box = adj_box.box()
                img_box.label(text="Graphic Texture / File", icon='IMAGE_DATA')
                mat = active_obj.active_material
                tex_node = next((n for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE'), None) if mat and mat.node_tree else None
                if tex_node:
                    img_row1 = img_box.row(align=True)
                    img_row1.template_ID(tex_node, "image", open="image.open")
                img_row2 = img_box.row(align=True)
                img_row2.operator("renderflo.swap_decal_image", text="Change Graphic File", icon='FILE_IMAGE')
                img_row2.operator("renderflo.match_decal_aspect", text="Fit Aspect", icon='CON_SIZELIKE')

                # 2. Placement & Surface Movement
                pos_box = adj_box.box()
                pos_box.label(text="Placement & Surface Move", icon='ORIENTATION_NORMAL')
                pos_row = pos_box.row(align=True)
                pos_row.scale_y = 1.15
                pos_row.operator("renderflo.reposition_decal_modal", text="Click New Spot on Surface", icon='EYEDROPPER')
                pos_row.operator("renderflo.slide_decal_modal", text="Slide on Surface", icon='HAND')
                realign_row = pos_box.row(align=True)
                realign_row.operator("renderflo.realign_decal_normal", text="Re-Align to Normal (Fix 'G' Move)", icon='SNAP_NORMAL')

                # 3. Surface Normal Rotation / Spin Controls
                rot_box = adj_box.box()
                cur_rot = active_obj.get("rf_decal_spin", 0.0)
                rot_box.label(text=f"Surface Normal Spin: {cur_rot:+.1f}°", icon='FILE_REFRESH')

                rot_row1 = rot_box.row(align=True)
                rot_row1.operator("renderflo.rotate_decal", text="-90°").angle_delta = -90.0
                rot_row1.operator("renderflo.rotate_decal", text="-15°").angle_delta = -15.0
                rot_row1.operator("renderflo.rotate_decal", text="+15°").angle_delta = 15.0
                rot_row1.operator("renderflo.rotate_decal", text="+90°").angle_delta = 90.0

                rot_row2 = rot_box.row(align=True)
                rot_row2.scale_y = 1.15
                rot_row2.operator("renderflo.spin_decal_modal", text="Interactive Spin (Mouse / Scroll)", icon='SCULPTMODE_HLT')
                rot_row2.operator("renderflo.reset_decal_spin", text="Reset", icon='LOOP_BACK')

                # 4. Modifiers & Surface Material
                if sw:
                    row_sw = adj_box.row(align=True)
                    row_sw.prop(sw, "offset", text="Surface Offset (Z-Fighting)")
                    row_sw.prop(sw, "wrap_method", text="")
                    if hasattr(sw, "wrap_mode"):
                        adj_box.prop(sw, "wrap_mode", text="Wrap Mode")

                if sub:
                    row_sub = adj_box.row(align=True)
                    row_sub.prop(sub, "levels", text="Catmull-Clark Smoothness")
                    row_sub.prop(sub, "render_levels", text="Render")

                if active_obj.active_material and active_obj.active_material.node_tree:
                    bsdf = next((n for n in active_obj.active_material.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
                    if bsdf and "Roughness" in bsdf.inputs:
                        adj_box.prop(bsdf.inputs["Roughness"], "default_value", text="Sticker Glossiness / Roughness")

            # Live Boolean Section Cutaways
            cut_box = layout.box()
            cut_box.label(text="Live Section Cutaway Box", icon='MOD_BOOLEAN')
            c_row1 = cut_box.row(align=True)
            c_row1.operator("renderflo.create_cutaway_box", text="Generate Cutaway Box", icon='ADD')
            c_row1.operator("renderflo.toggle_cutaway", text="Toggle Cut", icon='HIDE_OFF')
            c_row1.operator("renderflo.remove_cutaway", text="", icon='X')

        # ====================================================================
        # TAB 6: GPU BATCH RENDER & MANUFACTURING EXPORT (DXF)
        # ====================================================================
        elif scene.rf_ui_tab == 'RENDER':
            # Render Output Directory
            out_box = layout.box()
            out_box.label(text="Render Output Folder", icon='FILE_FOLDER')
            out_row = out_box.row(align=True)
            out_row.prop(scene, "rf_render_output_dir", text="")
            out_row.operator("renderflo.open_render_folder", text="", icon='FOLDER_REDIRECT')

            gpu_box = layout.box()
            gpu_box.label(text="GPU Hardware & Render Quality", icon='PREFERENCES')

            g_col = gpu_box.column(align=True)
            hw_row = g_col.row(align=True)
            hw_row.prop(scene, "rf_force_gpu", text="Force GPU Compute")
            hw_row.operator("renderflo.activate_gpu_now", text="Activate GPU", icon='CHECKMARK')

            samp_row = g_col.row(align=True)
            samp_row.prop(scene, "rf_render_samples", text="Render Samples")
            samp_row.prop(scene, "rf_viewport_samples", text="Viewport")

            dn_row = g_col.row(align=True)
            dn_row.prop(scene, "rf_use_denoiser", text="Denoiser")
            dn_row.prop(scene, "rf_noise_threshold", text="Noise Limit")

            render_box = layout.box()
            render_col = render_box.column(align=True)

            if scene.rf_is_batch_rendering:
                render_col.label(text=scene.rf_batch_status_text, icon='TIME')
                render_col.prop(scene, "rf_batch_progress", text="Batch Progress", slider=True)
                cancel_row = render_col.row(align=True)
                cancel_row.scale_y = 1.4
                cancel_row.operator("renderflo.cancel_batch_render", icon='CANCEL', text="Cancel Batch (ESC)")
            else:
                btn_std = render_col.row(align=True)
                btn_std.scale_y = 1.4
                op_std = btn_std.operator("renderflo.batch_render", icon='RENDER_STILL', text="Batch Render Checked Studios")
                op_std.matrix_mode = False

                btn_mat = render_col.row(align=True)
                btn_mat.scale_y = 1.3
                op_mat = btn_mat.operator("renderflo.batch_render", icon='GRID', text="Matrix Render (Studios x CMFs)")
                op_mat.matrix_mode = True

            # Manufacturing Export (DXF)
            mfg_box = layout.box()
            mfg_box.label(text="Manufacturing Export (DXF)", icon='EXPORT')
            mfg_col = mfg_box.column(align=True)
            mfg_col.scale_y = 1.2
            mfg_col.operator("renderflo.generate_router_outline", icon='CURVE_DATA', text="Generate Router Outline Curve")
            mfg_col.operator("renderflo.export_router_dxf", icon='EXPORT', text="Export 2D Outline (DXF)")

        # ====================================================================
        # BOTTOM ACTION BAR (Explode, Turntable, Render)
        # ====================================================================
        layout.separator()
        action_box = layout.box()
        act_col = action_box.column(align=True)
        act_col.prop(scene, "rf_explode_factor", text="Explode", slider=True)
        act_col.prop(scene, "rf_turntable_angle", text="Turntable", slider=True)

        act_btn = act_col.row(align=True)
        act_btn.scale_y = 1.3
        if getattr(scene, "rf_is_batch_rendering", False):
            act_btn.alert = True
            act_btn.operator("renderflo.cancel_batch_render", text=f"Cancel ({scene.rf_batch_progress:.0f}%)", icon='CANCEL')
        else:
            act_btn.operator("renderflo.render_action_bar", text="RENDER", icon='RENDER_STILL')


# ------------------------------------------------------------------------
# Wide Floating Studio Dashboard Modal (Alt+Shift+R)
# ------------------------------------------------------------------------

class RENDERFLO_OT_studio_dashboard(bpy.types.Operator):
    bl_idname = "renderflo.studio_dashboard"
    bl_label = "ID RenderFlo — Wide Studio Dashboard"
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=780)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Top Bar Info
        top = layout.row(align=True)
        top.label(text="ID RenderFlo v3.0.0 — Production Studio Dashboard", icon='RENDERLAYERS')
        top.operator("renderflo.add_studio", text="+ New Studio", icon='ADD')

        layout.separator()

        # 3-Column Wide HUD Grid
        grid = layout.grid_flow(columns=3, align=True)

        # Col 1: Studios
        col1 = grid.box()
        col1.label(text="1. Studios & Cameras", icon='CAMERA_DATA')
        col1.template_list("RENDERFLO_UL_studio_list", "", scene, "rf_studios", scene, "rf_studio_index", rows=5)
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            s_row = col1.row(align=True)
            s_row.prop(studio, "use_custom_samples", text="Custom Samples")
            if studio.use_custom_samples:
                s_row.prop(studio, "studio_samples", text="")
            t_row = col1.row(align=True)
            t_row.prop(studio, "use_collections", text="Model Sets", toggle=True, icon='OUTLINER_COLLECTION')
            t_row.prop(studio, "use_transforms", text="Exploded / Part Pos", toggle=True, icon='ARROW_LEFTRIGHT')

        # Col 2: CMF Matrix
        col2 = grid.box()
        col2.label(text="2. CMF Colorway Matrix", icon='COLOR')
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            col2.label(text=f"Colorways for [{studio.name}]:")
            for t in studio.cmf_matrix_toggles:
                col2.prop(t, "enabled", text=t.cmf_name)
        else:
            col2.label(text="No active studio")

        # Col 3: Lighting & Render
        col3 = grid.box()
        col3.label(text="3. Lighting & Actions", icon='LIGHT_SUN')
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            col3.prop(studio, "exposure", text="Exposure")
            col3.prop(studio, "contrast", text="Contrast")
            col3.prop(studio, "film_transparent", text="Transparent PNG")
            col3.separator()
            col3.operator("renderflo.interactive_hdri_canvas", text="2D HDRI Pin Canvas", icon='WINDOW')
            col3.operator("renderflo.cad_hot_reload", text="1-Click CAD Reload", icon='FILE_REFRESH')

        layout.separator()

        # Render Output Folder
        out_row = layout.row(align=True)
        out_row.prop(scene, "rf_render_output_dir", text="Save Renders To")
        out_row.operator("renderflo.open_render_folder", text="", icon='FOLDER_REDIRECT')

        # Bottom Bar: Render Queue Trigger
        bot = layout.row(align=True)
        bot.scale_y = 1.4
        op_std = bot.operator("renderflo.batch_render", text="Batch Render Studios (GPU)", icon='RENDER_STILL')
        op_std.matrix_mode = False
        op_mat = bot.operator("renderflo.batch_render", text="Matrix Render (Studios x CMF)", icon='GRID')
        op_mat.matrix_mode = True

    def execute(self, context):
        return {'FINISHED'}


main_panel_classes = (
    RENDERFLO_UL_studio_list,
    RENDERFLO_PT_main_panel,
    RENDERFLO_OT_studio_dashboard,
)


def register():
    for cls in main_panel_classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(main_panel_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

