# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.1.0 — Lighting & KeyShot-Style Procedural HDRI Dome Suite.
3-Point Area Softboxes, Highlight Raycasting, Procedural Latitude/Longitude Pins,
and Interactive 2D Viewport Dome Canvas.
"""

import bpy
import gpu
import blf
import math
from mathutils import Vector
from bpy_extras import view3d_utils
from bpy_extras.io_utils import ImportHelper
from gpu_extras.batch import batch_for_shader

from ..state import (
    TARGET_EMPTY_NAME,
    GROUND_PLANE_NAME,
    BACKDROP_OBJ_NAME,
    DOME_VISUALIZER_OBJ,
    DOME_PIN_PREFIX,
    is_internal_update,
    internal_update_guard,
)


# ------------------------------------------------------------------------
# 2D GPU Drawing Helpers
# ------------------------------------------------------------------------

def get_2d_gpu_shader():
    try:
        return gpu.shader.from_builtin('UNIFORM_COLOR')
    except Exception:
        return gpu.shader.from_builtin('2D_UNIFORM_COLOR')


def draw_2d_quad(x1, y1, x2, y2, color):
    shader = get_2d_gpu_shader()
    batch = batch_for_shader(shader, 'TRI_FAN', {
        "pos": [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
    })
    gpu.state.blend_set('ALPHA')
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set('NONE')


def draw_2d_line(x1, y1, x2, y2, color, line_width=1.0):
    shader = get_2d_gpu_shader()
    batch = batch_for_shader(shader, 'LINES', {
        "pos": [(x1, y1), (x2, y2)]
    })
    gpu.state.blend_set('ALPHA')
    try:
        gpu.state.line_width_set(line_width)
    except Exception:
        pass
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    try:
        gpu.state.line_width_set(1.0)
    except Exception:
        pass
    gpu.state.blend_set('NONE')


def draw_2d_circle(cx, cy, radius, color, segments=24, fill=True):
    coords = []
    if fill:
        coords.append((cx, cy))
    for i in range(segments + 1):
        ang = (2.0 * math.pi * i) / segments
        coords.append((cx + math.cos(ang) * radius, cy + math.sin(ang) * radius))

    shader = get_2d_gpu_shader()
    mode = 'TRI_FAN' if fill else 'LINE_STRIP'
    batch = batch_for_shader(shader, mode, {"pos": coords})
    gpu.state.blend_set('ALPHA')
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set('NONE')


def draw_2d_rect_pin(cx, cy, radius, aspect, rotation_deg, color, fill=True):
    hw = max(1.5, radius * 45.0 * max(0.1, aspect))
    hh = max(1.5, radius * 45.0)
    rad = math.radians(rotation_deg)
    cos_r = math.cos(rad)
    sin_r = math.sin(rad)

    corners = [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]
    rot_corners = []
    for lx, ly in corners:
        rx = cx + lx * cos_r - ly * sin_r
        ry = cy + lx * sin_r + ly * cos_r
        rot_corners.append((rx, ry))

    if fill:
        pts = rot_corners
        mode = 'TRI_FAN'
    else:
        pts = rot_corners + [rot_corners[0]]
        mode = 'LINE_STRIP'

    shader = get_2d_gpu_shader()
    batch = batch_for_shader(shader, mode, {"pos": pts})
    gpu.state.blend_set('ALPHA')
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set('NONE')


def draw_2d_text(text, x, y, size=11, color=(1.0, 1.0, 1.0, 1.0)):
    font_id = 0
    try:
        blf.size(font_id, size)
    except Exception:
        pass
    blf.color(font_id, *color)
    blf.position(font_id, x, y, 0)
    blf.draw(font_id, text)


def draw_2d_image_quad(img, x1, y1, x2, y2, rotation_deg=0.0):
    try:
        sh = gpu.shader.from_builtin('IMAGE')
    except Exception:
        try:
            sh = gpu.shader.from_builtin('2D_IMAGE')
        except Exception:
            return False

    try:
        if hasattr(img, "gl_load"):
            img.gl_load()
    except Exception:
        pass

    try:
        tex = gpu.texture.from_image(img)
    except Exception:
        return False

    u_rot = (rotation_deg / 360.0) % 1.0
    if u_rot < 0.0:
        u_rot += 1.0

    gpu.state.blend_set('ALPHA')
    sh.bind()
    try:
        sh.uniform_sampler('image', tex)
    except Exception:
        pass
    try:
        sh.uniform_float('color', (1.0, 1.0, 1.0, 1.0))
    except Exception:
        pass

    width = x2 - x1
    if u_rot <= 0.001 or u_rot >= 0.999:
        batch = batch_for_shader(sh, 'TRI_FAN', {
            "pos": [(x1, y1), (x2, y1), (x2, y2), (x1, y2)],
            "texCoord": [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)],
        })
        batch.draw(sh)
    else:
        x_split = x1 + u_rot * width

        batch1 = batch_for_shader(sh, 'TRI_FAN', {
            "pos": [(x1, y1), (x_split, y1), (x_split, y2), (x1, y2)],
            "texCoord": [(1.0 - u_rot, 0.0), (1.0, 0.0), (1.0, 1.0), (1.0 - u_rot, 1.0)],
        })
        batch1.draw(sh)

        batch2 = batch_for_shader(sh, 'TRI_FAN', {
            "pos": [(x_split, y1), (x2, y1), (x2, y2), (x_split, y2)],
            "texCoord": [(0.0, 0.0), (1.0 - u_rot, 0.0), (1.0 - u_rot, 1.0), (0.0, 1.0)],
        })
        batch2.draw(sh)

    gpu.state.blend_set('NONE')
    return True


# ------------------------------------------------------------------------
# HDRI Pin Helpers & Callback Updates
# ------------------------------------------------------------------------

def find_studio_for_pin(scene, pin):
    if not scene:
        return None
    for s in scene.rf_studios:
        for p in s.hdri_pins:
            if p == pin:
                return s
    if 0 <= scene.rf_studio_index < len(scene.rf_studios):
        return scene.rf_studios[scene.rf_studio_index]
    return None


def on_hdri_pin_update(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    scene = context.scene
    studio = find_studio_for_pin(scene, self)
    if studio:
        rebuild_studio_hdri_nodes(studio, scene, force=True)
        update_studio_dome_visualizer(studio, context)


def on_studio_hdri_update(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    rebuild_studio_hdri_nodes(self, context.scene, force=True)
    update_studio_dome_visualizer(self, context)


def on_studio_viewport_dome_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    scene = context.scene
    scene.render.film_transparent = False if self.viewport_show_dome else self.film_transparent
    if context.screen:
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D' and hasattr(space, "shading"):
                        if self.viewport_show_dome:
                            space.shading.use_scene_world = True
                            space.shading.use_scene_lights = True
                area.tag_redraw()


def update_studio_dome_visualizer(studio=None, context=None):
    dome_obj = bpy.data.objects.get(DOME_VISUALIZER_OBJ)
    if dome_obj:
        try:
            bpy.data.objects.remove(dome_obj, do_unlink=True)
        except Exception:
            pass
    for obj in list(bpy.data.objects):
        if obj.name.startswith(DOME_PIN_PREFIX):
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except Exception:
                pass


# ------------------------------------------------------------------------
# Procedural World HDRI Shader Construction
# ------------------------------------------------------------------------

def rebuild_studio_hdri_nodes(studio, scene=None, force=False):
    if is_internal_update() and not force:
        return

    world_name = studio.world_name or f"World_{bpy.path.clean_name(studio.name)}"
    world = bpy.data.worlds.get(world_name)
    if not world:
        world = bpy.data.worlds.new(world_name)
    studio.world_name = world.name

    if scene:
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            if scene.rf_studios[scene.rf_studio_index] == studio:
                if scene.world != world:
                    scene.world = world

    if studio.is_locked and not force:
        return

    world.use_nodes = True
    nt = world.node_tree
    nt.nodes.clear()

    if not studio.use_hdri_dome:
        bg = nt.nodes.new("ShaderNodeBackground")
        bg.location = (0, 0)
        bg.inputs["Color"].default_value = (
            studio.hdri_base_color[0],
            studio.hdri_base_color[1],
            studio.hdri_base_color[2],
            1.0,
        )
        bg.inputs["Strength"].default_value = studio.hdri_base_energy
        out = nt.nodes.new("ShaderNodeOutputWorld")
        out.location = (300, 0)
        nt.links.new(bg.outputs["Background"], out.inputs["Surface"])
        return

    # 1. TexCoord -> Normalize to get unit direction vector D
    tc = nt.nodes.new("ShaderNodeTexCoord")
    tc.location = (-1200, 0)

    norm = nt.nodes.new("ShaderNodeVectorMath")
    norm.operation = "NORMALIZE"
    norm.location = (-1000, 0)
    nt.links.new(tc.outputs["Generated"], norm.inputs[0])

    # 2. Base background: Custom HDRI environment texture OR procedural ambient color * energy
    if getattr(studio, "use_custom_hdri", False) and studio.hdri_image:
        mapping = nt.nodes.new("ShaderNodeMapping")
        mapping.location = (-1000, 250)
        mapping.vector_type = 'TEXTURE'
        mapping.inputs["Rotation"].default_value = (0, 0, math.radians(studio.hdri_rotation))
        nt.links.new(tc.outputs["Generated"], mapping.inputs["Vector"])

        env_tex = nt.nodes.new("ShaderNodeTexEnvironment")
        env_tex.location = (-800, 250)
        env_tex.image = studio.hdri_image
        nt.links.new(mapping.outputs["Vector"], env_tex.inputs["Vector"])

        scale_env = nt.nodes.new("ShaderNodeVectorMath")
        scale_env.operation = "SCALE"
        scale_env.location = (-600, 250)
        scale_env.inputs["Scale"].default_value = max(0.0, getattr(studio, "hdri_image_strength", 1.0))
        nt.links.new(env_tex.outputs["Color"], scale_env.inputs["Vector"])

        curr_accum_socket = scale_env.outputs["Vector"]
    else:
        base_node = nt.nodes.new("ShaderNodeCombineXYZ")
        base_node.location = (-800, 200)
        base_node.inputs[0].default_value = studio.hdri_base_color[0] * studio.hdri_base_energy
        base_node.inputs[1].default_value = studio.hdri_base_color[1] * studio.hdri_base_energy
        base_node.inputs[2].default_value = studio.hdri_base_color[2] * studio.hdri_base_energy
        curr_accum_socket = base_node.outputs["Vector"]

    # 3. Accumulate procedural pins
    x_offset = -600
    y_step = -250

    enabled_pins = [p for p in studio.hdri_pins if p.enabled]
    last_x = x_offset

    for idx, pin in enumerate(enabled_pins):
        theta = math.radians(pin.azimuth + studio.hdri_rotation)
        phi = math.radians(pin.elevation)
        cos_phi = math.cos(phi)
        sin_phi = math.sin(phi)
        cos_th = math.cos(theta)
        sin_th = math.sin(theta)

        px = cos_phi * cos_th
        py = cos_phi * sin_th
        pz = sin_phi
        p_vec = Vector((px, py, pz))

        pin_y = idx * y_step
        glow = max(0.01, getattr(studio, "hdri_glow_size", 1.0))

        if pin.pin_shape == 'CIRCLE':
            dot_node = nt.nodes.new("ShaderNodeVectorMath")
            dot_node.operation = "DOT_PRODUCT"
            dot_node.location = (x_offset, pin_y)
            dot_node.inputs[1].default_value = (px, py, pz)
            nt.links.new(norm.outputs["Vector"], dot_node.inputs[0])

            mr_node = nt.nodes.new("ShaderNodeMapRange")
            mr_node.interpolation_type = "SMOOTHSTEP"
            mr_node.clamp = True
            mr_node.location = (x_offset + 200, pin_y)
            nt.links.new(dot_node.outputs["Value"], mr_node.inputs["Value"])

            r_core = max(0.0005, pin.radius * glow)
            r_outer = min(math.pi * 0.999, r_core + max(0.0001, pin.falloff * glow))
            mr_node.inputs["From Min"].default_value = math.cos(r_outer)
            mr_node.inputs["From Max"].default_value = math.cos(r_core)
            mr_node.inputs["To Min"].default_value = 0.0
            mr_node.inputs["To Max"].default_value = 1.0

            mask_socket = mr_node.outputs["Result"]
            last_x = x_offset + 400

        else:  # 'RECT' Softbox Strip
            if abs(cos_phi) > 1e-4:
                u0 = Vector((-sin_th, cos_th, 0.0))
            else:
                u0 = Vector((1.0, 0.0, 0.0))
            v0 = p_vec.cross(u0).normalized()

            psi = math.radians(pin.rotation)
            cos_psi = math.cos(psi)
            sin_psi = math.sin(psi)
            u_vec = (cos_psi * u0 + sin_psi * v0).normalized()
            v_vec = (-sin_psi * u0 + cos_psi * v0).normalized()

            w = max(0.0005, pin.radius * glow * max(0.05, pin.aspect))
            h = max(0.0005, pin.radius * glow)
            f = max(0.0001, pin.falloff * glow)

            # U component
            dot_u = nt.nodes.new("ShaderNodeVectorMath")
            dot_u.operation = "DOT_PRODUCT"
            dot_u.location = (x_offset, pin_y + 80)
            dot_u.inputs[1].default_value = (u_vec.x, u_vec.y, u_vec.z)
            nt.links.new(norm.outputs["Vector"], dot_u.inputs[0])

            abs_u = nt.nodes.new("ShaderNodeMath")
            abs_u.operation = "ABSOLUTE"
            abs_u.location = (x_offset + 180, pin_y + 80)
            nt.links.new(dot_u.outputs["Value"], abs_u.inputs[0])

            mr_u = nt.nodes.new("ShaderNodeMapRange")
            mr_u.interpolation_type = "SMOOTHSTEP"
            mr_u.clamp = True
            mr_u.location = (x_offset + 340, pin_y + 80)
            nt.links.new(abs_u.outputs["Value"], mr_u.inputs["Value"])
            mr_u.inputs["From Min"].default_value = math.sin(min(math.pi * 0.49, w + f))
            mr_u.inputs["From Max"].default_value = math.sin(min(math.pi * 0.49, w))
            mr_u.inputs["To Min"].default_value = 0.0
            mr_u.inputs["To Max"].default_value = 1.0

            # V component
            dot_v = nt.nodes.new("ShaderNodeVectorMath")
            dot_v.operation = "DOT_PRODUCT"
            dot_v.location = (x_offset, pin_y - 80)
            dot_v.inputs[1].default_value = (v_vec.x, v_vec.y, v_vec.z)
            nt.links.new(norm.outputs["Vector"], dot_v.inputs[0])

            abs_v = nt.nodes.new("ShaderNodeMath")
            abs_v.operation = "ABSOLUTE"
            abs_v.location = (x_offset + 180, pin_y - 80)
            nt.links.new(dot_v.outputs["Value"], abs_v.inputs[0])

            mr_v = nt.nodes.new("ShaderNodeMapRange")
            mr_v.interpolation_type = "SMOOTHSTEP"
            mr_v.clamp = True
            mr_v.location = (x_offset + 340, pin_y - 80)
            nt.links.new(abs_v.outputs["Value"], mr_v.inputs["Value"])
            mr_v.inputs["From Min"].default_value = math.sin(min(math.pi * 0.49, h + f))
            mr_v.inputs["From Max"].default_value = math.sin(min(math.pi * 0.49, h))
            mr_v.inputs["To Min"].default_value = 0.0
            mr_v.inputs["To Max"].default_value = 1.0

            # Forward hemisphere mask
            dot_f = nt.nodes.new("ShaderNodeVectorMath")
            dot_f.operation = "DOT_PRODUCT"
            dot_f.location = (x_offset, pin_y - 200)
            dot_f.inputs[1].default_value = (px, py, pz)
            nt.links.new(norm.outputs["Vector"], dot_f.inputs[0])

            mr_f = nt.nodes.new("ShaderNodeMapRange")
            mr_f.interpolation_type = "LINEAR"
            mr_f.clamp = True
            mr_f.location = (x_offset + 180, pin_y - 200)
            nt.links.new(dot_f.outputs["Value"], mr_f.inputs["Value"])
            mr_f.inputs["From Min"].default_value = 0.0
            mr_f.inputs["From Max"].default_value = 0.02
            mr_f.inputs["To Min"].default_value = 0.0
            mr_f.inputs["To Max"].default_value = 1.0

            mul_uv = nt.nodes.new("ShaderNodeMath")
            mul_uv.operation = "MULTIPLY"
            mul_uv.location = (x_offset + 520, pin_y)
            nt.links.new(mr_u.outputs["Result"], mul_uv.inputs[0])
            nt.links.new(mr_v.outputs["Result"], mul_uv.inputs[1])

            mul_f = nt.nodes.new("ShaderNodeMath")
            mul_f.operation = "MULTIPLY"
            mul_f.location = (x_offset + 680, pin_y)
            nt.links.new(mul_uv.outputs["Value"], mul_f.inputs[0])
            nt.links.new(mr_f.outputs["Result"], mul_f.inputs[1])

            mask_socket = mul_f.outputs["Value"]
            last_x = x_offset + 840

        scale_node = nt.nodes.new("ShaderNodeVectorMath")
        scale_node.operation = "SCALE"
        scale_node.location = (last_x, pin_y)
        scale_node.inputs["Vector"].default_value = (
            pin.color[0] * pin.energy,
            pin.color[1] * pin.energy,
            pin.color[2] * pin.energy,
        )
        nt.links.new(mask_socket, scale_node.inputs["Scale"])

        add_node = nt.nodes.new("ShaderNodeVectorMath")
        add_node.operation = "ADD"
        add_node.location = (last_x + 200, pin_y)
        nt.links.new(curr_accum_socket, add_node.inputs[0])
        nt.links.new(scale_node.outputs["Vector"], add_node.inputs[1])

        curr_accum_socket = add_node.outputs["Vector"]
        last_x += 400

    # 4. Final Background & OutputWorld
    final_x = max(200, last_x + 200)
    bg = nt.nodes.new("ShaderNodeBackground")
    bg.location = (final_x, 0)
    bg.inputs["Strength"].default_value = 1.0
    nt.links.new(curr_accum_socket, bg.inputs["Color"])

    out = nt.nodes.new("ShaderNodeOutputWorld")
    out.location = (final_x + 200, 0)
    nt.links.new(bg.outputs["Background"], out.inputs["Surface"])


def generate_hdri_equirectangular_preview(studio, width=256, height=128):
    if not getattr(studio, "use_hdri_dome", True):
        return None

    img_name = f"_RenderFlo_HDRI_Map_{bpy.path.clean_name(studio.name)}"
    img = bpy.data.images.get(img_name)
    if not img or img.size[0] != width or img.size[1] != height:
        if img:
            bpy.data.images.remove(img)
        img = bpy.data.images.new(img_name, width=width, height=height, float_buffer=False)
        img.use_fake_user = True

    try:
        import numpy as np

        xs = np.linspace(-math.pi, math.pi, width, endpoint=False)
        ys = np.linspace(-math.pi * 0.5, math.pi * 0.5, height, endpoint=False)
        X, Y = np.meshgrid(xs, ys)

        base_energy = max(0.0, studio.hdri_base_energy)
        base_r = studio.hdri_base_color[0] * base_energy
        base_g = studio.hdri_base_color[1] * base_energy
        base_b = studio.hdri_base_color[2] * base_energy

        sky_grad = np.clip((np.sin(Y) + 1.0) * 0.5, 0.25, 1.0)
        rgb = np.zeros((height, width, 3), dtype=np.float32)
        rgb[:, :, 0] = base_r * sky_grad
        rgb[:, :, 1] = base_g * sky_grad
        rgb[:, :, 2] = base_b * sky_grad

        dome_rot = math.radians(studio.hdri_rotation)
        enabled_pins = [p for p in studio.hdri_pins if p.enabled]

        for pin in enabled_pins:
            p_th = math.radians(pin.azimuth) + dome_rot
            while p_th > math.pi:
                p_th -= 2.0 * math.pi
            while p_th < -math.pi:
                p_th += 2.0 * math.pi
            p_phi = math.radians(pin.elevation)

            cos_phi_p = math.cos(p_phi)
            sin_phi_p = math.sin(p_phi)
            cos_dist = np.clip(np.sin(Y) * sin_phi_p + np.cos(Y) * cos_phi_p * np.cos(X - p_th), -1.0, 1.0)

            if pin.pin_shape == 'CIRCLE':
                dist = np.arccos(cos_dist)
                r_core = max(0.005, pin.radius)
                r_outer = max(r_core + 0.001, pin.radius + pin.falloff)
                mask = np.clip((r_outer - dist) / (r_outer - r_core), 0.0, 1.0)
                mask = mask * mask * (3.0 - 2.0 * mask)
            else:
                d_th = np.abs(X - p_th)
                d_th = np.minimum(d_th, 2.0 * math.pi - d_th) * np.cos(Y)
                d_phi = np.abs(Y - p_phi)

                w_core = max(0.005, pin.radius * max(0.1, pin.aspect))
                w_outer = w_core + pin.falloff
                h_core = max(0.005, pin.radius)
                h_outer = h_core + pin.falloff

                cos_r = math.cos(math.radians(pin.rotation))
                sin_r = math.sin(math.radians(pin.rotation))
                rot_u = np.abs(d_th * cos_r + d_phi * sin_r)
                rot_v = np.abs(-d_th * sin_r + d_phi * cos_r)

                mask_u = np.clip((w_outer - rot_u) / max(0.001, w_outer - w_core), 0.0, 1.0)
                mask_v = np.clip((h_outer - rot_v) / max(0.001, h_outer - h_core), 0.0, 1.0)
                mask = (mask_u * mask_u * (3.0 - 2.0 * mask_u)) * (mask_v * mask_v * (3.0 - 2.0 * mask_v))
                mask *= (cos_dist > 0.0).astype(np.float32)

            rgb[:, :, 0] += mask * pin.color[0] * pin.energy
            rgb[:, :, 1] += mask * pin.color[1] * pin.energy
            rgb[:, :, 2] += mask * pin.color[2] * pin.energy

        rgb = rgb / (1.0 + rgb)

        h_idx = height // 2
        rgb[h_idx, :, :] = np.clip(rgb[h_idx, :, :] * 0.75 + 0.25, 0.0, 1.0)
        m_idx = width // 2
        rgb[:, m_idx, :] = np.clip(rgb[:, m_idx, :] * 0.8 + 0.2, 0.0, 1.0)

        for pin in enabled_pins:
            p_th = math.radians(pin.azimuth) + dome_rot
            while p_th > math.pi:
                p_th -= 2.0 * math.pi
            while p_th < -math.pi:
                p_th += 2.0 * math.pi
            p_phi = math.radians(pin.elevation)

            cx = int(((p_th + math.pi) / (2.0 * math.pi)) * width) % width
            cy = int(((p_phi + math.pi * 0.5) / math.pi) * height)
            cy = max(0, min(height - 1, cy))

            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    nx = (cx + dx) % width
                    ny = max(0, min(height - 1, cy + dy))
                    rgb[ny, nx, :] = [1.0, 1.0, 1.0] if (dx == 0 or dy == 0) else [0.0, 0.0, 0.0]

        rgba = np.ones((height, width, 4), dtype=np.float32)
        rgba[:, :, :3] = rgb
        flat = rgba.flatten()
        img.pixels.foreach_set(flat)
        img.update()
        try:
            prev = img.preview_ensure()
            prev.image_size = (width, height)
            prev.image_pixels_float = flat
            prev.icon_size = (32, 32)
            prev.icon_pixels_float = rgba[::max(1, height // 32), ::max(1, width // 32), :].flatten()
        except Exception:
            pass
        studio.hdri_preview_image = img
        return img
    except Exception:
        return None


# ------------------------------------------------------------------------
# Physical Lamps & Eyedropper Highlight Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_spawn_studio_light(bpy.types.Operator):
    bl_idname = "renderflo.spawn_studio_light"
    bl_label = "Add Studio Light"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(
        items=[
            ('KEY', "Key Softbox", "Primary 45-degree softbox light"),
            ('RIM', "Rim / Edge", "Back/Side high-contrast edge highlight light"),
            ('FILL', "Top Fill", "Soft overhead diffused fill light"),
            ('UNDER', "Under Glow", "Subtle upward ground bounce softbox"),
            ('ACCENT', "Pin Accent", "Narrow beam specular accent light"),
        ],
        default='KEY'
    )

    def execute(self, context):
        scene = context.scene
        from .studio_manager import ensure_studio_light_collection, ensure_light_target, capture_studio_state
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            bpy.ops.renderflo.add_studio()

        studio = scene.rf_studios[scene.rf_studio_index]
        light_coll = ensure_studio_light_collection(context, studio)
        target = ensure_light_target(context)

        if self.preset == 'KEY':
            l_name, offset, energy, size, color = f"{studio.name}_KeyLight", Vector((2.2, -2.2, 1.8)), 150.0, 1.5, (1.0, 0.98, 0.95)
        elif self.preset == 'RIM':
            l_name, offset, energy, size, color = f"{studio.name}_RimLight", Vector((-2.0, 2.2, 1.2)), 250.0, 0.6, (0.95, 0.98, 1.0)
        elif self.preset == 'UNDER':
            l_name, offset, energy, size, color = f"{studio.name}_UnderGlow", Vector((0.0, -1.5, -0.8)), 60.0, 2.0, (0.9, 0.95, 1.0)
        elif self.preset == 'ACCENT':
            l_name, offset, energy, size, color = f"{studio.name}_AccentSpot", Vector((1.5, -0.5, 2.5)), 300.0, 0.3, (1.0, 0.95, 0.9)
        else:
            l_name, offset, energy, size, color = f"{studio.name}_TopFill", Vector((0.0, 0.0, 3.0)), 80.0, 2.5, (1.0, 1.0, 1.0)

        light_data = bpy.data.lights.new(name=l_name, type='AREA')
        light_data.energy = energy
        light_data.size = size
        light_data.color = color
        light_data.shape = 'RECTANGLE'
        light_data.size_y = size * 0.65

        light_obj = bpy.data.objects.new(name=l_name, object_data=light_data)
        light_obj.location = target.location + offset
        light_coll.objects.link(light_obj)

        track = light_obj.constraints.new(type='TRACK_TO')
        track.target = target
        track.track_axis = 'TRACK_NEGATIVE_Z'
        track.up_axis = 'UP_Y'

        for o in context.selected_objects:
            o.select_set(False)
        light_obj.select_set(True)
        context.view_layer.objects.active = light_obj
        capture_studio_state(context, studio)
        self.report({'INFO'}, f"Spawned Softbox: '{light_obj.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_toggle_studio_light(bpy.types.Operator):
    bl_idname = "renderflo.toggle_studio_light"
    bl_label = "Toggle Studio Light"
    bl_description = "Turn this physical light on/off in both Viewport and Render view"
    bl_options = {'REGISTER', 'UNDO'}

    light_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.light_name)
        if not obj:
            return {'CANCELLED'}

        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if studio.is_locked:
                self.report({'WARNING'}, "Active Studio is locked.")
                return {'CANCELLED'}

        is_hidden = obj.hide_viewport or obj.hide_render or obj.hide_get()
        new_hide = not is_hidden

        obj.hide_viewport = new_hide
        obj.hide_render = new_hide
        try:
            obj.hide_set(new_hide)
        except Exception:
            pass

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if not studio.is_locked:
                from .studio_manager import capture_studio_state
                capture_studio_state(context, studio)

        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        state_str = "OFF" if new_hide else "ON"
        self.report({'INFO'}, f"Light '{obj.name}' turned {state_str}")
        return {'FINISHED'}


class RENDERFLO_OT_remove_studio_light(bpy.types.Operator):
    bl_idname = "renderflo.remove_studio_light"
    bl_label = "Delete Studio Light"
    bl_description = "Delete this physical light from the scene and studio collection"
    bl_options = {'REGISTER', 'UNDO'}

    light_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.light_name)
        if not obj:
            return {'CANCELLED'}

        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if studio.is_locked:
                self.report({'WARNING'}, "Active Studio is locked.")
                return {'CANCELLED'}

        l_name = obj.name
        l_data = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if l_data and l_data.users == 0:
            bpy.data.lights.remove(l_data)

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if not studio.is_locked:
                from .studio_manager import capture_studio_state
                capture_studio_state(context, studio)

        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        self.report({'INFO'}, f"Deleted Light '{l_name}'")
        return {'FINISHED'}


class RENDERFLO_OT_place_highlight_modal(bpy.types.Operator):
    bl_idname = "renderflo.place_highlight_modal"
    bl_label = "Click on Model to Place Highlight"
    bl_options = {'REGISTER', 'UNDO'}

    light_name: bpy.props.StringProperty()
    distance: bpy.props.FloatProperty(default=2.5, min=0.2, max=20.0)

    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'MOUSEMOVE', 'LEFTMOUSE'}:
            region = context.region
            rv3d = context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, obj, matrix = context.scene.ray_cast(depsgraph, ray_origin, view_vector)

            if result and obj and obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                light_obj = bpy.data.objects.get(self.light_name)
                from .studio_manager import ensure_light_target, capture_studio_state
                target = ensure_light_target(context)
                if light_obj:
                    incident = (location - ray_origin).normalized()
                    n = normal.normalized()
                    reflect_vec = (incident - 2.0 * incident.dot(n) * n).normalized()
                    dist = max((light_obj.location - target.location).length, self.distance)
                    light_obj.location = location + reflect_vec * dist
                    target.location = location

                if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                    context.window.cursor_modal_restore()
                    if 0 <= context.scene.rf_studio_index < len(context.scene.rf_studios):
                        capture_studio_state(context, context.scene.rf_studios[context.scene.rf_studio_index])
                    self.report({'INFO'}, f"Placed highlight on '{obj.name}'")
                    return {'FINISHED'}

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            context.window.cursor_modal_restore()
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            context.window.cursor_modal_set('EYEDROPPER')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        return {'CANCELLED'}


# ------------------------------------------------------------------------
# Procedural HDRI Pin Eyedropper & Canvas Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_place_hdri_pin_modal(bpy.types.Operator):
    bl_idname = "renderflo.place_hdri_pin_modal"
    bl_label = "Click on Model to Place HDRI Pin"
    bl_options = {'REGISTER', 'UNDO'}

    pin_index: bpy.props.IntProperty(default=0)
    _orig_azimuth: float = 0.0
    _orig_elevation: float = 0.0

    def modal(self, context, event):
        context.area.tag_redraw()
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            context.window.cursor_modal_restore()
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if not (0 <= self.pin_index < len(studio.hdri_pins)):
            context.window.cursor_modal_restore()
            return {'CANCELLED'}

        pin = studio.hdri_pins[self.pin_index]

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            context.window.cursor_modal_restore()
            pin.azimuth = self._orig_azimuth
            pin.elevation = self._orig_elevation
            rebuild_studio_hdri_nodes(studio, scene)
            update_studio_dome_visualizer(studio, context)
            return {'CANCELLED'}

        if event.type in {'MOUSEMOVE', 'LEFTMOUSE'}:
            region = context.region
            rv3d = context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, obj, matrix = scene.ray_cast(depsgraph, ray_origin, view_vector)

            if result and obj and obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                incident = (location - ray_origin).normalized()
                n = normal.normalized()
                r_vec = (incident - 2.0 * incident.dot(n) * n).normalized()

                az_deg = math.degrees(math.atan2(r_vec.y, r_vec.x)) - studio.hdri_rotation
                while az_deg > 180.0:
                    az_deg -= 360.0
                while az_deg < -180.0:
                    az_deg += 360.0

                el_deg = math.degrees(math.asin(max(-1.0, min(1.0, r_vec.z))))

                pin.azimuth = az_deg
                pin.elevation = el_deg
                rebuild_studio_hdri_nodes(studio, scene)
                update_studio_dome_visualizer(studio, context)

                if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                    context.window.cursor_modal_restore()
                    if getattr(scene, "rf_auto_save_studios", True) and not studio.is_locked:
                        from .studio_manager import capture_studio_state
                        capture_studio_state(context, studio)
                    self.report({'INFO'}, f"Placed HDRI Pin '{pin.name}' on '{obj.name}' ({az_deg:.1f}°, {el_deg:.1f}°)")
                    return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            self.report({'WARNING'}, "No active Studio.")
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        if not (0 <= self.pin_index < len(studio.hdri_pins)):
            self.report({'WARNING'}, "Invalid HDRI Pin index.")
            return {'CANCELLED'}

        pin = studio.hdri_pins[self.pin_index]
        self._orig_azimuth = pin.azimuth
        self._orig_elevation = pin.elevation

        if context.area.type == 'VIEW_3D':
            context.window.cursor_modal_set('EYEDROPPER')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}

        return {'CANCELLED'}


class RENDERFLO_OT_interactive_hdri_canvas(bpy.types.Operator):
    bl_idname = "renderflo.interactive_hdri_canvas"
    bl_label = "KeyShot Interactive HDRI Dome Pin Canvas"
    bl_description = "Open interactive 2D rectangular HDRI dome canvas in 3D Viewport to directly click, drag, add, and manipulate lighting pins"
    bl_options = {'REGISTER'}

    _handle = None
    _is_running = False
    _target_area = None

    canvas_x: int = 50
    canvas_y: int = 50
    canvas_w: int = 400
    canvas_h: int = 200
    title_h: int = 26
    footer_h: int = 22
    dragging_pin: int = -1
    hover_pin: int = -1
    dragging_window: bool = False
    drag_offset_x: int = 0
    drag_offset_y: int = 0
    is_collapsed: bool = False
    size_mode: str = 'STANDARD'

    SIZE_PRESETS = {
        'COMPACT': (320, 160),
        'STANDARD': (400, 200),
        'LARGE': (500, 250),
    }

    def draw_canvas(self, context):
        try:
            self._draw_canvas_impl(context)
        except Exception:
            pass

    def _draw_canvas_impl(self, context):
        curr_area = getattr(bpy.context, "area", None) or getattr(context, "area", None)
        if RENDERFLO_OT_interactive_hdri_canvas._target_area is not None and curr_area is not None:
            if curr_area != RENDERFLO_OT_interactive_hdri_canvas._target_area:
                return

        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            return
        studio = scene.rf_studios[scene.rf_studio_index]
        if not studio.use_hdri_dome:
            return

        cx = self.canvas_x
        cy = self.canvas_y
        cw = self.canvas_w
        ch = self.canvas_h
        th = self.title_h
        fh = self.footer_h

        has_hdr = getattr(studio, "use_custom_hdri", False) and bool(studio.hdri_image)
        t_y1 = cy if self.is_collapsed else (cy + ch)
        t_y2 = t_y1 + th

        if self.is_collapsed:
            draw_2d_quad(cx - 2, t_y1 - 2, cx + cw + 2, t_y2 + 2, (0.01, 0.01, 0.02, 0.75))
            draw_2d_quad(cx - 1, t_y1 - 1, cx + cw + 1, t_y2 + 1, (0.22, 0.26, 0.35, 0.95))
        else:
            draw_2d_quad(cx - 3, cy - fh - 3, cx + cw + 3, cy + ch + th + 3, (0.01, 0.01, 0.02, 0.8))
            draw_2d_quad(cx - 1, cy - fh - 1, cx + cw + 1, cy + ch + th + 1, (0.22, 0.25, 0.32, 0.95))

        draw_2d_quad(cx, t_y1, cx + cw, t_y2, (0.12, 0.13, 0.16, 0.98))

        min_icon = "+" if self.is_collapsed else "-"
        draw_2d_quad(cx + 4, t_y1 + 3, cx + 22, t_y2 - 3, (0.22, 0.24, 0.30, 0.95))
        draw_2d_text(min_icon, cx + 9, t_y1 + 6, size=11, color=(0.85, 0.9, 1.0, 1.0))

        draw_2d_text("KeyShot HDRI", cx + 28, t_y1 + 7, size=10, color=(0.95, 0.95, 0.98, 1.0))
        draw_2d_text(f"[{studio.name}]", cx + 112, t_y1 + 7, size=9, color=(0.35, 0.75, 1.0, 1.0))

        if self.is_collapsed:
            active_p_cnt = sum(1 for p in studio.hdri_pins if p.enabled)
            draw_2d_text(f"({active_p_cnt}/{len(studio.hdri_pins)} Pins)", cx + 175, t_y1 + 7, size=9, color=(0.7, 0.75, 0.85, 0.9))

        bx_close1 = cx + cw - 24
        bx_close2 = cx + cw - 4
        draw_2d_quad(bx_close1, t_y1 + 3, bx_close2, t_y2 - 3, (0.75, 0.2, 0.2, 0.9))
        draw_2d_text("X", bx_close1 + 6, t_y1 + 6, size=10, color=(1.0, 1.0, 1.0, 1.0))

        bx_add1 = cx + cw - 72
        bx_add2 = cx + cw - 28
        draw_2d_quad(bx_add1, t_y1 + 3, bx_add2, t_y2 - 3, (0.18, 0.45, 0.75, 0.95))
        draw_2d_text("+ Pin", bx_add1 + 6, t_y1 + 6, size=9, color=(1.0, 1.0, 1.0, 1.0))

        if self.is_collapsed:
            return

        # Canvas Panorama Background
        drawn_img = False
        if has_hdr and studio.hdri_image:
            drawn_img = draw_2d_image_quad(studio.hdri_image, cx, cy, cx + cw, cy + ch, rotation_deg=studio.hdri_rotation)

        if not drawn_img:
            bc = studio.hdri_base_color
            be = max(0.05, min(1.0, studio.hdri_base_energy * 0.4))
            draw_2d_quad(cx, cy, cx + cw, cy + ch, (bc[0] * be, bc[1] * be, bc[2] * be, 0.92))

        # Grid lines (Equator & Meridian)
        mid_y = cy + ch // 2
        draw_2d_line(cx, mid_y, cx + cw, mid_y, (1.0, 1.0, 1.0, 0.25), line_width=1.0)
        mid_x = cx + cw // 2
        draw_2d_line(mid_x, cy, mid_x, cy + ch, (1.0, 1.0, 1.0, 0.25), line_width=1.0)

        # Draw Pins
        dome_rot = math.radians(studio.hdri_rotation)
        for idx, pin in enumerate(studio.hdri_pins):
            if not pin.enabled:
                continue

            p_th = math.radians(pin.azimuth) + dome_rot
            while p_th > math.pi:
                p_th -= 2.0 * math.pi
            while p_th < -math.pi:
                p_th += 2.0 * math.pi
            p_phi = math.radians(pin.elevation)

            px = cx + int(((p_th + math.pi) / (2.0 * math.pi)) * cw)
            py = cy + int(((p_phi + math.pi * 0.5) / math.pi) * ch)

            is_sel = (idx == self.hover_pin or idx == self.dragging_pin)
            p_col = (pin.color[0], pin.color[1], pin.color[2], 0.95 if pin.enabled else 0.4)
            halo_col = (1.0, 1.0, 0.2, 0.75) if is_sel else (1.0, 1.0, 1.0, 0.35)

            if pin.pin_shape == 'CIRCLE':
                r_px = max(4.0, pin.radius * 35.0)
                draw_2d_circle(px, py, r_px, halo_col, fill=False)
                draw_2d_circle(px, py, max(2.5, r_px * 0.5), p_col, fill=True)
            else:
                draw_2d_rect_pin(px, py, pin.radius, pin.aspect, pin.rotation, halo_col, fill=False)
                draw_2d_rect_pin(px, py, pin.radius * 0.6, pin.aspect, pin.rotation, p_col, fill=True)

            draw_2d_text(pin.name, px + 6, py - 4, size=9, color=(1.0, 1.0, 1.0, 0.85))

        # Footer
        draw_2d_quad(cx, cy - fh, cx + cw, cy, (0.09, 0.10, 0.12, 0.96))
        draw_2d_text("Drag: Move Pin | Click Header: Move | [S/M/L] Size", cx + 8, cy - fh + 6, size=9, color=(0.65, 0.7, 0.8, 0.9))

    def invoke(self, context, event):
        if RENDERFLO_OT_interactive_hdri_canvas._is_running:
            self.cancel(context)
            return {'FINISHED'}

        if context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Open inside 3D Viewport")
            return {'CANCELLED'}

        RENDERFLO_OT_interactive_hdri_canvas._handle = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_canvas, (context,), 'WINDOW', 'POST_PIXEL'
        )
        RENDERFLO_OT_interactive_hdri_canvas._is_running = True
        RENDERFLO_OT_interactive_hdri_canvas._target_area = context.area

        context.window_manager.modal_handler_add(self)
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not RENDERFLO_OT_interactive_hdri_canvas._is_running:
            return {'FINISHED'}

        if event.type in {'ESC'}:
            self.cancel(context)
            return {'FINISHED'}

        mx = event.mouse_region_x
        my = event.mouse_region_y
        scene = context.scene
        studio = scene.rf_studios[scene.rf_studio_index] if (0 <= scene.rf_studio_index < len(scene.rf_studios)) else None

        cx, cy, cw, ch = self.canvas_x, self.canvas_y, self.canvas_w, self.canvas_h
        th, fh = self.title_h, self.footer_h
        t_y1 = cy if self.is_collapsed else (cy + ch)
        t_y2 = t_y1 + th

        # Title bar dragging
        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                # Close button
                if (cx + cw - 24) <= mx <= (cx + cw - 4) and t_y1 <= my <= t_y2:
                    self.cancel(context)
                    return {'FINISHED'}

                # + Pin button
                if (cx + cw - 72) <= mx <= (cx + cw - 28) and t_y1 <= my <= t_y2:
                    bpy.ops.renderflo.add_hdri_pin()
                    context.area.tag_redraw()
                    return {'RUNNING_MODAL'}

                # Collapse button
                if (cx + 4) <= mx <= (cx + 22) and t_y1 <= my <= t_y2:
                    self.is_collapsed = not self.is_collapsed
                    context.area.tag_redraw()
                    return {'RUNNING_MODAL'}

                # Window drag header
                if cx <= mx <= (cx + cw) and t_y1 <= my <= t_y2:
                    self.dragging_window = True
                    self.drag_offset_x = mx - cx
                    self.drag_offset_y = my - cy
                    return {'RUNNING_MODAL'}

                # Canvas pin picking / dragging
                if not self.is_collapsed and studio and cx <= mx <= (cx + cw) and cy <= my <= (cy + ch):
                    dome_rot = math.radians(studio.hdri_rotation)
                    for idx, pin in enumerate(studio.hdri_pins):
                        p_th = math.radians(pin.azimuth) + dome_rot
                        while p_th > math.pi:
                            p_th -= 2.0 * math.pi
                        while p_th < -math.pi:
                            p_th += 2.0 * math.pi
                        p_phi = math.radians(pin.elevation)
                        px = cx + int(((p_th + math.pi) / (2.0 * math.pi)) * cw)
                        py = cy + int(((p_phi + math.pi * 0.5) / math.pi) * ch)

                        if math.hypot(mx - px, my - py) <= 15.0:
                            self.dragging_pin = idx
                            return {'RUNNING_MODAL'}

            elif event.value == 'RELEASE':
                self.dragging_window = False
                if self.dragging_pin != -1:
                    self.dragging_pin = -1
                    if getattr(scene, "rf_auto_save_studios", True) and studio and not studio.is_locked:
                        from .studio_manager import capture_studio_state
                        capture_studio_state(context, studio)
                return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            if self.dragging_window:
                self.canvas_x = mx - self.drag_offset_x
                self.canvas_y = my - self.drag_offset_y
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}

            if self.dragging_pin != -1 and studio and not self.is_collapsed:
                pin = studio.hdri_pins[self.dragging_pin]
                dome_rot = math.radians(studio.hdri_rotation)
                u = max(0.0, min(1.0, (mx - cx) / float(cw)))
                v = max(0.0, min(1.0, (my - cy) / float(ch)))

                p_th = (u * 2.0 * math.pi) - math.pi
                p_phi = (v * math.pi) - (math.pi * 0.5)

                az_deg = math.degrees(p_th - dome_rot)
                while az_deg > 180.0:
                    az_deg -= 360.0
                while az_deg < -180.0:
                    az_deg += 360.0

                pin.azimuth = az_deg
                pin.elevation = math.degrees(p_phi)
                rebuild_studio_hdri_nodes(studio, scene, force=True)
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}

            # Hover detection
            if not self.is_collapsed and studio and cx <= mx <= (cx + cw) and cy <= my <= (cy + ch):
                dome_rot = math.radians(studio.hdri_rotation)
                self.hover_pin = -1
                for idx, pin in enumerate(studio.hdri_pins):
                    p_th = math.radians(pin.azimuth) + dome_rot
                    while p_th > math.pi:
                        p_th -= 2.0 * math.pi
                    while p_th < -math.pi:
                        p_th += 2.0 * math.pi
                    p_phi = math.radians(pin.elevation)
                    px = cx + int(((p_th + math.pi) / (2.0 * math.pi)) * cw)
                    py = cy + int(((p_phi + math.pi * 0.5) / math.pi) * ch)
                    if math.hypot(mx - px, my - py) <= 12.0:
                        self.hover_pin = idx
                        break
                context.area.tag_redraw()

        # Size toggle shortcut keys while hovering canvas
        if event.type in {'S', 'M', 'L'} and event.value == 'PRESS':
            if cx <= mx <= (cx + cw) and (cy - fh) <= my <= (cy + ch + th):
                key_map = {'S': 'COMPACT', 'M': 'STANDARD', 'L': 'LARGE'}
                mode = key_map.get(event.type, 'STANDARD')
                w, h = self.SIZE_PRESETS[mode]
                self.canvas_w = w
                self.canvas_h = h
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def cancel(self, context):
        if RENDERFLO_OT_interactive_hdri_canvas._handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(RENDERFLO_OT_interactive_hdri_canvas._handle, 'WINDOW')
            RENDERFLO_OT_interactive_hdri_canvas._handle = None
        RENDERFLO_OT_interactive_hdri_canvas._is_running = False
        RENDERFLO_OT_interactive_hdri_canvas._target_area = None
        if context and context.area:
            context.area.tag_redraw()


# ------------------------------------------------------------------------
# HDRI Pin CRUD & Image Loading Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_add_hdri_pin(bpy.types.Operator):
    bl_idname = "renderflo.add_hdri_pin"
    bl_label = "Add HDRI Pin"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            self.report({'WARNING'}, "No active Studio.")
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        new_pin = studio.hdri_pins.add()
        new_pin.name = f"Pin_{len(studio.hdri_pins):02d}"
        new_pin.azimuth = 45.0 + (len(studio.hdri_pins) - 1) * 30.0
        while new_pin.azimuth > 180.0:
            new_pin.azimuth -= 360.0
        new_pin.elevation = 35.0
        new_pin.radius = 0.18
        new_pin.falloff = 0.15
        new_pin.energy = 15.0
        new_pin.color = (1.0, 1.0, 1.0)
        new_pin.enabled = True

        rebuild_studio_hdri_nodes(studio, scene)
        update_studio_dome_visualizer(studio, context)
        self.report({'INFO'}, f"Added '{new_pin.name}' to '{studio.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_remove_hdri_pin(bpy.types.Operator):
    bl_idname = "renderflo.remove_hdri_pin"
    bl_label = "Remove HDRI Pin"
    bl_options = {'REGISTER', 'UNDO'}

    pin_index: bpy.props.IntProperty(default=0)

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        if 0 <= self.pin_index < len(studio.hdri_pins):
            p_name = studio.hdri_pins[self.pin_index].name
            studio.hdri_pins.remove(self.pin_index)
            rebuild_studio_hdri_nodes(studio, scene)
            update_studio_dome_visualizer(studio, context)
            self.report({'INFO'}, f"Removed HDRI Pin '{p_name}'")
        return {'FINISHED'}


class RENDERFLO_OT_duplicate_hdri_pin(bpy.types.Operator):
    bl_idname = "renderflo.duplicate_hdri_pin"
    bl_label = "Duplicate HDRI Pin"
    bl_options = {'REGISTER', 'UNDO'}

    pin_index: bpy.props.IntProperty(default=0)

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        if 0 <= self.pin_index < len(studio.hdri_pins):
            src = studio.hdri_pins[self.pin_index]
            dup = studio.hdri_pins.add()
            dup.name = f"{src.name}_Copy"
            dup.enabled = src.enabled
            dup.pin_shape = src.pin_shape
            dup.azimuth = src.azimuth + 15.0
            while dup.azimuth > 180.0:
                dup.azimuth -= 360.0
            dup.elevation = src.elevation
            dup.radius = src.radius
            dup.aspect = src.aspect
            dup.rotation = src.rotation
            dup.falloff = src.falloff
            dup.energy = src.energy
            dup.color = src.color

            rebuild_studio_hdri_nodes(studio, scene)
            update_studio_dome_visualizer(studio, context)
            self.report({'INFO'}, f"Duplicated '{src.name}' -> '{dup.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_load_hdri_image(bpy.types.Operator, ImportHelper):
    bl_idname = "renderflo.load_hdri_image"
    bl_label = "Load HDRI Environment"
    bl_description = "Browse and load an external .hdr, .exr, or panorama image for the studio environment"
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob: bpy.props.StringProperty(
        default="*.hdr;*.exr;*.png;*.jpg;*.jpeg;*.tif;*.tiff",
        options={'HIDDEN'},
        maxlen=255,
    )

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            self.report({'WARNING'}, "No active Studio.")
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        if not self.filepath:
            return {'CANCELLED'}

        try:
            img = bpy.data.images.load(self.filepath, check_existing=True)
            try:
                if hasattr(img, "gl_load"):
                    img.gl_load()
            except Exception:
                pass
            studio.hdri_image = img
            studio.use_custom_hdri = True
            rebuild_studio_hdri_nodes(studio, scene, force=True)
            for screen in bpy.data.screens:
                for area in screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
            self.report({'INFO'}, f"Loaded HDRI: '{img.name}'")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load image: {e}")
            return {'CANCELLED'}


class RENDERFLO_OT_clear_hdri_image(bpy.types.Operator):
    bl_idname = "renderflo.clear_hdri_image"
    bl_label = "Clear HDRI"
    bl_description = "Remove custom HDRI environment map from this studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            return {'CANCELLED'}

        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.is_locked:
            self.report({'WARNING'}, "Active Studio is locked.")
            return {'CANCELLED'}

        studio.hdri_image = None
        studio.use_custom_hdri = False
        rebuild_studio_hdri_nodes(studio, scene, force=True)
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        self.report({'INFO'}, "Cleared custom HDRI map.")
        return {'FINISHED'}


class RENDERFLO_OT_refresh_hdri_preview(bpy.types.Operator):
    bl_idname = "renderflo.refresh_hdri_preview"
    bl_label = "Refresh HDRI Preview"
    bl_description = "Force regeneration of the 2D equirectangular panorama map and 3D visualizer dome"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            rebuild_studio_hdri_nodes(studio, scene, force=True)
            generate_hdri_equirectangular_preview(studio)
            update_studio_dome_visualizer(studio, context)
            for area in context.screen.areas:
                area.tag_redraw()
            self.report({'INFO'}, f"Regenerated HDRI Preview for '{studio.name}'")
        return {'FINISHED'}


lighting_classes = (
    RENDERFLO_OT_spawn_studio_light,
    RENDERFLO_OT_toggle_studio_light,
    RENDERFLO_OT_remove_studio_light,
    RENDERFLO_OT_place_highlight_modal,
    RENDERFLO_OT_place_hdri_pin_modal,
    RENDERFLO_OT_interactive_hdri_canvas,
    RENDERFLO_OT_add_hdri_pin,
    RENDERFLO_OT_remove_hdri_pin,
    RENDERFLO_OT_duplicate_hdri_pin,
    RENDERFLO_OT_load_hdri_image,
    RENDERFLO_OT_clear_hdri_image,
    RENDERFLO_OT_refresh_hdri_preview,
)


def register():
    for cls in lighting_classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(lighting_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

