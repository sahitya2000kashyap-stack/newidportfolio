# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.1.0 — Flex Deform & Parametric Cable Routing Suite.
1-Click Curve/Lattice Strap Bender for wearables and Interactive Port-to-Port Cable Router.
"""

import bpy
import math
from mathutils import Vector, Matrix
from bpy_extras import view3d_utils

from ..state import (
    MASTER_FLEX_COLL,
    CABLE_PREFIX,
    STRAP_PREFIX,
    GROUND_PLANE_NAME,
    BACKDROP_OBJ_NAME,
    DOME_VISUALIZER_OBJ,
    DOME_PIN_PREFIX,
    CUTAWAY_BOX_NAME,
    TARGET_EMPTY_NAME,
    DECAL_PREFIX,
    REST_LOCATION_PROP,
    REST_ROTATION_PROP,
)
from .studio_manager import ensure_collection


# ------------------------------------------------------------------------
# Exploded View & Turntable Rotation Engine
# ------------------------------------------------------------------------

def get_product_objects(scene):
    """Returns all product mesh/curve/surface objects, excluding staging, lighting, and helper entities."""
    excluded_names = {
        GROUND_PLANE_NAME,
        BACKDROP_OBJ_NAME,
        DOME_VISUALIZER_OBJ,
        CUTAWAY_BOX_NAME,
        TARGET_EMPTY_NAME,
    }
    product_objs = []
    for obj in scene.objects:
        if obj.name in excluded_names:
            continue
        if (
            obj.name.startswith(DOME_PIN_PREFIX)
            or obj.name.startswith("Studio_Light_")
            or obj.name.startswith(DECAL_PREFIX)
        ):
            continue
        if obj.type in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META'}:
            product_objs.append(obj)
    return product_objs


def get_assembly_roots(scene):
    """Finds Assembly_* empty roots in the scene."""
    return [obj for obj in scene.objects if obj.type == 'EMPTY' and obj.name.startswith("Assembly_")]


def update_exploded_view(scene, factor):
    """
    Parametric non-destructive exploded view of product parts.
    Explodes components along their radial/axial vectors relative to the product center.
    At factor = 0%, components restore to their rest positions.
    """
    objs = get_product_objects(scene)
    if not objs:
        return

    # Find root parts (avoid compounding offsets on child sub-parts)
    top_objs = [o for o in objs if o.parent not in objs]
    if not top_objs:
        top_objs = objs

    # Determine reference center
    target_obj = bpy.data.objects.get(TARGET_EMPTY_NAME)
    if target_obj:
        center = target_obj.location.copy()
    else:
        assemblies = get_assembly_roots(scene)
        if assemblies:
            center = assemblies[0].location.copy()
        else:
            center = sum((o.matrix_world.translation for o in top_objs), Vector()) / max(1, len(top_objs))

    # Calculate assembly scale for proportional explosion distance
    dists = [(o.matrix_world.translation - center).length for o in top_objs]
    assembly_scale = max(0.1, max(dists)) if dists else 1.0

    if factor <= 0.001:
        # Restore to rest locations
        for obj in top_objs:
            if REST_LOCATION_PROP in obj:
                try:
                    obj.location = Vector(obj[REST_LOCATION_PROP])
                except Exception:
                    pass
            # Update cache to current rest position
            obj[REST_LOCATION_PROP] = list(obj.location)
    else:
        t = factor / 100.0
        for obj in top_objs:
            if REST_LOCATION_PROP not in obj:
                obj[REST_LOCATION_PROP] = list(obj.location)

            rest_loc = Vector(obj[REST_LOCATION_PROP])
            # Calculate direction vector from center
            parent_offset = obj.parent.location if (obj.parent and obj.parent.type == 'EMPTY') else center
            diff = rest_loc - parent_offset
            if diff.length < 1e-4:
                diff = Vector((0.0, 0.0, 0.05 * assembly_scale))

            dir_norm = diff.normalized()
            # Smooth exponential/linear explosion curve
            offset = diff * (t * 1.5) + dir_norm * (assembly_scale * 0.3 * t)
            obj.location = rest_loc + offset


def update_turntable_rotation(scene, angle_rad):
    """
    Rotates the product assembly around the optical center Z-axis.
    Smoothly updates Assembly_* root empties or root product components.
    `angle_rad` is in radians as provided by RNA subtype='ANGLE'.
    """
    assemblies = get_assembly_roots(scene)
    if assemblies:
        for asm in assemblies:
            if angle_rad <= 0.001:
                if REST_ROTATION_PROP in asm:
                    try:
                        asm.rotation_euler = Vector(asm[REST_ROTATION_PROP])
                    except Exception:
                        pass
                asm[REST_ROTATION_PROP] = list(asm.rotation_euler)
            else:
                if REST_ROTATION_PROP not in asm:
                    asm[REST_ROTATION_PROP] = list(asm.rotation_euler)
                rest_rot = Vector(asm[REST_ROTATION_PROP])
                asm.rotation_euler.z = rest_rot.z + angle_rad
        return

    # Fallback when no Assembly_* empty exists: rotate root product objects around center
    objs = get_product_objects(scene)
    root_objs = [o for o in objs if o.parent is None or o.parent not in objs]
    if not root_objs:
        return

    target_obj = bpy.data.objects.get(TARGET_EMPTY_NAME)
    if target_obj:
        center = target_obj.location.copy()
    else:
        center = sum((o.matrix_world.translation for o in root_objs), Vector()) / max(1, len(root_objs))

    rot_matrix = Matrix.Rotation(angle_rad, 4, 'Z')

    for obj in root_objs:
        if angle_rad <= 0.001:
            if REST_LOCATION_PROP in obj:
                try:
                    obj.location = Vector(obj[REST_LOCATION_PROP])
                except Exception:
                    pass
            if REST_ROTATION_PROP in obj:
                try:
                    obj.rotation_euler = Vector(obj[REST_ROTATION_PROP])
                except Exception:
                    pass
            obj[REST_LOCATION_PROP] = list(obj.location)
            obj[REST_ROTATION_PROP] = list(obj.rotation_euler)
        else:
            if REST_LOCATION_PROP not in obj:
                obj[REST_LOCATION_PROP] = list(obj.location)
            if REST_ROTATION_PROP not in obj:
                obj[REST_ROTATION_PROP] = list(obj.rotation_euler)

            rest_loc = Vector(obj[REST_LOCATION_PROP])
            rest_rot = Vector(obj[REST_ROTATION_PROP])

            rel = rest_loc - center
            rel_4 = Vector((rel.x, rel.y, rel.z, 1.0))
            rot_rel = (rot_matrix @ rel_4).xyz
            obj.location = center + rot_rel
            obj.rotation_euler.z = rest_rot.z + angle_rad



# ------------------------------------------------------------------------
# Cable Material Generator
# ------------------------------------------------------------------------

def get_or_create_cable_material(braided=True):
    mat_name = "RenderFlo_Cable_Braided" if braided else "RenderFlo_Cable_Silicone"
    mat = bpy.data.materials.get(mat_name)
    if not mat:
        mat = bpy.data.materials.new(name=mat_name)
        mat.use_nodes = True
        nt = mat.node_tree
        nt.nodes.clear()

        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.location = (50, 0)

        out = nt.nodes.new("ShaderNodeOutputMaterial")
        out.location = (300, 0)
        nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

        if braided:
            tc = nt.nodes.new("ShaderNodeTexCoord")
            tc.location = (-600, 0)
            wave = nt.nodes.new("ShaderNodeTexWave")
            wave.location = (-400, 0)
            wave.wave_type = 'BANDS'
            wave.inputs["Scale"].default_value = 350.0
            nt.links.new(tc.outputs["Generated"], wave.inputs["Vector"])

            bump = nt.nodes.new("ShaderNodeBump")
            bump.location = (-180, 0)
            bump.inputs["Strength"].default_value = 0.25
            bump.inputs["Distance"].default_value = 0.0003
            nt.links.new(wave.outputs["Color"], bump.inputs["Height"])

            col_socket = bsdf.inputs.get("Base Color") or bsdf.inputs.get("Color")
            if col_socket:
                col_socket.default_value = (0.12, 0.12, 0.13, 1.0)
            if "Roughness" in bsdf.inputs:
                bsdf.inputs["Roughness"].default_value = 0.65
            nt.links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])
        else:
            col_socket = bsdf.inputs.get("Base Color") or bsdf.inputs.get("Color")
            if col_socket:
                col_socket.default_value = (0.85, 0.85, 0.86, 1.0)
            if "Roughness" in bsdf.inputs:
                bsdf.inputs["Roughness"].default_value = 0.42

    return mat


# ------------------------------------------------------------------------
# 1-Click Strap Bender
# ------------------------------------------------------------------------

class RENDERFLO_OT_apply_strap_bender(bpy.types.Operator):
    bl_idname = "renderflo.apply_strap_bender"
    bl_label = "1-Click Strap & Band Bender"
    bl_description = "Add parametric Bezier curve deformer to selected watch strap, belt, or wearable with wrist curvature handles"
    bl_options = {'REGISTER', 'UNDO'}

    bend_angle: bpy.props.FloatProperty(name="Bend Angle (deg)", default=75.0, min=0.0, max=180.0)
    wrist_radius: bpy.props.FloatProperty(name="Wrist Radius (mm)", default=32.0, min=5.0, max=200.0)

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type not in {'MESH'}:
            self.report({'WARNING'}, "Select a 3D strap mesh to apply bender.")
            return {'CANCELLED'}

        scene = context.scene
        flex_coll = ensure_collection(scene, MASTER_FLEX_COLL)

        # 1. Inspect mesh bounds
        bb = [Vector(corner) for corner in obj.bound_box]
        min_v = Vector((min(p.x for p in bb), min(p.y for p in bb), min(p.z for p in bb)))
        max_v = Vector((max(p.x for p in bb), max(p.y for p in bb), max(p.z for p in bb)))
        dim = max_v - min_v

        # Determine primary length axis
        axis = 'Y'
        if dim.x > dim.y and dim.x > dim.z:
            axis = 'X'
        elif dim.z > dim.x and dim.z > dim.y:
            axis = 'Z'

        length = getattr(dim, axis.lower())
        center = (min_v + max_v) * 0.5

        # 2. Build Bezier curve
        curve_data = bpy.data.curves.new(name=f"{STRAP_PREFIX}Curve", type='CURVE')
        curve_data.dimensions = '3D'
        spline = curve_data.splines.new('BEZIER')
        spline.bezier_points.add(2)  # 3 points total

        p0, p1, p2 = spline.bezier_points[0], spline.bezier_points[1], spline.bezier_points[2]
        r = (self.wrist_radius * 0.001)

        if axis == 'Y':
            p0.co = Vector((center.x, center.y - length * 0.5, center.z))
            p1.co = Vector((center.x, center.y, center.z - r * 0.5))
            p2.co = Vector((center.x, center.y + length * 0.5, center.z - r))
        else:
            p0.co = Vector((center.x - length * 0.5, center.y, center.z))
            p1.co = Vector((center.x, center.y, center.z - r * 0.5))
            p2.co = Vector((center.x + length * 0.5, center.y, center.z - r))

        for p in (p0, p1, p2):
            p.handle_left_type = 'AUTO'
            p.handle_right_type = 'AUTO'

        curve_obj = bpy.data.objects.new(f"{STRAP_PREFIX}{obj.name}_Deformer", curve_data)
        curve_obj.matrix_world = obj.matrix_world.copy()
        flex_coll.objects.link(curve_obj)

        # 3. Add Curve Modifier to strap mesh
        mod = obj.modifiers.new(name="RenderFlo_StrapBend", type='CURVE')
        mod.object = curve_obj
        mod.deform_axis = f"POS_{axis}"

        self.report({'INFO'}, f"Applied Strap Bender to '{obj.name}'")
        return {'FINISHED'}


# ------------------------------------------------------------------------
# Parametric Cable Router
# ------------------------------------------------------------------------

class RENDERFLO_OT_route_cable(bpy.types.Operator):
    bl_idname = "renderflo.route_cable"
    bl_label = "Route Cable Between Selected Objects"
    bl_description = "Generate parametric curved cable with catenary gravity sag between two selected objects or empties"
    bl_options = {'REGISTER', 'UNDO'}

    diameter_mm: bpy.props.FloatProperty(name="Cable Diameter (mm)", default=4.0, min=0.5, max=50.0)
    sag_factor: bpy.props.FloatProperty(name="Gravity Sag Factor", default=0.25, min=0.0, max=2.0)
    braided: bpy.props.BoolProperty(name="Braided Nylon Material", default=True)

    def execute(self, context):
        sel = [o for o in context.selected_objects if o.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}]
        if len(sel) < 2:
            self.report({'WARNING'}, "Select 2 objects or empties as start and end ports.")
            return {'CANCELLED'}

        p1_loc = sel[0].matrix_world.translation
        p2_loc = sel[1].matrix_world.translation

        self._build_cable(context, p1_loc, p2_loc, name_suffix=f"{sel[0].name}_{sel[1].name}")
        return {'FINISHED'}

    def _build_cable(self, context, start_pt, end_pt, name_suffix=""):
        scene = context.scene
        flex_coll = ensure_collection(scene, MASTER_FLEX_COLL)

        curve_data = bpy.data.curves.new(name=f"{CABLE_PREFIX}Data", type='CURVE')
        curve_data.dimensions = '3D'
        curve_data.bevel_depth = (self.diameter_mm * 0.001) * 0.5
        curve_data.bevel_resolution = 4
        curve_data.resolution_u = 24

        spline = curve_data.splines.new('BEZIER')
        spline.bezier_points.add(1)  # 2 endpoints

        dist = (end_pt - start_pt).length
        mid_pt = (start_pt + end_pt) * 0.5
        mid_pt.z -= dist * self.sag_factor

        # Add middle sag point
        spline.bezier_points.add(1)
        bp0, bp1, bp2 = spline.bezier_points[0], spline.bezier_points[1], spline.bezier_points[2]

        bp0.co = start_pt
        bp1.co = mid_pt
        bp2.co = end_pt

        for bp in (bp0, bp1, bp2):
            bp.handle_left_type = 'AUTO'
            bp.handle_right_type = 'AUTO'

        c_obj = bpy.data.objects.new(f"{CABLE_PREFIX}{name_suffix}", curve_data)
        flex_coll.objects.link(c_obj)

        mat = get_or_create_cable_material(braided=self.braided)
        c_obj.data.materials.append(mat)

        for o in context.selected_objects:
            o.select_set(False)
        c_obj.select_set(True)
        context.view_layer.objects.active = c_obj

        self.report({'INFO'}, f"Routed Cable ({self.diameter_mm}mm, Sag: {self.sag_factor})")
        return c_obj


class RENDERFLO_OT_pick_cable_points_modal(bpy.types.Operator):
    bl_idname = "renderflo.pick_cable_points_modal"
    bl_label = "Click 2 Points on Model to Route Cable"
    bl_description = "Click on Start port then End port/floor to spawn a parametric draped cable"
    bl_options = {'REGISTER', 'UNDO'}

    _point1 = None

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            context.window.cursor_modal_restore()
            return {'CANCELLED'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            region = context.region
            rv3d = context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, obj, matrix = context.scene.ray_cast(depsgraph, ray_origin, view_vector)

            if result:
                if self._point1 is None:
                    self._point1 = location.copy()
                    self.report({'INFO'}, "Start point set. Now click target port / floor...")
                    return {'RUNNING_MODAL'}
                else:
                    context.window.cursor_modal_restore()
                    cable_op = RENDERFLO_OT_route_cable()
                    cable_op.diameter_mm = context.scene.rf_cable_settings.cable_diameter
                    cable_op.sag_factor = context.scene.rf_cable_settings.slack_sag
                    cable_op.braided = context.scene.rf_cable_settings.braided_look
                    cable_op._build_cable(context, self._point1, location, name_suffix="Routed")
                    return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self._point1 = None
        if context.area.type == 'VIEW_3D':
            context.window.cursor_modal_set('CROSSHAIR')
            context.window_manager.modal_handler_add(self)
            self.report({'INFO'}, "Click port/location 1 for Cable start...")
            return {'RUNNING_MODAL'}
        return {'CANCELLED'}


flex_classes = (
    RENDERFLO_OT_apply_strap_bender,
    RENDERFLO_OT_route_cable,
    RENDERFLO_OT_pick_cable_points_modal,
)


def register():
    for cls in flex_classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(flex_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

