# ID RenderFlo — How-To Guide & Manual

**Universal Industrial Design Studio Suite & CAD Pipeline for Blender**  
*Created by Sahitya Kashyap ([sahityakashyap.in](https://sahityakashyap.in))*

---

## 🧭 Introduction & Layout Overview

**ID RenderFlo** transforms Blender into a dedicated, KeyShot-style product visualization studio tailored specifically for industrial designers, mechanical engineers, and hardware design teams.

The workflow is organized into two primary interfaces:
1. **Persistent Topbar Ribbon**: Located at the top of the Blender window (next to `File`, `Edit`, `Window`, `Help`) for 1-click access to the most vital actions at all times.
2. **6-Stage N-Panel Dock**: Located in the 3D Viewport sidebar (press `N` > select **ID RenderFlo** tab), guiding you step-by-step through the product visualization lifecycle:
   ```
   [ CAD Bridge ] → [ Studio ] → [ Lighting ] → [ CMF ] → [ Decals & FX ] → [ Render & DXF ]
   ```
3. **Wide Floating Studio Dashboard**: Press **`Alt + Shift + R`** anywhere in the 3D Viewport to summon the HUD dashboard for multi-studio framing, bloom tweaks, part visibility isolation, and batch review.

---

## ⚡ The Topbar Quick Ribbon

The topbar ribbon keeps your entire design workflow accessible regardless of which sidebar panel or workspace you are currently viewing:

```
[Import CAD (.STEP/.3DM)] [Hot-Reload CAD] | Studio: [Hero_Shot ▾] [🔒] [▾] [+] | CMF: [Matte_Black ▾] [✏️] [📋] | Ratio: [4:5 ▾]
```

* **Import CAD**: Opens file browser pre-filtered for `.step`, `.stp`, and Rhino `.3dm` files.
* **Hot-Reload CAD**: 1-click reload of the active CAD model. If you make changes in Rhino, Fusion 360, or SolidWorks, re-export to the same file and click **Hot-Reload CAD** — your materials, decals, and lighting are completely preserved!
* **Studio**: Quick selector for camera angles and framing. Click the **Padlock [🔒]** to freeze camera transforms.
* **CMF**: Active Color, Material & Finish colorway selector. Click **[✏️]** to rename or **[📋]** to duplicate the current colorway.
* **Ratio**: Instant 1-click aspect ratio cropping (`1:1 Square`, `4:5 Portrait`, `16:9 Landscape`, `9:16 Story`, `2.39:1 Cinematic`).

---

## 🛠️ Step-by-Step 6-Stage Workflow

### Stage 1: CAD Bridge (Import & Unit Calibration)
> **Standalone Edition Setup**: If not already installed, click **Install CAD Engine Files (OCC & Rhino)** in the CAD Bridge tab or Preferences to download/activate the OpenCASCADE and Rhino3DM kernels in 1 click, or click **Browse Offline Archive** to install from a downloaded wheel or zip.

1. In the N-Panel, select the **CAD Bridge** tab.
2. Click **Import CAD (.STEP / .3DM)**.
3. Configure import settings in the operator file dialog:
   * **Tessellation Quality**: Choose between *Ultra Fine (0.02mm)* for extreme closeups, *High Quality (0.08mm)* (recommended default), *Medium*, or *Custom*.
   * **CAD Up-Axis**: Defaulted to **Z-Up** (matches Rhino, Fusion 360, and Blender). Select *Y-Up* if exporting from legacy SolidWorks files.
   * **CAD Units**: Defaulted to **Millimeters (True Scale / Recommended - 0.001x)**.
     > **Why 0.001x?** Blender uses meters as its internal base unit. Since CAD systems export coordinates in millimeters, scaling by 0.001x converts 100mm into 0.10m. This ensures physical camera depth of field, AgX exposure, and Cycles lighting behave identically to the real world.
   * **Center on X/Y Origin & Snap Base to Floor**: Automatically centers your product and puts its base on the ground plane (Z = 0).
   * **Weighted Normals (Clean Fillets)**: Preserves custom CAD split normals for razor-sharp fillets and chamfers without dark shading artifacts.
4. **1-Click CAD Hot-Reload**: Whenever geometry changes in your CAD software, simply hit **Hot-Reload CAD** to update the mesh while retaining all assigned materials, decals, and camera framing.

---

### Stage 2: Studio Manager (Cameras, Framing & Samples)
A **Studio** in ID RenderFlo is a complete state snapshot: it captures camera angle, focal length, aspect ratio, depth-of-field, active CMF colorway, active lighting rig, custom sample count, per-studio bloom glow FX, and isolated part visibility.

1. Select the **Studio** tab.
2. Click **+ Add Studio** to create a new shot (e.g., `Hero_Front`, `Isometric_Exploded`, `Macro_Detail`).
3. **Reorganizing Studios (`▲` / `▼`)**: Use the up and down chevron buttons next to the studio list to easily reorder camera shots, arrange your presentation flow, and set the batch render sequence.
4. Frame your product in the 3D Viewport:
   * **Focal Length**: Choose from industrial design presets (35mm Wide, 50mm Normal, 85mm Portrait, 105mm Macro) or adjust the slider.
   * **Aspect Ratio**: Select standard social and web dimensions (`1:1`, `4:5`, `16:9`, `9:16`, `4:3`, `2.39:1`).
   * **Camera Lock [🔒]**: Click the padlock to lock the camera angle and prevent accidental panning or zooming while tweaking materials.
   * **Custom Render Samples**: Check **Custom Samples** to assign independent sample counts per studio (e.g. 128 samples for draft angles, 1024 samples for hero closeups). Cycles automatically synchronizes sample limits when switching studios.
   * **Model Sets & Exploded Positions**:
     * **Model Sets [Toggle]**: Isolates collection visibility per studio. Toggle on to show/hide specific CAD assemblies or component options independently in each studio.
     * **Exploded / Part Pos [Toggle]**: Isolates object transforms (locations and rotations) per studio. Create an exploded view studio, enable **Exploded / Part Pos**, and translate parts apart. Click **Store Current Positions** to snapshot the exploded state. When you switch back to your assembled studio, all components automatically return to their rest/assembled positions! Click **Reset to Assembled** anytime to snap components back to rest.
   * **Part Visibility & Component Isolation [Toggle]**:
     * Enable **Part Visibility** to capture hidden/shown parts independently for the active studio.
     * Hide an outer casing, cover, or bezel in the 3D Viewport or Outliner to reveal internal mechanisms or electronics.
     * Click **Store Hidden Parts** to lock this hidden state strictly to this studio.
     * Click **Show All Parts** to quickly unhide all objects.
     * When switching between studios, RenderFlo automatically restores and hides parts dynamically!
   * **Bloom / Glow Studio FX [Toggle]**:
     * Expand **Bloom / Glow Studio FX** in the Studio tab.
     * Check **Bloom / Glow** to add realistic optical glow to LEDs, emissive buttons, or specular glints for the active studio snapshot.
     * Fine-tune **Intensity** (glow brightness multiplier), **Radius** (blur spread), **Threshold** (luminance cutoff), and **Color Tint**.
     * Keep **Show Live in Viewport** enabled to preview bloom interactively in real-time through the camera with Cycles or EEVEE!
     * Cleanly evaluates during offline F12 rendering, Batch Queue rendering, and CMF Matrix variations with native alpha preservation for transparent PNG renders.

---

### Stage 3: Lighting (HDRI Dome, Pins & Physical Softboxes)
ID RenderFlo provides a simultaneous dual-lighting engine:
* **Procedural HDRI Dome**:
  * Set the global ambient lighting intensity and dome rotation.
  * Adjust background color or environment brightness.
* **Interactive 2D Pin Canvas**:
  * Click **Launch 2D Pin Canvas** to open an interactive latitude/longitude dome overlay directly in the viewport.
  * Add **Round Pins** (specular highlights) or **Softbox Strips** (elongated rectangular reflections).
  * **Normal Raycast Eyedropper**: Click the eyedropper icon and click anywhere on your 3D product surface — RenderFlo automatically calculates the exact dome azimuth and elevation to project the specular reflection right onto that edge!
* **Physical Studio Softboxes**:
  * Click **+ Key Light**, **+ Fill Light**, or **+ Rim Light** to spawn physical studio light fixtures aimed at the product optical center with automatic power scaling.

---

### Stage 4: CMF Matrix (Color, Material & Finish)
1. Select the **CMF** tab.
2. Create and manage colorways (e.g., `Matte_Black`, `Sage_Green`, `Raw_Titanium`):
   * Click **+ New Variant** or **Duplicate Colorway**.
   * Switch between colorways in 1 click; the scene updates material assignments in real-time.
3. Choose from built-in industrial design material libraries:
   * **Plastics & Synthetics**: Mold-Tech VDI 3400 texture standards (VDI 12 High Polish through VDI 36 Heavy Spark Erosion), High-Gloss ABS, Soft-Touch TPU/Silicone.
   * **Metals**: Bead-blasted aluminum, anodized satin, brushed stainless steel, raw machined metal with anisotropy.
   * **Transparents**: Optical grade Polycarbonate (PC), PMMA / Acrylic, tinted glass.
4. **Zebra Curvature Analysis**: Click the **Zebra** button in the ribbon to inspect Class-A surface curvature continuity across fillets and parting lines.

---

### Stage 5: Decals & Stickers (1-Click Conformal Surface Dropper)
1. Select the **Decals & FX** tab.
2. Click **1-Click Drop Graphic on Surface** and pick your PNG/JPEG logo or icon.
3. Click anywhere on your CAD model's 3D surface:
   * The graphic plane automatically aligns to the local surface normal with an anti-Z-fighting offset.
4. Refine decal placement:
   * **Surface Normal Spin**: Rotate the decal by ±15° or ±90°, or use interactive mouse wheel spin.
   * **Reposition / Slide**: Click **Click New Spot on Surface** or **Slide on Surface** to glide the decal across curved geometry.
   * **Conform Sticker**: Applies subdivision and shrinkwrap to wrap flexible stickers seamlessly over complex curvature.
5. **Live Section Cutaway Box**: Click **Generate Cutaway Box** to create an interactive boolean slicing cube that exposes interior components and internal architecture without destructive edits.

---

### Stage 6: Render & Manufacturing Export (DXF)
1. Select the **Render & DXF** tab.
2. **Output Directory**:
   * Set your custom destination folder using the **Render Output Directory** path picker.
   * Click **Open Folder [📁]** at any time to open the folder directly in your system file manager.
3. **GPU Batch Queue**:
   * Review all configured studios. Check/uncheck individual studios for rendering.
   * Click **BATCH RENDER ALL STUDIOS** — RenderFlo sequentially switches studios, applies camera transforms, active CMF variants, custom sample limits, and bloom effects, saving timestamped high-resolution frames automatically.
4. **Manufacturing Export (DXF)**:
   * Select a planar or sheet-metal part from your assembly.
   * Click **1-Click Export DXF** to generate clean 2D vector CAD curves for laser cutting, CNC routing, and manufacturing flat patterns.

---

## ⌨️ Shortcut Reference

| Shortcut | Action | Scope |
| :--- | :--- | :--- |
| **`Alt + Shift + R`** | Toggle Wide Floating Studio Dashboard | 3D Viewport |
| **`N`** | Toggle Sidebar (ID RenderFlo Dock) | 3D Viewport |
| **`G` / `R` / `S`** | Move / Rotate / Scale Selected Decal or Lamp | 3D Viewport |
| **`Shift + Middle Click`** | Pan Viewport Camera (when unlocked) | 3D Viewport |
| **`Ctrl + Middle Click`** | Zoom Viewport Camera (when unlocked) | 3D Viewport |

---

## 💡 Pro Tips for Industrial Designers
* **Keep Z-Up and Millimeters Default**: Never scale your CAD imports manually by arbitrary numbers. ID RenderFlo's `0.001x` True Scale matches real-world optics and saves you hours of lighting recalibration.
* **Lock Hero Shots**: Once you find the perfect hero camera angle, immediately click the **Padlock [🔒]** in the Topbar. This allows you to pan around the scene to tweak materials and decals without losing your camera composition.
* **Hot-Reload Iteration**: When client or engineering revisions come in, do not re-assign materials from scratch! Keep part names consistent in Rhino or SolidWorks, overwrite the STEP/3DM file, and click **Hot-Reload CAD**. All CMF assignments and sticker positions will map right back onto the updated geometry.
