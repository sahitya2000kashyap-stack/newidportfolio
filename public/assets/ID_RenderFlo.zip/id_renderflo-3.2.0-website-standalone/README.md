# ID RenderFlo (v3.1.0) — Standalone Edition

**Universal Industrial Design Studio Suite & Parametric CAD Pipeline for Blender**  
*Created by Sahitya Kashyap ([sahityakashyap.in](https://sahityakashyap.in))*

---

## 🚀 Overview

**ID RenderFlo** transforms Blender into a dedicated, KeyShot-style product visualization studio tailored specifically for industrial designers, mechanical engineers, and hardware design teams.

Equipped with a native **Rhino (`.3dm`) & STEP (`.step`/`.stp`) CAD Importer**, **1-Click CAD Hot-Reload**, **KeyShot-style Multi-Studio Snapshots**, **Per-Studio Bloom & Glow FX**, **Part Visibility & Isolation**, **Procedural HDRI Dome & 2D Pin Canvas**, **CMF Matrix (Color, Material & Finish)**, **Raycast Conformal Decal Dropper**, and **GPU Batch Rendering with DXF Manufacturing Export**.

---

## ✨ Key Features in v3.1.0

* **✨ Real-Time Per-Studio Bloom & Glow FX (Cycles & EEVEE)**:
  * Independent radiance glow and bloom controls per studio snapshot (`Intensity`, `Radius`, `Threshold`, `Color Tint`).
  * Live GPU Viewport Compositor feedback with zero render stalls, automatic camera sync, and transparent PNG alpha channel preservation.
  * Synchronized rendering across interactive viewport, F12 offline frames, Batch Studio Queue, and CMF Matrix variations.
* **🔀 Studio Shot List Reordering**:
  * One-click chevron arrows (`▲` / `▼`) in the N-panel and Studio Dashboard to reorder studios, organize presentation storylines, and set batch render sequence.
* **👁️ Part Visibility & Isolation per Studio**:
  * Snapshot and isolate individual hidden or shown CAD parts per camera angle (e.g. hide casing in an exploded or internal view while keeping it visible in hero product shots).
  * 1-Click `Store Hidden Parts` and `Show All Parts` operators.
* **🔒 Camera Isolation & Locking Stability**:
  * Bulletproof camera assignment per studio preventing accidental overrides or camera crosstalk when switching between unlocked shots.
* **Persistent Topbar Ribbon**: Immediate access to `Import CAD`, `Hot-Reload CAD`, `Studio Selector`, `CMF Matrix`, and `Aspect Ratio Presets` directly in Blender's main topbar.
* **6-Stage Industrial Design Lifecycle Dock**:
  1. `CAD Bridge`: Native STEP & Rhino .3dm import with Z-Up and True Millimeter (0.001x) scaling defaults.
  2. `Studios`: Camera snapshots, focal lengths, camera padlock protection, custom render samples, bloom FX, and part visibility.
  3. `Lighting`: Procedural HDRI dome, interactive 2D pin canvas with reflection raycasting, and physical studio softboxes.
  4. `CMF Matrix`: Instant colorway switching, Mold-Tech VDI 3400 textures, anodized satin, and brushed metal presets.
  5. `Decals & FX`: 1-click raycast sticker placement, normal rotation, conformal shrinkwrap, and live boolean section cutaways.
  6. `Render & DXF`: GPU batch queue, custom output directory selector with 1-click open folder, and 2D DXF manufacturing export.
* **1-Click CAD Hot-Reload**: Re-import engineering updates from Rhino, Fusion 360, or SolidWorks in 1 click without losing materials, lighting, or camera compositions.
* **Wide Floating Studio Dashboard**: Press **`Alt + Shift + R`** anywhere in the 3D Viewport to summon the HUD dashboard with studio reordering, bloom controls, and part visibility toggles.

---

## 📦 Installation

### Blender 4.2+ & Blender 4.5+ (Extensions Platform):
1. In Blender, navigate to **Edit > Preferences > Get Extensions**.
2. Click the top-right menu dropdown (arrow icon) and choose **Install from Disk...**
3. Select the `id_renderflo-3.1.0-website-standalone` folder or zip archive.
4. Press **`N`** in any 3D Viewport to access the **ID RenderFlo** panel, or use the **Topbar Ribbon**.

### ⚡ Standalone Edition CAD Engine Setup:
This standalone build is optimized for fast, lightweight download from [sahityakashyap.in](https://sahityakashyap.in) without pre-bundled 20 MB binary wheels.

To import STEP, STP, IGES, or Rhino `.3dm` files:
1. **1-Click Auto Install (Online)**:
   - In the 3D Viewport N-Panel under **CAD Bridge**, or in **Edit > Preferences > Add-ons > ID RenderFlo**, click **Install CAD Engine Files (OCC & Rhino)**.
   - ID RenderFlo automatically downloads and activates both **OpenCASCADE** (`cascadio`) and **Rhino3DM** (`rhino3dm`) into Blender with zero terminal commands needed.
2. **Offline Installation (No Internet)**:
   - Click **Browse Offline Wheel / Archive...** and select your `.whl` or `.zip` file.
   - Alternatively, drop `.whl` files into the `wheels/` subfolder and click **Recheck**.

---

## 📖 Documentation & Guides
* **Comprehensive How-To Manual**: See [`HOW_TO.md`](./HOW_TO.md) for full step-by-step instructions.
* **Release Notes**: See [`RELEASE_NOTES.md`](./RELEASE_NOTES.md) for complete version history and changes.
* **License**: Dual-licensed under GPL-3.0-or-later and MIT. See [`LICENSE.txt`](./LICENSE.txt).
