# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.1.0 — Shared State, Constants, and Thread / Recursion Guards.
Preserves thread-safety and avoids cyclic dependency re-evaluations during UI updates.
"""

import contextlib

# ------------------------------------------------------------------------
# Recursion Guard for Property Update Callbacks
# ------------------------------------------------------------------------
_IS_INTERNAL_UPDATE = False


def is_internal_update() -> bool:
    """Returns True if property update is triggered programmatically by ID RenderFlo."""
    return _IS_INTERNAL_UPDATE


def set_internal_update(val: bool):
    """Sets internal update flag."""
    global _IS_INTERNAL_UPDATE
    _IS_INTERNAL_UPDATE = bool(val)


@contextlib.contextmanager
def internal_update_guard():
    """Context manager to guarantee safety when updating RNA properties inside callbacks."""
    global _IS_INTERNAL_UPDATE
    prev = _IS_INTERNAL_UPDATE
    _IS_INTERNAL_UPDATE = True
    try:
        yield
    finally:
        _IS_INTERNAL_UPDATE = prev


# ------------------------------------------------------------------------
# Object & Collection Naming Hierarchy
# ------------------------------------------------------------------------
MASTER_LIGHT_COLL = "_RENDERFLO_LIGHTS_MASTER_"
MASTER_CAM_COLL = "_RENDERFLO_CAMERAS_"
MASTER_CUTAWAY_COLL = "_RENDERFLO_CUTAWAYS_"
MASTER_DECAL_COLL = "_RENDERFLO_DECALS_"
MASTER_FLEX_COLL = "_RENDERFLO_FLEX_"

TARGET_EMPTY_NAME = "RenderFlo_Product_Target"
GROUND_PLANE_NAME = "RenderFlo_Shadow_Floor"
BACKDROP_OBJ_NAME = "RenderFlo_Curved_Backdrop"
DOME_VISUALIZER_OBJ = "RenderFlo_HDRI_Dome_Visualizer"
DOME_PIN_PREFIX = "RenderFlo_DomePin_"
CUTAWAY_BOX_NAME = "RenderFlo_Cutaway_Box"
DECAL_PREFIX = "RenderFlo_Decal_"
CABLE_PREFIX = "RenderFlo_Cable_"
STRAP_PREFIX = "RenderFlo_Strap_"
REST_LOCATION_PROP = "rf_rest_location"
REST_ROTATION_PROP = "rf_rest_rotation"

# ------------------------------------------------------------------------
# Aspect Ratio & Resolution Presets
# ------------------------------------------------------------------------
ASPECT_PRESETS = [
    ('16_9', "16:9 (Widescreen)", "16:9 Landscape format", 16, 9),
    ('1_1', "1:1 (Square)", "1:1 Square e-commerce format", 1, 1),
    ('4_5', "4:5 (Portrait)", "4:5 Social / Mobile portrait", 4, 5),
    ('9_16', "9:16 (Vertical)", "9:16 Full vertical story", 9, 16),
    ('4_3', "4:3 (Standard)", "4:3 Traditional presentation", 4, 3),
    ('3_2', "3:2 (Photography)", "3:2 DSLR photography ratio", 3, 2),
    ('21_9', "21:9 (Ultrawide)", "21:9 Cinematic banner", 21, 9),
    ('CUSTOM', "Custom Resolution", "Enter custom pixel dimensions", 0, 0),
]

# ------------------------------------------------------------------------
# Color Management Contrast Presets
# ------------------------------------------------------------------------
CONTRAST_PRESETS = [
    ('None', "None", "Default standard contrast"),
    ('Very Low Contrast', "Very Low", "Very Low Contrast tone curve"),
    ('Low Contrast', "Low", "Low Contrast tone curve"),
    ('Medium Low Contrast', "Med-Low", "Medium Low Contrast tone curve"),
    ('Medium Contrast', "Medium", "Medium Contrast tone curve"),
    ('Medium High Contrast', "Med-High", "Medium High Contrast tone curve"),
    ('High Contrast', "High", "High Contrast tone curve"),
    ('Very High Contrast', "Very High", "Very High Contrast tone curve"),
]

# ------------------------------------------------------------------------
# Engine Capability Flags (Updated at runtime)
# ------------------------------------------------------------------------
_CASCADIO_AVAILABLE = False
_RHINO3DM_AVAILABLE = False
_CAD_ENGINE_AVAILABLE = None

