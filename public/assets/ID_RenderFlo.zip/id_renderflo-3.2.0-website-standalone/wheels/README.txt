ID RenderFlo — Standalone Edition Wheels Folder
=================================================
This version of ID RenderFlo is packaged for website distribution without bundled binary wheels (~20 MB saved).

When you import a CAD file (.step, .stp, .3dm) in Blender:
- ID RenderFlo will offer 1-click automatic installation via pip/PyPI.
- Alternatively, you can drop offline .whl files (cascadio and rhino3dm) directly into this folder or use "Browse Offline Archive" in the Blender UI.

