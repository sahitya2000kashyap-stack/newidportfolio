# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.1.0 — Application Template Script.
Automatically configures metric millimeter units, AgX color management,
strips bloat workspaces, configures Turntable orbit, and prepares a pristine ID studio environment.
"""

import bpy


def configure_id_studio_environment():
    scene = bpy.context.scene
    if not scene:
        return

    # 1. Industrial Design Precision Metric Units (Millimeters)
    scene.unit_settings.system = 'METRIC'
    scene.unit_settings.length_unit = 'MILLIMETERS'
    scene.unit_settings.scale_length = 0.001

    # 2. Modern AgX Color Management
    try:
        vs = scene.view_settings
        if "AgX" in vs.bl_rna.properties['view_transform'].enum_items:
            vs.view_transform = 'AgX'
            vs.look = 'Medium High Contrast'
        elif "Filmic" in vs.bl_rna.properties['view_transform'].enum_items:
            vs.view_transform = 'Filmic'
            vs.look = 'Medium High Contrast'
    except Exception:
        pass

    # 3. Strip Bloat Workspaces
    bloat_workspaces = {"Sculpting", "VFX", "Video Editing", "Motion Tracking", "Scripting", "Texture Paint"}
    for ws in list(bpy.data.workspaces):
        if ws.name in bloat_workspaces and len(bpy.data.workspaces) > 1:
            try:
                bpy.data.workspaces.remove(ws)
            except Exception:
                pass

    # 4. Industrial Design Viewport Navigation Defaults
    try:
        prefs = bpy.context.preferences.inputs
        prefs.view_rotate_method = 'TURNTABLE'
        prefs.use_zoom_to_mouse = True
        prefs.use_rotate_around_active = True
    except Exception:
        pass

    # 5. Cycles GPU Engine Default
    try:
        scene.render.engine = 'CYCLES'
        scene.cycles.device = 'GPU'
    except Exception:
        pass


def register():
    # Run once when template loads
    bpy.app.timers.register(configure_id_studio_environment, first_interval=0.1)


def unregister():
    pass


if __name__ == "__main__":
    register()

