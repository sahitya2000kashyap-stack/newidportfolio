# ID RenderFlo (v3.3.0) — Modern Extensions Edition

**Universal Industrial Design Studio Suite & Parametric CAD Pipeline for Blender (4.2+ LTS to 5.2+)**  
*Created by Sahitya Kashyap ([sahityakashyap.in](https://sahityakashyap.in))*

---

## 🚀 Overview

**ID RenderFlo** transforms Blender into a dedicated, KeyShot-style product visualization studio tailored specifically for industrial designers, mechanical engineers, and hardware design teams.

Equipped with a native **Rhino (`.3dm`) & STEP (`.step`/`.stp`) CAD Importer**, **1-Click CAD Hot-Reload**, **KeyShot-style Multi-Studio Snapshots**, **Standard CAD Views & Orthographic Mode**, **14 Photorealistic Studio Environments**, **Dedicated Material Library with Dynamic Preview Scaling**, **CMF Quick Save & Colorway Matrix**, **Per-Studio Bloom & Glow FX**, **Part Visibility & Isolation**, **Procedural HDRI Dome & 2D Pin Canvas**, **Raycast Conformal Decals**, and **GPU Batch Rendering with DXF Manufacturing Export**.

---

## ✨ Key Features in v3.3.0

* **🗂️ 8-Stage Industrial Design Lifecycle Dock**:
  1. `CAD Bridge`: Native STEP & Rhino `.3dm` import with Z-Up and True Millimeter (0.001x) scaling defaults.
  2. `Studios`: Camera snapshots, Standard CAD Views (`Front`, `Right`, `Left`, `Top`, `Bottom`, `Back`, `ISO`), segmented `[Persp | Ortho]` toggle, native `Orthographic Scale` slider, and custom render samples.
  3. `Environments`: 14 KeyShot-inspired photorealistic studio lighting scenes & custom HDRI library.
  4. `Lighting`: Procedural HDRI dome, interactive 2D pin canvas with reflection raycasting, and physical studio softboxes.
  5. `Materials`: Dynamic scrollable material shelf with continuous `Size` slider, inline apply button, procedural shader ball preview, and slot link/unlink controls.
  6. `CMF Matrix`: Instant colorway switching, Mold-Tech VDI 3400 textures, anodized satin, and brushed metal presets.
  7. `Decals & FX`: 1-click raycast sticker placement, normal rotation, conformal shrinkwrap, and live boolean section cutaways.
  8. `Render & DXF`: GPU batch queue, matrix batch render, custom output directory selector, and 2D DXF manufacturing export.
* **🎨 Active CMF Quick Save at Very Top of Material Library**:
  * View and switch active CMF colorways directly from the top of the Material Library tab.
  * 1-Click `[ + Save Current State as CMF ]` to record all component materials into a new CMF colorway preset.
  * 1-Click `[ ⟳ Update CMF ]` to overwrite the active CMF colorway with current adjustments.
* **⚡ Optimized Sample Defaults**:
  * Default Render Samples set to **100** for clean, fast final exports.
  * Default Viewport Samples set to **200** for crisp, noise-free interactive previews.
* **Persistent Topbar Ribbon**: Immediate access to `Import CAD`, `Hot-Reload CAD`, `Studio Steppers (< / >)`, `CMF Steppers (< / >)`, and `Aspect Ratio Presets` directly in Blender's main topbar with zero duplicate chevrons.
* **1-Click CAD Hot-Reload**: Re-import engineering updates from Rhino, Fusion 360, or SolidWorks in 1 click without losing materials, lighting, or camera compositions.
* **Wide Floating Studio Dashboard**: Press **`Alt + Shift + R`** anywhere in the 3D Viewport to summon the HUD dashboard with studio reordering, bloom controls, and part visibility toggles.

---

## 📦 Installation

### Blender 4.2+ to Blender 5.2+ (Official Extensions):
1. In Blender, navigate to **Edit > Preferences > Get Extensions**.
2. Click the top-right menu dropdown (arrow icon) and choose **Install from Disk...**
3. Select your platform package (e.g. `id_renderflo-3.3.0-windows_x64.zip` or `id_renderflo-3.3.0-website-standalone.zip`).
4. Press **`N`** in any 3D Viewport to access the **ID RenderFlo** panel, or use the **Topbar Ribbon**.

### ⚡ Standalone Edition CAD Engine Setup:
This standalone build is optimized for fast, lightweight download from [sahityakashyap.in](https://sahityakashyap.in) without pre-bundled 20 MB binary wheels.

To import STEP, STP, IGES, or Rhino `.3dm` files:
1. **1-Click Auto Install (Online)**:
   - In the 3D Viewport N-Panel under **CAD Bridge**, or in **Edit > Preferences > Add-ons > ID RenderFlo**, click **Install CAD Engine Files (OCC & Rhino)**.
   - ID RenderFlo automatically downloads and activates both **OpenCASCADE** (`cascadio`) and **Rhino3DM** (`rhino3dm`) into Blender with zero terminal commands needed.
2. **Offline Installation (No Internet)**:
   - Click **Browse Offline Wheel / Archive...** and select your `.whl` or `.zip` file.
   - Alternatively, drop `.whl` files into the `wheels/` subfolder and click **Recheck**.

---

## 📖 Documentation & Guides
* **Comprehensive How-To Manual**: See [`HOW_TO.md`](./HOW_TO.md) for full step-by-step instructions.
* **Release Notes**: See [`RELEASE_NOTES.md`](./RELEASE_NOTES.md) for complete version history and changes.
* **License**: Dual-licensed under GPL-3.0-or-later and MIT. See [`LICENSE.txt`](./LICENSE.txt).
