# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.3.0 — CMF Industrial Design Material Library & Persistence Engine.
Curated procedural manufacturing materials (Anodized, Bead-Blast, Mold-Tech VDI, TPU, Glass, Carbon Fiber),
1-Click Link / Unlink tools, and User Personal Library disk storage.
"""

import os
import json
import math
import bpy
import bpy.utils.previews
from bpy.props import StringProperty, EnumProperty, FloatProperty, FloatVectorProperty
from bpy.app.handlers import persistent

preview_collections = {}

def get_material_preview_collection():
    global preview_collections
    if "id_materials" not in preview_collections:
        pcoll = bpy.utils.previews.new()
        
        # 1. Built-in thumbnails
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        thumb_dir = os.path.join(base_dir, "thumbnails", "materials")
        if os.path.isdir(thumb_dir):
            for fname in os.listdir(thumb_dir):
                if fname.lower().endswith(".png"):
                    p_id = os.path.splitext(fname)[0]
                    fpath = os.path.join(thumb_dir, fname)
                    try:
                        pcoll.load(p_id, fpath, 'IMAGE')
                    except Exception:
                        pass
        
        # 2. User-saved thumbnails
        user_thumb_dir = os.path.join(get_user_library_dir(), "thumbnails")
        if os.path.isdir(user_thumb_dir):
            for fname in os.listdir(user_thumb_dir):
                if fname.lower().endswith(".png"):
                    p_id = f"USER::{os.path.splitext(fname)[0]}"
                    fpath = os.path.join(user_thumb_dir, fname)
                    try:
                        pcoll.load(p_id, fpath, 'IMAGE')
                    except Exception:
                        pass

        preview_collections["id_materials"] = pcoll
    return preview_collections["id_materials"]


# ------------------------------------------------------------------------
# Disk Persistence Paths & User Library Management
# ------------------------------------------------------------------------

def get_user_library_dir():
    """Returns the dedicated user folder for saved ID RenderFlo materials."""
    try:
        dirpath = bpy.utils.user_resource("DATAFILES", path="id_renderflo_materials", create=True)
    except Exception:
        import tempfile
        dirpath = os.path.join(tempfile.gettempdir(), "id_renderflo_materials")
        os.makedirs(dirpath, exist_ok=True)
    return dirpath


def get_metadata_filepath():
    return os.path.join(get_user_library_dir(), "library_manifest.json")


def load_user_library_metadata():
    mf = get_metadata_filepath()
    if os.path.isfile(mf):
        try:
            with open(mf, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_user_library_metadata(meta):
    mf = get_metadata_filepath()
    try:
        with open(mf, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2)
    except Exception as e:
        print(f"ID RenderFlo: Failed to write material metadata: {e}")


def get_user_saved_materials_list():
    meta = load_user_library_metadata()
    lib_dir = get_user_library_dir()
    valid_items = []
    for mat_name, info in meta.items():
        blend_file = os.path.join(lib_dir, f"{info.get('file_id', mat_name)}.blend")
        if os.path.isfile(blend_file):
            valid_items.append((mat_name, info.get("category", "Custom"), blend_file))
    return valid_items


# ------------------------------------------------------------------------
# Procedural ID Material Shaders Generation Engine
# ------------------------------------------------------------------------

def _clean_node_tree(mat):
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    links = mat.node_tree.links
    out_node = nodes.new(type="ShaderNodeOutputMaterial")
    out_node.location = (600, 0)
    bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
    bsdf.location = (200, 0)
    links.new(bsdf.outputs["BSDF"], out_node.inputs["Surface"])
    return nodes, links, bsdf, out_node


def _add_texture_coords(nodes, loc=(-600, 0)):
    tex_coord = nodes.new(type="ShaderNodeTexCoord")
    tex_coord.location = loc
    mapping = nodes.new(type="ShaderNodeMapping")
    mapping.location = (loc[0] + 200, loc[1])
    return tex_coord, mapping


def create_anodized_aluminum(mat, color=(0.12, 0.12, 0.13, 1.0), roughness=0.28, anisotropy=0.45):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    tex_coord, mapping = _add_texture_coords(nodes, (-800, 0))
    links.new(tex_coord.outputs["Object"], mapping.inputs["Vector"])

    # Subtle micro-surface roughness texture
    noise = nodes.new(type="ShaderNodeTexNoise")
    noise.location = (-400, 0)
    noise.inputs["Scale"].default_value = 85.0
    noise.inputs["Detail"].default_value = 6.0
    noise.inputs["Roughness"].default_value = 0.6
    links.new(mapping.outputs["Vector"], noise.inputs["Vector"])

    cr = nodes.new(type="ShaderNodeMapRange")
    cr.location = (-150, 0)
    cr.inputs["From Min"].default_value = 0.2
    cr.inputs["From Max"].default_value = 0.8
    cr.inputs["To Min"].default_value = max(0.01, roughness - 0.08)
    cr.inputs["To Max"].default_value = min(1.0, roughness + 0.08)
    links.new(noise.outputs["Fac"], cr.inputs["Value"])
    links.new(cr.outputs["Result"], bsdf.inputs["Roughness"])

    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = 1.0
    if "Anisotropic" in bsdf.inputs:
        bsdf.inputs["Anisotropic"].default_value = anisotropy
    mat["rf_id_category"] = "METALS"


def create_bead_blasted_aluminum(mat, color=(0.78, 0.79, 0.81, 1.0), roughness=0.36):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    tex_coord, mapping = _add_texture_coords(nodes, (-800, 0))
    links.new(tex_coord.outputs["Object"], mapping.inputs["Vector"])

    # Dual frequency micro-pitting
    noise = nodes.new(type="ShaderNodeTexNoise")
    noise.location = (-400, -150)
    noise.inputs["Scale"].default_value = 180.0
    noise.inputs["Detail"].default_value = 8.0
    links.new(mapping.outputs["Vector"], noise.inputs["Vector"])

    bump = nodes.new(type="ShaderNodeBump")
    bump.location = (-100, -150)
    bump.inputs["Strength"].default_value = 0.08
    bump.inputs["Distance"].default_value = 0.005
    links.new(noise.outputs["Fac"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = 1.0
    bsdf.inputs["Roughness"].default_value = roughness
    mat["rf_id_category"] = "METALS"


def create_brushed_steel(mat, color=(0.85, 0.85, 0.86, 1.0), roughness=0.22):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    tex_coord, mapping = _add_texture_coords(nodes, (-800, 0))
    mapping.inputs["Scale"].default_value = (1.0, 60.0, 1.0)
    links.new(tex_coord.outputs["Object"], mapping.inputs["Vector"])

    noise = nodes.new(type="ShaderNodeTexNoise")
    noise.location = (-400, -150)
    noise.inputs["Scale"].default_value = 50.0
    noise.inputs["Detail"].default_value = 10.0
    links.new(mapping.outputs["Vector"], noise.inputs["Vector"])

    bump = nodes.new(type="ShaderNodeBump")
    bump.location = (-100, -150)
    bump.inputs["Strength"].default_value = 0.12
    bump.inputs["Distance"].default_value = 0.005
    links.new(noise.outputs["Fac"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = 1.0
    bsdf.inputs["Roughness"].default_value = roughness
    if "Anisotropic" in bsdf.inputs:
        bsdf.inputs["Anisotropic"].default_value = 0.8
    mat["rf_id_category"] = "METALS"


def create_powder_coat(mat, color=(0.04, 0.04, 0.04, 1.0), roughness=0.48):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    tex_coord, mapping = _add_texture_coords(nodes, (-800, 0))
    links.new(tex_coord.outputs["Object"], mapping.inputs["Vector"])

    voronoi = nodes.new(type="ShaderNodeTexVoronoi")
    voronoi.location = (-400, -150)
    voronoi.inputs["Scale"].default_value = 120.0
    links.new(mapping.outputs["Vector"], voronoi.inputs["Vector"])

    bump = nodes.new(type="ShaderNodeBump")
    bump.location = (-100, -150)
    bump.inputs["Strength"].default_value = 0.22
    bump.inputs["Distance"].default_value = 0.01
    links.new(voronoi.outputs["Distance"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = 0.75
    bsdf.inputs["Roughness"].default_value = roughness
    mat["rf_id_category"] = "METALS"


def create_mold_tech_plastic(mat, color=(0.08, 0.08, 0.09, 1.0), grain_scale=150.0, roughness=0.38):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    tex_coord, mapping = _add_texture_coords(nodes, (-800, 0))
    links.new(tex_coord.outputs["Object"], mapping.inputs["Vector"])

    # Procedural VDI 3400 EDM spark erosion stipple
    voronoi = nodes.new(type="ShaderNodeTexVoronoi")
    voronoi.location = (-500, -150)
    voronoi.inputs["Scale"].default_value = grain_scale
    links.new(mapping.outputs["Vector"], voronoi.inputs["Vector"])

    noise = nodes.new(type="ShaderNodeTexNoise")
    noise.location = (-500, 100)
    noise.inputs["Scale"].default_value = grain_scale * 1.5
    noise.inputs["Detail"].default_value = 6.0
    links.new(mapping.outputs["Vector"], noise.inputs["Vector"])

    mix = nodes.new(type="ShaderNodeMix")
    mix.location = (-250, -50)
    mix.data_type = 'FLOAT'
    mix.inputs["Factor"].default_value = 0.4
    links.new(voronoi.outputs["Distance"], mix.inputs[2])
    links.new(noise.outputs["Fac"], mix.inputs[3])

    bump = nodes.new(type="ShaderNodeBump")
    bump.location = (-50, -150)
    bump.inputs["Strength"].default_value = 0.15
    bump.inputs["Distance"].default_value = 0.003
    links.new(mix.outputs["Result"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = 0.0
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["IOR"].default_value = 1.52
    mat["rf_id_category"] = "PLASTICS"


def create_high_gloss_abs(mat, color=(0.88, 0.88, 0.89, 1.0)):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = 0.0
    bsdf.inputs["Roughness"].default_value = 0.035
    bsdf.inputs["IOR"].default_value = 1.54
    if "Coat Weight" in bsdf.inputs:
        bsdf.inputs["Coat Weight"].default_value = 1.0
        bsdf.inputs["Coat Roughness"].default_value = 0.02
    mat["rf_id_category"] = "PLASTICS"


def create_soft_touch_tpu(mat, color=(0.1, 0.1, 0.11, 1.0), roughness=0.55):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    tex_coord, mapping = _add_texture_coords(nodes, (-800, 0))
    links.new(tex_coord.outputs["Object"], mapping.inputs["Vector"])

    noise = nodes.new(type="ShaderNodeTexNoise")
    noise.location = (-400, -150)
    noise.inputs["Scale"].default_value = 350.0
    noise.inputs["Detail"].default_value = 4.0
    links.new(mapping.outputs["Vector"], noise.inputs["Vector"])

    bump = nodes.new(type="ShaderNodeBump")
    bump.location = (-100, -150)
    bump.inputs["Strength"].default_value = 0.04
    bump.inputs["Distance"].default_value = 0.002
    links.new(noise.outputs["Fac"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = 0.0
    bsdf.inputs["Roughness"].default_value = roughness
    if "Sheen Weight" in bsdf.inputs:
        bsdf.inputs["Sheen Weight"].default_value = 0.95
        bsdf.inputs["Sheen Roughness"].default_value = 0.5
    mat["rf_id_category"] = "PLASTICS"


def create_smoked_polycarbonate(mat, tint=(0.15, 0.15, 0.17, 1.0), roughness=0.12):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    bsdf.inputs["Base Color"].default_value = tint
    bsdf.inputs["Metallic"].default_value = 0.0
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["IOR"].default_value = 1.58
    if "Transmission Weight" in bsdf.inputs:
        bsdf.inputs["Transmission Weight"].default_value = 0.92
    mat["rf_id_category"] = "PLASTICS"


def create_frosted_diffuser_glass(mat, color=(0.95, 0.96, 0.98, 1.0), roughness=0.35):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = 0.0
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["IOR"].default_value = 1.52
    if "Transmission Weight" in bsdf.inputs:
        bsdf.inputs["Transmission Weight"].default_value = 1.0
    mat["rf_id_category"] = "GLASS"


def create_clear_glass(mat, ior=1.52):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    bsdf.inputs["Base Color"].default_value = (1.0, 1.0, 1.0, 1.0)
    bsdf.inputs["Metallic"].default_value = 0.0
    bsdf.inputs["Roughness"].default_value = 0.005
    bsdf.inputs["IOR"].default_value = ior
    if "Transmission Weight" in bsdf.inputs:
        bsdf.inputs["Transmission Weight"].default_value = 1.0
    mat["rf_id_category"] = "GLASS"


def create_speaker_grill(mat, color=(0.12, 0.12, 0.13, 1.0), hole_scale=25.0):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    tex_coord, mapping = _add_texture_coords(nodes, (-800, 0))
    links.new(tex_coord.outputs["Object"], mapping.inputs["Vector"])

    voronoi = nodes.new(type="ShaderNodeTexVoronoi")
    voronoi.location = (-400, -150)
    voronoi.inputs["Scale"].default_value = hole_scale
    links.new(mapping.outputs["Vector"], voronoi.inputs["Vector"])

    # Alpha mask for holes
    cr = nodes.new(type="ShaderNodeValToRGB")
    cr.location = (-150, -150)
    cr.color_ramp.interpolation = 'CONSTANT'
    cr.color_ramp.elements[0].position = 0.28
    cr.color_ramp.elements[0].color = (0.0, 0.0, 0.0, 1.0)
    cr.color_ramp.elements[1].position = 0.29
    cr.color_ramp.elements[1].color = (1.0, 1.0, 1.0, 1.0)
    links.new(voronoi.outputs["Distance"], cr.inputs["Fac"])
    links.new(cr.outputs["Color"], bsdf.inputs["Alpha"])

    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = 0.8
    bsdf.inputs["Roughness"].default_value = 0.35
    mat["rf_id_category"] = "SPECIALTY"


def create_knurled_rubber(mat, color=(0.08, 0.08, 0.08, 1.0)):
    nodes, links, bsdf, out = _clean_node_tree(mat)
    tex_coord, mapping = _add_texture_coords(nodes, (-800, 0))
    links.new(tex_coord.outputs["Object"], mapping.inputs["Vector"])

    # Diagonal wave cross-hatch for diamond knurl
    w1 = nodes.new(type="ShaderNodeTexWave")
    w1.location = (-500, 50)
    w1.wave_type = 'BANDS'
    w1.inputs["Scale"].default_value = 35.0
    links.new(mapping.outputs["Vector"], w1.inputs["Vector"])

    m2 = nodes.new(type="ShaderNodeMapping")
    m2.location = (-600, -250)
    m2.inputs["Rotation"].default_value = (0.0, 0.0, 1.5708)
    links.new(tex_coord.outputs["Object"], m2.inputs["Vector"])

    w2 = nodes.new(type="ShaderNodeTexWave")
    w2.location = (-400, -250)
    w2.wave_type = 'BANDS'
    w2.inputs["Scale"].default_value = 35.0
    links.new(m2.outputs["Vector"], w2.inputs["Vector"])

    mix = nodes.new(type="ShaderNodeMix")
    mix.location = (-200, -100)
    mix.data_type = 'FLOAT'
    mix.inputs["Factor"].default_value = 0.5
    links.new(w1.outputs["Color"], mix.inputs[2])
    links.new(w2.outputs["Color"], mix.inputs[3])

    bump = nodes.new(type="ShaderNodeBump")
    bump.location = (0, -150)
    bump.inputs["Strength"].default_value = 0.4
    bump.inputs["Distance"].default_value = 0.01
    links.new(mix.outputs["Result"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = 0.0
    bsdf.inputs["Roughness"].default_value = 0.65
    mat["rf_id_category"] = "SPECIALTY"


# Built-in Registry
BUILTIN_PRESETS = {
    "ANODIZED_NATURAL": {
        "name": "Anodized Aluminum (Natural)",
        "category": "METALS",
        "func": lambda m: create_anodized_aluminum(m, (0.75, 0.76, 0.78, 1.0), roughness=0.28)
    },
    "ANODIZED_SPACE_GRAY": {
        "name": "Anodized Aluminum (Space Gray)",
        "category": "METALS",
        "func": lambda m: create_anodized_aluminum(m, (0.28, 0.29, 0.31, 1.0), roughness=0.26)
    },
    "ANODIZED_BLACK": {
        "name": "Anodized Aluminum (Matte Black)",
        "category": "METALS",
        "func": lambda m: create_anodized_aluminum(m, (0.05, 0.05, 0.05, 1.0), roughness=0.32)
    },
    "BEAD_BLAST_SILVER": {
        "name": "Bead-Blasted Aluminum (MacBook)",
        "category": "METALS",
        "func": lambda m: create_bead_blasted_aluminum(m, (0.80, 0.81, 0.83, 1.0), roughness=0.36)
    },
    "BRUSHED_STAINLESS": {
        "name": "Brushed Stainless Steel",
        "category": "METALS",
        "func": lambda m: create_brushed_steel(m, (0.85, 0.85, 0.86, 1.0), roughness=0.22)
    },
    "POWDER_COAT_BLACK": {
        "name": "Powder-Coated Steel (Black Stipple)",
        "category": "METALS",
        "func": lambda m: create_powder_coat(m, (0.04, 0.04, 0.04, 1.0), roughness=0.48)
    },
    "MOLD_TECH_FINE": {
        "name": "Mold-Tech MT-11010 (Fine EDM)",
        "category": "PLASTICS",
        "func": lambda m: create_mold_tech_plastic(m, (0.08, 0.08, 0.09, 1.0), grain_scale=160.0, roughness=0.36)
    },
    "MOLD_TECH_COARSE": {
        "name": "Mold-Tech MT-11020 (Coarse EDM)",
        "category": "PLASTICS",
        "func": lambda m: create_mold_tech_plastic(m, (0.07, 0.07, 0.07, 1.0), grain_scale=90.0, roughness=0.45)
    },
    "HIGH_GLOSS_ABS": {
        "name": "High-Gloss Molded ABS",
        "category": "PLASTICS",
        "func": lambda m: create_high_gloss_abs(m, (0.90, 0.90, 0.91, 1.0))
    },
    "SOFT_TOUCH_TPU": {
        "name": "Soft-Touch TPU / Silicone",
        "category": "PLASTICS",
        "func": lambda m: create_soft_touch_tpu(m, (0.10, 0.10, 0.11, 1.0), roughness=0.58)
    },
    "SMOKED_POLYCARB": {
        "name": "Smoked Polycarbonate (Tinted)",
        "category": "PLASTICS",
        "func": lambda m: create_smoked_polycarbonate(m, (0.12, 0.12, 0.14, 1.0), roughness=0.10)
    },
    "CLEAR_OPTICAL_GLASS": {
        "name": "Optical Glass (Clear)",
        "category": "GLASS",
        "func": lambda m: create_clear_glass(m, ior=1.52)
    },
    "FROSTED_DIFFUSER_GLASS": {
        "name": "Frosted LED Diffuser Glass",
        "category": "GLASS",
        "func": lambda m: create_frosted_diffuser_glass(m, (0.95, 0.96, 0.98, 1.0), roughness=0.35)
    },
    "SPEAKER_GRILL_MESH": {
        "name": "Speaker Grill (Micro-Perforated)",
        "category": "SPECIALTY",
        "func": lambda m: create_speaker_grill(m, (0.12, 0.12, 0.13, 1.0), hole_scale=25.0)
    },
    "KNURLED_GRIP_RUBBER": {
        "name": "Knurled Grip Rubber (Dials)",
        "category": "SPECIALTY",
        "func": lambda m: create_knurled_rubber(m, (0.08, 0.08, 0.08, 1.0))
    },
}


# ------------------------------------------------------------------------
# Material Enum Item Callbacks for UI
# ------------------------------------------------------------------------

def get_material_category_items(self, context):
    return [
        ('ALL', "All Categories", "Browse all available ID materials", 'FILE_FOLDER', 0),
        ('METALS', "Metals & Anodized", "Anodized aluminum, brushed steel, powder coats", 'SHADING_RENDERED', 1),
        ('PLASTICS', "Plastics & Mold-Tech", "VDI 3400 spark erosion, ABS, soft-touch TPU", 'MATERIAL', 2),
        ('GLASS', "Glass & Optics", "Clear glass, frosted diffuser, smoked PC", 'RESTRICT_RENDER_OFF', 3),
        ('SPECIALTY', "Specialty & Grips", "Speaker grills, knurled rubber", 'MOD_WIREFRAME', 4),
        ('USER', "★ My Saved Library", "Custom user-saved materials", 'FAVORITES', 5),
    ]



def render_user_material_thumbnail(mat, thumb_path):
    orig_scene = bpy.context.scene
    temp_scene = bpy.data.scenes.new("RF_ThumbGenScene")
    try:
        temp_scene.render.resolution_x = 128
        temp_scene.render.resolution_y = 128
        temp_scene.render.film_transparent = True
        temp_scene.render.image_settings.file_format = 'PNG'
        temp_scene.render.image_settings.color_mode = 'RGBA'
        
        # World
        tw = bpy.data.worlds.new("RF_ThumbWorld")
        tw.use_nodes = True
        bg = tw.node_tree.nodes.get("Background")
        if bg:
            bg.inputs["Color"].default_value = (0.2, 0.2, 0.22, 1.0)
            bg.inputs["Strength"].default_value = 0.5
        temp_scene.world = tw
        
        # Sphere
        mesh = bpy.data.meshes.new("RF_ThumbSphereMesh")
        import bmesh
        bm = bmesh.new()
        bmesh.ops.create_uvsphere(bm, u_segments=32, v_segments=16, radius=1.0)
        bm.to_mesh(mesh)
        bm.free()
        
        sphere_obj = bpy.data.objects.new("RF_ThumbSphere", mesh)
        sphere_obj.data.materials.append(mat)
        temp_scene.collection.objects.link(sphere_obj)
        
        # Camera
        cam_data = bpy.data.cameras.new("RF_ThumbCam")
        cam_data.lens = 55.0
        cam_obj = bpy.data.objects.new("RF_ThumbCamObj", cam_data)
        cam_obj.location = (0, -3.2, 1.5)
        cam_obj.rotation_euler = (math.radians(72), 0, 0)
        temp_scene.collection.objects.link(cam_obj)
        temp_scene.camera = cam_obj
        
        # Key light
        key_data = bpy.data.lights.new("RF_ThumbKey", type='AREA')
        key_data.energy = 80.0
        key_data.size = 2.0
        key_obj = bpy.data.objects.new("RF_ThumbKeyObj", key_data)
        key_obj.location = (2.5, -2.5, 3.2)
        key_obj.rotation_euler = (math.radians(45), 0, math.radians(45))
        temp_scene.collection.objects.link(key_obj)
        
        # Fill light
        fill_data = bpy.data.lights.new("RF_ThumbFill", type='AREA')
        fill_data.energy = 35.0
        fill_data.size = 2.5
        fill_obj = bpy.data.objects.new("RF_ThumbFillObj", fill_data)
        fill_obj.location = (-2.5, -2.0, 2.4)
        fill_obj.rotation_euler = (math.radians(45), 0, math.radians(-45))
        temp_scene.collection.objects.link(fill_obj)
        
        # Rim light
        rim_data = bpy.data.lights.new("RF_ThumbRim", type='AREA')
        rim_data.energy = 95.0
        rim_data.size = 1.6
        rim_obj = bpy.data.objects.new("RF_ThumbRimObj", rim_data)
        rim_obj.location = (0.0, 3.0, 2.8)
        rim_obj.rotation_euler = (math.radians(-40), 0, math.radians(180))
        temp_scene.collection.objects.link(rim_obj)
        
        temp_scene.render.filepath = thumb_path
        bpy.ops.render.render(scene=temp_scene.name, write_still=True)
    finally:
        bpy.data.scenes.remove(temp_scene)

def get_material_presets_items(self, context):
    cat = getattr(context.scene, "rf_mat_category", 'ALL')
    items = []
    pcoll = get_material_preview_collection()

    # 1. Built-in presets
    if cat != 'USER':
        for p_id, p_info in BUILTIN_PRESETS.items():
            if cat == 'ALL' or p_info.get("category") == cat:
                if p_id in pcoll:
                    items.append((p_id, p_info["name"], f"Built-in {p_info['category']} Preset", pcoll[p_id].icon_id, len(items)))
                else:
                    icon = 'MATERIAL'
                    if p_info["category"] == 'METALS':
                        icon = 'SHADING_RENDERED'
                    elif p_info["category"] == 'GLASS':
                        icon = 'RESTRICT_RENDER_OFF'
                    elif p_info["category"] == 'SPECIALTY':
                        icon = 'MOD_WIREFRAME'
                    items.append((p_id, p_info["name"], f"Built-in {p_info['category']} Preset", icon, len(items)))

    # 2. User-saved library presets
    if cat in {'ALL', 'USER'}:
        user_mats = get_user_saved_materials_list()
        for mat_name, user_cat, _ in user_mats:
            key = f"USER::{mat_name}"
            if key not in pcoll:
                user_thumb = os.path.join(get_user_library_dir(), "thumbnails", f"{mat_name}.png")
                if os.path.isfile(user_thumb):
                    try:
                        pcoll.load(key, user_thumb, 'IMAGE')
                    except Exception:
                        pass

            if key in pcoll:
                items.append((key, f"★ {mat_name}", f"User Saved ({user_cat})", pcoll[key].icon_id, len(items)))
            else:
                items.append((key, f"★ {mat_name}", f"User Saved ({user_cat})", 'SOLO_ON', len(items)))

    if not items:
        items.append(('NONE', "(No materials in category)", "", 'INFO', 0))
    return items


# ------------------------------------------------------------------------
# Operators: Apply, Save, Update, Delete
# ------------------------------------------------------------------------

class RENDERFLO_OT_select_id_material(bpy.types.Operator):
    bl_idname = "renderflo.select_id_material"
    bl_label = "Select Material Preset"
    bl_description = "Select this industrial design material preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset_id: bpy.props.StringProperty(name="Preset ID", default="")
    apply_to_selected: bpy.props.BoolProperty(name="Apply to Selected Part", default=False)

    def execute(self, context):
        scene = context.scene
        if self.preset_id:
            scene.rf_mat_preset = self.preset_id
            if self.apply_to_selected:
                if context.active_object and context.active_object.type in {'MESH', 'CURVE', 'SURFACE'}:
                    bpy.ops.renderflo.apply_id_material(preset_id=self.preset_id)
        return {'FINISHED'}


def get_or_create_preview_material(context):
    scene = getattr(context, "scene", None)
    if not scene:
        return None
    preset_id = getattr(scene, "rf_mat_preset", "")
    mat_name = ".rf_material_preview"
    mat = bpy.data.materials.get(mat_name)
    if not mat:
        mat = bpy.data.materials.new(name=mat_name)
        mat.use_fake_user = True
    
    if getattr(mat, "_rf_cached_preset", None) != preset_id:
        if preset_id in BUILTIN_PRESETS:
            BUILTIN_PRESETS[preset_id]["func"](mat)
            mat["_rf_cached_preset"] = preset_id
    return mat


class RENDERFLO_OT_apply_id_material(bpy.types.Operator):
    bl_idname = "renderflo.apply_id_material"
    bl_label = "Apply Material to Part"
    bl_description = "Apply the chosen industrial design material to the selected object or slot"
    bl_options = {'REGISTER', 'UNDO'}

    preset_id: bpy.props.StringProperty(name="Preset ID", default="")

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type in {'MESH', 'CURVE', 'SURFACE'}

    def execute(self, context):
        obj = context.active_object
        scene = context.scene
        if self.preset_id:
            scene.rf_mat_preset = self.preset_id
        preset_id = scene.rf_mat_preset

        if not preset_id or preset_id == 'NONE':
            self.report({'WARNING'}, "Please select a material preset from the library first.")
            return {'CANCELLED'}

        # 1. User-saved material loading
        if preset_id.startswith("USER::"):
            mat_name = preset_id.split("USER::", 1)[1]
            lib_dir = get_user_library_dir()
            meta = load_user_library_metadata()
            info = meta.get(mat_name, {})
            blend_file = os.path.join(lib_dir, f"{info.get('file_id', mat_name)}.blend")
            if not os.path.isfile(blend_file):
                self.report({'ERROR'}, f"Library file not found for '{mat_name}'")
                return {'CANCELLED'}

            with bpy.data.libraries.load(blend_file, link=False) as (data_from, data_to):
                data_to.materials = data_from.materials

            target_mat = None
            if data_to.materials:
                target_mat = data_to.materials[0]
            if not target_mat:
                target_mat = bpy.data.materials.get(mat_name)
            if target_mat:
                target_mat.name = mat_name
        else:
            # 2. Built-in procedural generation
            preset_info = BUILTIN_PRESETS.get(preset_id)
            if not preset_info:
                self.report({'ERROR'}, f"Unknown material preset: {preset_id}")
                return {'CANCELLED'}

            mat_name = preset_info["name"]
            # Create a fresh material with unique name if already exists in scene
            target_mat = bpy.data.materials.new(name=mat_name)
            preset_info["func"](target_mat)

        target_mat["rf_id_preset_id"] = preset_id

        # Assign to object
        if len(obj.material_slots) == 0:
            obj.data.materials.append(target_mat)
        else:
            slot_idx = obj.active_material_index
            if 0 <= slot_idx < len(obj.material_slots):
                obj.material_slots[slot_idx].material = target_mat
            else:
                obj.material_slots[0].material = target_mat

        self.report({'INFO'}, f"Applied '{target_mat.name}' to {obj.name}")
        return {'FINISHED'}


class RENDERFLO_OT_save_material_to_library(bpy.types.Operator):
    bl_idname = "renderflo.save_material_to_library"
    bl_label = "Save Material to Personal Library"
    bl_description = "Save the active material into your persistent ID RenderFlo library on disk"
    bl_options = {'REGISTER', 'UNDO'}

    material_name: StringProperty(name="Material Name", default="Custom_Anodized")
    category: EnumProperty(
        name="Category",
        items=[
            ('METALS', "Metals & Anodized", ""),
            ('PLASTICS', "Plastics & Mold-Tech", ""),
            ('GLASS', "Glass & Optics", ""),
            ('SPECIALTY', "Specialty & Grips", ""),
            ('CUSTOM', "Custom / Personal", ""),
        ],
        default='CUSTOM'
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.active_material is not None

    def invoke(self, context, event):
        obj = context.active_object
        if obj and obj.active_material:
            self.material_name = obj.active_material.name
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.prop(self, "material_name")
        col.prop(self, "category")

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material
        name = self.material_name.strip()
        if not name:
            self.report({'ERROR'}, "Material name cannot be empty.")
            return {'CANCELLED'}

        lib_dir = get_user_library_dir()
        safe_file_id = "".join(c if c.isalnum() or c in ('_', '-') else '_' for c in name)
        blend_path = os.path.join(lib_dir, f"{safe_file_id}.blend")

        # Save material into its own blend file
        orig_name = mat.name
        mat.name = name
        try:
            bpy.data.libraries.write(blend_path, {mat}, fake_user=True)
        except Exception as e:
            mat.name = orig_name
            self.report({'ERROR'}, f"Failed to save library file: {e}")
            return {'CANCELLED'}
        finally:
            mat.name = orig_name

        # Update metadata JSON
        meta = load_user_library_metadata()
        meta[name] = {
            "file_id": safe_file_id,
            "category": self.category,
        }
        save_user_library_metadata(meta)

        # Render 128x128 preview thumbnail for this user material
        try:
            user_thumb_dir = os.path.join(lib_dir, "thumbnails")
            os.makedirs(user_thumb_dir, exist_ok=True)
            thumb_path = os.path.join(user_thumb_dir, f"{safe_file_id}.png")
            render_user_material_thumbnail(mat, thumb_path)
            pcoll = get_material_preview_collection()
            key = f"USER::{name}"
            if key in pcoll:
                del pcoll[key]
            pcoll.load(key, thumb_path, 'IMAGE')
        except Exception as e:
            print(f"ID RenderFlo: Could not render material thumbnail: {e}")

        sync_material_items(context.scene)
        self.report({'INFO'}, f"Saved '{name}' to ID RenderFlo Personal Library!")
        return {'FINISHED'}


class RENDERFLO_OT_update_material_preset(bpy.types.Operator):
    bl_idname = "renderflo.update_material_preset"
    bl_label = "Update Preset in Library"
    bl_description = "Overwrite and update the active user preset in the library with your current modifications"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.active_material is not None

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material
        meta = load_user_library_metadata()

        # Check if active material name matches a user preset
        if mat.name in meta:
            file_id = meta[mat.name].get("file_id", mat.name)
            blend_path = os.path.join(get_user_library_dir(), f"{file_id}.blend")
            bpy.data.libraries.write(blend_path, {mat}, fake_user=True)
            self.report({'INFO'}, f"Successfully updated '{mat.name}' in personal library!")
            return {'FINISHED'}

        # Otherwise trigger save as new
        bpy.ops.renderflo.save_material_to_library('INVOKE_DEFAULT')
        return {'FINISHED'}


class RENDERFLO_OT_delete_library_material(bpy.types.Operator):
    bl_idname = "renderflo.delete_library_material"
    bl_label = "Delete Preset from Library"
    bl_description = "Remove this custom material from your personal library"
    bl_options = {'REGISTER', 'UNDO'}

    material_name: StringProperty(name="Material Name", default="")

    def execute(self, context):
        name = self.material_name.strip()
        if not name:
            preset_id = context.scene.rf_mat_preset
            if preset_id.startswith("USER::"):
                name = preset_id.split("USER::", 1)[1]

        meta = load_user_library_metadata()
        if name in meta:
            file_id = meta[name].get("file_id", name)
            blend_path = os.path.join(get_user_library_dir(), f"{file_id}.blend")
            if os.path.exists(blend_path):
                try:
                    os.remove(blend_path)
                except Exception:
                    pass
            del meta[name]
            save_user_library_metadata(meta)
            sync_material_items(context.scene)
            self.report({'INFO'}, f"Deleted '{name}' from personal library.")
            return {'FINISHED'}

        self.report({'WARNING'}, f"Material '{name}' not found in user library.")
        return {'CANCELLED'}


# ------------------------------------------------------------------------
# Link & Unlink Material Operators (CAD Assembly Essentials)
# ------------------------------------------------------------------------

class RENDERFLO_OT_link_materials_to_selected(bpy.types.Operator):
    bl_idname = "renderflo.link_materials_to_selected"
    bl_label = "Link Active Material to Selected"
    bl_description = "Propagate the active part's material across all currently selected objects in 1-click"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and len(context.selected_objects) > 1

    def execute(self, context):
        active_obj = context.active_object
        if not active_obj or not active_obj.active_material:
            self.report({'WARNING'}, "Active object must have a material assigned.")
            return {'CANCELLED'}

        target_mat = active_obj.active_material
        count = 0

        for obj in context.selected_objects:
            if obj == active_obj or obj.type not in {'MESH', 'CURVE', 'SURFACE'}:
                continue
            if len(obj.material_slots) == 0:
                obj.data.materials.append(target_mat)
            else:
                idx = obj.active_material_index
                if 0 <= idx < len(obj.material_slots):
                    obj.material_slots[idx].material = target_mat
                else:
                    obj.material_slots[0].material = target_mat
            count += 1

        self.report({'INFO'}, f"Linked material '{target_mat.name}' to {count} selected objects.")
        return {'FINISHED'}


class RENDERFLO_OT_make_material_unique(bpy.types.Operator):
    bl_idname = "renderflo.make_material_unique"
    bl_label = "Unlink Material (Make Unique)"
    bl_description = "Duplicate this slot's material into an independent single-user copy so edits won't affect other parts"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.active_material is not None

    def execute(self, context):
        obj = context.active_object
        orig_mat = obj.active_material
        new_mat = orig_mat.copy()
        new_mat.name = f"{orig_mat.name}_Unique"
        obj.active_material = new_mat
        self.report({'INFO'}, f"Created unique material copy: '{new_mat.name}' on {obj.name}")
        return {'FINISHED'}


# ------------------------------------------------------------------------
# Look-Dev Shader Orb Spawner
# ------------------------------------------------------------------------

class RENDERFLO_OT_spawn_shader_orb(bpy.types.Operator):
    bl_idname = "renderflo.spawn_shader_orb"
    bl_label = "Spawn ID Look-Dev Orb"
    bl_description = "Spawn a calibrated industrial design shader ball in the viewport to evaluate highlights and reflections"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Create sphere with flat base for studio look-dev
        bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, radius=0.15)
        orb = context.active_object
        orb.name = "ID_Material_LookDev_Orb"
        bpy.ops.object.shade_smooth()

        # Assign active material if available
        src_obj = next((o for o in context.selected_objects if o != orb and getattr(o, "active_material", None)), None)
        if src_obj and src_obj.active_material:
            orb.data.materials.append(src_obj.active_material)

        # Place near 3D cursor
        orb.location = context.scene.cursor.location
        orb.location.z += 0.15
        self.report({'INFO'}, f"Spawned Look-Dev Orb: '{orb.name}'")
        return {'FINISHED'}


# ------------------------------------------------------------------------
# Material Items Synchronization & Collection Helpers
# ------------------------------------------------------------------------

def sync_material_items(scene):
    if not scene or not hasattr(scene, "rf_material_items"):
        return
    cat = getattr(scene, "rf_mat_category", 'ALL')
    items = scene.rf_material_items
    items.clear()

    CATEGORY_LABELS = {
        'METALS': "Metals",
        'PLASTICS': "Plastics",
        'GLASS': "Glass",
        'SPECIALTY': "Specialty",
        'USER': "Saved",
        'CUSTOM': "Custom",
    }

    # 1. Built-in presets
    if cat != 'USER':
        for p_id, p_info in BUILTIN_PRESETS.items():
            if cat == 'ALL' or p_info.get("category") == cat:
                it = items.add()
                it.preset_id = p_id
                it.name = p_info["name"]
                raw_cat = p_info.get("category", "General")
                it.category = CATEGORY_LABELS.get(raw_cat, raw_cat.title())
                it.description = p_info.get("desc", "")

    # 2. User-saved presets
    if cat in {'ALL', 'USER'}:
        user_mats = get_user_saved_materials_list()
        for mat_name, user_cat, _ in user_mats:
            it = items.add()
            it.preset_id = f"USER::{mat_name}"
            it.name = f"★ {mat_name}"
            it.category = CATEGORY_LABELS.get(user_cat, user_cat.title())
            it.description = "User Saved Material"

    # Match active index with scene.rf_mat_preset
    if len(items) > 0:
        cur_preset = getattr(scene, "rf_mat_preset", "")
        found_idx = -1
        for idx, it in enumerate(items):
            if it.preset_id == cur_preset:
                found_idx = idx
                break
        if found_idx >= 0:
            if scene.rf_material_active_index != found_idx:
                scene.rf_material_active_index = found_idx
        elif scene.rf_material_active_index >= len(items):
            scene.rf_material_active_index = 0
            scene.rf_mat_preset = items[0].preset_id
        else:
            scene.rf_mat_preset = items[scene.rf_material_active_index].preset_id


def ensure_material_items_synced(scene=None):
    if scene is None:
        scene = getattr(bpy.context, "scene", None)
    if scene and hasattr(scene, "rf_material_items") and len(scene.rf_material_items) == 0:
        sync_material_items(scene)
    return None


@persistent
def _on_load_post(dummy):
    try:
        scene = getattr(bpy.context, "scene", None)
        if scene:
            sync_material_items(scene)
    except Exception:
        pass


# ------------------------------------------------------------------------
# UIList: Scrollable Material Library List with Previews & Real-Time Search
# ------------------------------------------------------------------------

class RENDERFLO_UL_material_list(bpy.types.UIList):
    bl_idname = "RENDERFLO_UL_material_list"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        pcoll = get_material_preview_collection()
        icon_id = 0
        if item.preset_id in pcoll:
            icon_id = pcoll[item.preset_id].icon_id

        scale_val = getattr(context.scene, "rf_mat_preview_scale", 1.25)
        row = layout.row(align=True)
        row.scale_y = scale_val

        # 3D Thumbnail Icon & Name
        if icon_id:
            row.label(text=item.name, icon_value=icon_id)
        else:
            row.label(text=item.name, icon='MATERIAL')

        # Right sub-row: Category badge & 1-click apply button
        sub = row.row(align=True)
        sub.alignment = 'RIGHT'
        if scale_val < 1.45 and item.category:
            sub.label(text=f"[{item.category}]")
        op = sub.operator("renderflo.apply_id_material", text="Apply" if scale_val >= 1.5 else "", icon='IMPORT', emboss=False)
        op.preset_id = item.preset_id

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        flt_flags = []
        flt_neworder = []
        if self.filter_name:
            flt_flags = bpy.types.UI_UL_list.filter_items_by_name(
                self.filter_name,
                self.bitflag_filter_item,
                items,
                "name",
                reverse=self.use_filter_sort_reverse
            )
        return flt_flags, flt_neworder


class RENDERFLO_OT_refresh_material_library(bpy.types.Operator):
    bl_idname = "renderflo.refresh_material_library"
    bl_label = "Refresh Material Library"
    bl_description = "Reload material library items and preview thumbnails"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        sync_material_items(context.scene)
        self.report({'INFO'}, "Material library refreshed.")
        return {'FINISHED'}


# ------------------------------------------------------------------------
# Registration
# ------------------------------------------------------------------------

material_library_classes = (
    RENDERFLO_OT_select_id_material,
    RENDERFLO_OT_apply_id_material,
    RENDERFLO_OT_save_material_to_library,
    RENDERFLO_OT_update_material_preset,
    RENDERFLO_OT_delete_library_material,
    RENDERFLO_OT_link_materials_to_selected,
    RENDERFLO_OT_make_material_unique,
    RENDERFLO_OT_spawn_shader_orb,
    RENDERFLO_OT_refresh_material_library,
    RENDERFLO_UL_material_list,
)


def register():
    for cls in material_library_classes:
        bpy.utils.register_class(cls)

    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)

    try:
        if hasattr(bpy.context, "scene") and bpy.context.scene:
            ensure_material_items_synced(bpy.context.scene)
    except Exception:
        pass


def unregister():
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)

    global preview_collections
    for pcoll in preview_collections.values():
        try:
            bpy.utils.previews.remove(pcoll)
        except Exception:
            pass
    preview_collections.clear()

    for cls in reversed(material_library_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
