# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.3.0 — CAD Bridge & Tessellation Kernel (Standalone Edition).
Isolated OpenCASCADE (cascadio), Native Rhino (.3dm via rhino3dm), Safe Mesh Dispatchers,
Dynamic Engine Installer, and 1-Click Parametric CAD Hot-Reload.
"""

import bpy
import os
import sys
import math
import uuid
import tempfile
import subprocess
import pickle
from mathutils import Vector
from bpy_extras.io_utils import ImportHelper, ExportHelper

from ..state import (
    TARGET_EMPTY_NAME,
    GROUND_PLANE_NAME,
    BACKDROP_OBJ_NAME,
    _CASCADIO_AVAILABLE,
    _RHINO3DM_AVAILABLE,
    _CAD_ENGINE_AVAILABLE,
)

# ------------------------------------------------------------------------
# Direct Wheel Imports (Fallback Check)
# ------------------------------------------------------------------------
try:
    import cascadio
    _CASCADIO_AVAILABLE = True
except Exception:
    cascadio = None
    _CASCADIO_AVAILABLE = False

try:
    import rhino3dm
    _RHINO3DM_AVAILABLE = True
except Exception:
    rhino3dm = None
    _RHINO3DM_AVAILABLE = False


# ------------------------------------------------------------------------
# Version-Safe Mesh Import Dispatcher (Blender 3.6 - 5.2.2+)
# ------------------------------------------------------------------------

def safe_import_stl(filepath):
    if hasattr(bpy.ops.wm, "stl_import"):
        bpy.ops.wm.stl_import(filepath=filepath)
    elif hasattr(bpy.ops.import_mesh, "stl"):
        bpy.ops.import_mesh.stl(filepath=filepath)


def safe_import_obj(filepath):
    if hasattr(bpy.ops.wm, "obj_import"):
        bpy.ops.wm.obj_import(filepath=filepath)
    elif hasattr(bpy.ops.import_scene, "obj"):
        bpy.ops.import_scene.obj(filepath=filepath)


def safe_import_ply(filepath):
    if hasattr(bpy.ops.wm, "ply_import"):
        bpy.ops.wm.ply_import(filepath=filepath)
    elif hasattr(bpy.ops.import_mesh, "ply"):
        bpy.ops.import_mesh.ply(filepath=filepath)


# ------------------------------------------------------------------------
# Environment Isolation, Python Interpreter & Engine Paths
# ------------------------------------------------------------------------

def get_python_exe():
    """
    Reliably returns the executable path to Blender's Python interpreter.
    Avoids using 'blender.exe' which cannot run standard Python commands or pip.
    """
    if sys.executable and "python" in os.path.basename(sys.executable).lower():
        return sys.executable

    candidates = []
    if sys.prefix:
        candidates.extend([
            os.path.join(sys.prefix, "bin", "python.exe"),
            os.path.join(sys.prefix, "python.exe"),
            os.path.join(sys.prefix, "bin", "python3"),
            os.path.join(sys.prefix, "bin", "python"),
        ])

    try:
        b_bin = bpy.app.binary_path
        if b_bin:
            b_dir = os.path.dirname(b_bin)
            ver = f"{bpy.app.version[0]}.{bpy.app.version[1]}"
            candidates.extend([
                os.path.join(b_dir, ver, "python", "bin", "python.exe"),
                os.path.join(b_dir, "python", "bin", "python.exe"),
                os.path.join(b_dir, ver, "python", "bin", "python3"),
                os.path.join(b_dir, "python", "bin", "python3"),
            ])
    except Exception:
        pass

    for c in candidates:
        if os.path.isfile(c):
            return c

    return sys.executable


# ------------------------------------------------------------------------
# Cached Engine State & DLL Management (0ms overhead in draw loops)
# ------------------------------------------------------------------------
_CACHED_OCC_READY = False
_CACHED_RHINO_READY = False
_CACHED_ENGINE_DIR = None
_CACHED_SEARCH_PATHS = None
_REGISTERED_DLL_DIRS = set()


def get_cad_engine_dir():
    """
    Returns the writable directory where CAD wheels are installed / extracted.
    Strictly located OUTSIDE the extension directory to maintain 100% compliance
    with official Blender Extensions Platform repository policy.
    """
    global _CACHED_ENGINE_DIR
    if _CACHED_ENGINE_DIR and os.path.isdir(_CACHED_ENGINE_DIR):
        return _CACHED_ENGINE_DIR

    # 1. Blender 4.2+ official extension site-packages directory
    try:
        if hasattr(bpy.utils, "user_resource"):
            ext_res = bpy.utils.user_resource("EXTENSIONS")
            if ext_res:
                target = os.path.join(ext_res, ".local", "lib", f"python{sys.version_info.major}.{sys.version_info.minor}", "site-packages")
                os.makedirs(target, exist_ok=True)
                _CACHED_ENGINE_DIR = target
                return target
    except Exception:
        pass

    # 2. Blender User Data directory (for Blender 3.6 - 4.1 or standalone fallback)
    try:
        if hasattr(bpy.utils, "user_resource"):
            target = bpy.utils.user_resource("DATA", "id_renderflo_cad_engine", create=True)
            if target and os.path.isdir(target):
                _CACHED_ENGINE_DIR = target
                return target
    except Exception:
        pass

    # 3. Temp directory fallback
    target = os.path.join(tempfile.gettempdir(), "id_renderflo_cad_engine")
    os.makedirs(target, exist_ok=True)
    _CACHED_ENGINE_DIR = target
    return target


def get_extension_search_paths(force_rescan=False):
    """
    Returns search directories for CAD packages.
    Caches the list so it is NEVER repeatedly scanned during 60 FPS UI draw calls.
    STRICT POLICY RULE: Never includes extension directory or subdirectories in sys.path.
    """
    global _CACHED_SEARCH_PATHS
    if _CACHED_SEARCH_PATHS is not None and not force_rescan:
        return _CACHED_SEARCH_PATHS

    paths = []
    addon_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # 1. Blender extensions site-packages
    try:
        if hasattr(bpy.utils, "user_resource"):
            ext_res = bpy.utils.user_resource("EXTENSIONS")
            if ext_res:
                sp = os.path.join(ext_res, ".local", "lib", f"python{sys.version_info.major}.{sys.version_info.minor}", "site-packages")
                if os.path.isdir(sp) and sp not in paths:
                    paths.append(sp)
    except Exception:
        pass

    # 2. Dedicated engine dir (always external, strictly outside addon_dir)
    eng_dir = get_cad_engine_dir()
    if os.path.isdir(eng_dir) and eng_dir not in paths:
        paths.append(eng_dir)

    # 3. Active sys.path site-packages
    for p in sys.path:
        if ("site-packages" in p or "dist-packages" in p) and os.path.isdir(p) and p not in paths:
            paths.append(p)

    # Register in sys.path and add DLL directory (only once!)
    # CRITICAL: Exclude addon_dir and any subpaths inside addon_dir to satisfy Blender policy checks
    for p in paths:
        if p == addon_dir or p.startswith(addon_dir + os.sep):
            continue
        if p not in sys.path:
            sys.path.insert(0, p)
        libs_dir = os.path.join(p, "cascadio.libs")
        if hasattr(os, "add_dll_directory") and os.path.isdir(libs_dir) and libs_dir not in _REGISTERED_DLL_DIRS:
            try:
                os.add_dll_directory(libs_dir)
                _REGISTERED_DLL_DIRS.add(libs_dir)
            except Exception:
                pass

    _CACHED_SEARCH_PATHS = [p for p in paths if p != addon_dir and not p.startswith(addon_dir + os.sep)]
    return _CACHED_SEARCH_PATHS


def refresh_engine_status():
    """
    Scans environment and updates cached readiness flags.
    Called ONLY during register(), install, browse, or explicit recheck.
    Never called inside UI draw loops.
    """
    global _CACHED_OCC_READY, _CACHED_RHINO_READY, _CASCADIO_AVAILABLE, _RHINO3DM_AVAILABLE, cascadio, rhino3dm
    from .. import state

    # 1. Check if direct import works
    try:
        import cascadio as _c
        cascadio = _c
        _CACHED_OCC_READY = True
    except Exception:
        _CACHED_OCC_READY = False

    try:
        import rhino3dm as _r
        rhino3dm = _r
        _CACHED_RHINO_READY = True
    except Exception:
        _CACHED_RHINO_READY = False

    # 2. Check local search paths
    search_paths = get_extension_search_paths(force_rescan=True)
    for sp in search_paths:
        if not _CACHED_OCC_READY:
            if os.path.isdir(os.path.join(sp, "cascadio")):
                try:
                    import cascadio as _c
                    cascadio = _c
                    _CACHED_OCC_READY = True
                except Exception:
                    pass

        if not _CACHED_RHINO_READY:
            if os.path.isdir(os.path.join(sp, "rhino3dm")):
                try:
                    import rhino3dm as _r
                    rhino3dm = _r
                    _CACHED_RHINO_READY = True
                except Exception:
                    pass

    # 3. If either engine is missing, auto-extract from bundled wheels/ if available
    if not _CACHED_OCC_READY or not _CACHED_RHINO_READY:
        addon_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        wheels_dir = os.path.join(addon_dir, "wheels")
        if os.path.isdir(wheels_dir):
            import zipfile
            eng_dir = get_cad_engine_dir()
            py_ver = f"cp{sys.version_info.major}{sys.version_info.minor}"
            for fname in os.listdir(wheels_dir):
                if not fname.lower().endswith(".whl"):
                    continue
                f_lower = fname.lower()
                need_occ = not _CACHED_OCC_READY and "cascadio" in f_lower
                need_rhino = not _CACHED_RHINO_READY and "rhino3dm" in f_lower
                if need_occ or need_rhino:
                    plat_match = False
                    if sys.platform.startswith("win") and ("win_amd64" in f_lower or "win32" in f_lower):
                        plat_match = True
                    elif sys.platform == "darwin":
                        import platform
                        arch = platform.machine().lower()
                        if "universal" in f_lower or arch in f_lower or ("arm" in arch and "arm64" in f_lower) or ("x86_64" in arch and "x86_64" in f_lower):
                            plat_match = True
                    elif sys.platform.startswith("linux") and ("linux" in f_lower or "manylinux" in f_lower):
                        plat_match = True
                    elif "any" in f_lower or "py3-none-any" in f_lower:
                        plat_match = True

                    is_py_compat = py_ver in f_lower or "py3" in f_lower or ("abi3" in f_lower and sys.version_info >= (3, 12))
                    if plat_match and is_py_compat:
                        try:
                            fpath = os.path.join(wheels_dir, fname)
                            with zipfile.ZipFile(fpath, 'r') as zf:
                                zf.extractall(eng_dir)
                        except Exception:
                            pass

            # Re-check search paths after unpacking
            search_paths = get_extension_search_paths(force_rescan=True)
            for sp in search_paths:
                if not _CACHED_OCC_READY and os.path.isdir(os.path.join(sp, "cascadio")):
                    try:
                        import cascadio as _c
                        cascadio = _c
                        _CACHED_OCC_READY = True
                    except Exception:
                        pass
                if not _CACHED_RHINO_READY and os.path.isdir(os.path.join(sp, "rhino3dm")):
                    try:
                        import rhino3dm as _r
                        rhino3dm = _r
                        _CACHED_RHINO_READY = True
                    except Exception:
                        pass

    _CASCADIO_AVAILABLE = _CACHED_OCC_READY
    _RHINO3DM_AVAILABLE = _CACHED_RHINO_READY
    state._CASCADIO_AVAILABLE = _CACHED_OCC_READY
    state._RHINO3DM_AVAILABLE = _CACHED_RHINO_READY
    return _CACHED_OCC_READY, _CACHED_RHINO_READY


def is_cascadio_ready(force_recheck=False):
    """Fast, 0ms check for UI draw calls. Reads cached boolean."""
    if force_recheck:
        refresh_engine_status()
    return _CACHED_OCC_READY


def is_rhino_ready(force_recheck=False):
    """Fast, 0ms check for UI draw calls. Reads cached boolean."""
    if force_recheck:
        refresh_engine_status()
    return _CACHED_RHINO_READY


def is_cad_engine_ready(force_recheck=False):
    """Fast, 0ms check for UI draw calls. Reads cached boolean."""
    if force_recheck:
        refresh_engine_status()
    return _CACHED_OCC_READY and _CACHED_RHINO_READY


def is_engine_ready_for_ext(ext):
    ext = (ext or "").lower()
    if ext in {'.step', '.stp', '.iges', '.igs'}:
        return is_cascadio_ready()
    elif ext == '.3dm':
        return is_rhino_ready()
    return True


def extract_wheel_or_archive(filepath):
    """
    Extracts an offline .whl or .zip archive into the engine directory.
    When a .whl is chosen, also auto-discovers companion .whl files in the same folder.
    """
    if not filepath or not os.path.exists(filepath):
        return False, "File does not exist"

    engine_dir = get_cad_engine_dir()
    os.makedirs(engine_dir, exist_ok=True)
    import zipfile
    import io

    extracted_count = 0
    ext = os.path.splitext(filepath)[1].lower()

    try:
        if ext == '.whl':
            with zipfile.ZipFile(filepath, 'r') as zf:
                zf.extractall(engine_dir)
            extracted_count += 1

            parent_dir = os.path.dirname(filepath)
            for fname in os.listdir(parent_dir):
                f_path = os.path.join(parent_dir, fname)
                if f_path != filepath and fname.lower().endswith(".whl"):
                    if any(k in fname.lower() for k in ("cascadio", "rhino3dm")):
                        try:
                            with zipfile.ZipFile(f_path, 'r') as zf:
                                zf.extractall(engine_dir)
                            extracted_count += 1
                        except Exception:
                            pass

        elif ext == '.zip':
            with zipfile.ZipFile(filepath, 'r') as zf:
                wheel_entries = [e for e in zf.namelist() if e.lower().endswith(".whl") and any(k in e.lower() for k in ("cascadio", "rhino3dm"))]
                if wheel_entries:
                    for we in wheel_entries:
                        whl_bytes = zf.read(we)
                        with zipfile.ZipFile(io.BytesIO(whl_bytes)) as inner_zf:
                            inner_zf.extractall(engine_dir)
                        extracted_count += 1
                else:
                    cad_entries = [e for e in zf.namelist() if any(e.startswith(p) for p in ("cascadio", "rhino3dm"))]
                    if cad_entries:
                        zf.extractall(engine_dir)
                        extracted_count += 1

        if extracted_count > 0:
            refresh_engine_status()
            return True, f"Successfully installed CAD engine from '{os.path.basename(filepath)}'!"
        else:
            return False, "No OpenCASCADE (cascadio) or Rhino3DM wheels found in the selected file."
    except Exception as e:
        return False, f"Failed to extract CAD archive: {e}"


def install_cad_engine(target_pkg='ALL'):
    """
    Installs OpenCASCADE (cascadio) and/or Rhino3DM engines.
    1. Checks offline candidate wheels in addon wheels/ or ~/Downloads.
    2. Runs pip install via Blender's Python into the engine directory.
    Returns (success: bool, message: str).
    """
    target_pkg = (target_pkg or 'ALL').upper()
    engine_dir = get_cad_engine_dir()
    os.makedirs(engine_dir, exist_ok=True)

    import zipfile
    import io

    # 1. Check local offline candidates in addon wheels/ or ~/Downloads
    candidate_sources = []
    addon_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    addon_wheels = os.path.join(addon_dir, "wheels")
    if os.path.isdir(addon_wheels):
        candidate_sources.append(addon_wheels)
    try:
        dl_dir = os.path.expanduser("~/Downloads")
        if os.path.isdir(dl_dir):
            candidate_sources.append(dl_dir)
    except Exception:
        pass

    for src in candidate_sources:
        try:
            for fname in os.listdir(src):
                fpath = os.path.join(src, fname)
                f_lower = fname.lower()
                if f_lower.endswith(".whl"):
                    need_casc = (target_pkg in ('ALL', 'OCC') and not _CACHED_OCC_READY) and "cascadio" in f_lower
                    need_rhino = (target_pkg in ('ALL', 'RHINO') and not _CACHED_RHINO_READY) and "rhino3dm" in f_lower
                    if need_casc or need_rhino:
                        try:
                            with zipfile.ZipFile(fpath, 'r') as zf:
                                zf.extractall(engine_dir)
                        except Exception:
                            pass
                elif f_lower.startswith("id_renderflo") and f_lower.endswith(".zip"):
                    try:
                        with zipfile.ZipFile(fpath, 'r') as zf:
                            for we in zf.namelist():
                                if we.lower().endswith(".whl") and any(k in we.lower() for k in ("cascadio", "rhino3dm")):
                                    whl_bytes = zf.read(we)
                                    with zipfile.ZipFile(io.BytesIO(whl_bytes)) as inner_zf:
                                        inner_zf.extractall(engine_dir)
                    except Exception:
                        pass
        except Exception:
            pass

    refresh_engine_status()
    if (target_pkg == 'OCC' and _CACHED_OCC_READY) or (target_pkg == 'RHINO' and _CACHED_RHINO_READY) or (target_pkg == 'ALL' and _CACHED_OCC_READY and _CACHED_RHINO_READY):
        return True, "CAD Engine installed and activated from local files!"

    # 2. Pip install fallback via Blender's python.exe
    pkgs_to_install = []
    if target_pkg in ('ALL', 'OCC') and not _CACHED_OCC_READY:
        pkgs_to_install.append("cascadio==0.1.1")
    if target_pkg in ('ALL', 'RHINO') and not _CACHED_RHINO_READY:
        pkgs_to_install.append("rhino3dm==8.17.0")

    if not pkgs_to_install:
        return True, "Requested engines are already active!"

    py_exe = get_python_exe()
    if not py_exe or not os.path.exists(py_exe):
        return False, "Could not locate Blender's Python interpreter for pip installation."

    try:
        p_chk = subprocess.run([py_exe, "-m", "pip", "--version"], capture_output=True, text=True, timeout=15)
        if p_chk.returncode != 0:
            subprocess.run([py_exe, "-m", "ensurepip", "--default-pip"], capture_output=True, text=True, timeout=30)
    except Exception:
        pass

    try:
        cmd = [py_exe, "-m", "pip", "install", *pkgs_to_install, "--target", engine_dir]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        if res.returncode != 0:
            err_msg = (res.stderr or res.stdout or "").strip()
            return False, f"pip install failed ({res.returncode}): {err_msg[:250]}"
    except Exception as e:
        return False, f"Failed executing pip: {e}"

    refresh_engine_status()

    if _CACHED_OCC_READY and _CACHED_RHINO_READY:
        return True, "CAD Engine (OpenCASCADE & Rhino3DM) installed and activated successfully!"
    elif _CACHED_OCC_READY:
        return True, "OpenCASCADE (STEP) engine active. Rhino3DM is not yet installed."
    elif _CACHED_RHINO_READY:
        return True, "Rhino3DM engine active. OpenCASCADE (STEP) is not yet installed."
    else:
        return False, "Could not install CAD engine. Please verify internet connection or provide offline wheels (.whl / .zip)."


def bootstrap_cad_engine():
    success, _ = install_cad_engine(target_pkg='ALL')
    return success


def has_parasolid_bridge():
    rhino_candidates = [
        r"C:\Program Files\Rhino 8\System\Rhino.exe",
        r"C:\Program Files\Rhino 7\System\Rhino.exe",
    ]
    return any(os.path.exists(p) for p in rhino_candidates)


# ------------------------------------------------------------------------
CAD_WORKER_CODE = r"""
import sys
import os

site_dirs = sys.argv[1].split(os.pathsep) if len(sys.argv) > 1 and sys.argv[1] else []
filepath = sys.argv[2]
out_glb = sys.argv[3]
lin_tol = float(sys.argv[4])
ang_rad = float(sys.argv[5])

for sdir in site_dirs:
    if sdir and os.path.isdir(sdir):
        libs_dir = os.path.join(sdir, "cascadio.libs")
        if hasattr(os, "add_dll_directory") and os.path.isdir(libs_dir):
            try:
                os.add_dll_directory(libs_dir)
            except Exception:
                pass
        try:
            import site
            site.addsitedir(sdir)
        except Exception:
            pass
        if sdir not in sys.path:
            sys.path.insert(0, sdir)

import cascadio
cascadio.step_to_glb(filepath, out_glb, lin_tol, ang_rad)
"""


def execute_universal_cad_import(context, filepath, lin_tol, ang_rad):
    base_name = os.path.splitext(os.path.basename(filepath))[0]
    tmp_dir = tempfile.gettempdir()
    out_glb = os.path.join(tmp_dir, f"_rf_{base_name}_{uuid.uuid4().hex[:6]}.glb")

    if os.path.exists(out_glb):
        try:
            os.remove(out_glb)
        except OSError:
            pass

    search_paths = get_extension_search_paths()
    for sp in search_paths:
        if sp not in sys.path:
            sys.path.insert(0, sp)
        libs_dir = os.path.join(sp, "cascadio.libs")
        if hasattr(os, "add_dll_directory") and os.path.isdir(libs_dir):
            try:
                os.add_dll_directory(libs_dir)
            except Exception:
                pass

    converted = False
    try:
        import cascadio
        cascadio.step_to_glb(filepath, out_glb, lin_tol, ang_rad)
        converted = os.path.exists(out_glb)
    except Exception:
        converted = False

    if not converted:
        worker_script = os.path.join(tmp_dir, f"_rf_cad_worker_{uuid.uuid4().hex[:6]}.py")
        try:
            with open(worker_script, "w", encoding="utf-8") as f:
                f.write(CAD_WORKER_CODE)

            sp_arg = os.pathsep.join(search_paths)
            py_exe = get_python_exe()
            res = subprocess.run(
                [py_exe, worker_script, sp_arg, filepath, out_glb, str(lin_tol), str(ang_rad)],
                capture_output=True, text=True
            )
            converted = (res.returncode == 0 and os.path.exists(out_glb))
        finally:
            if os.path.exists(worker_script):
                try:
                    os.remove(worker_script)
                except OSError:
                    pass

    if not converted or not os.path.exists(out_glb):
        raise RuntimeError("CAD conversion failed to produce intermediate geometry. Ensure OpenCASCADE / cascadio engine is installed.")

    before = set(context.scene.objects)
    bpy.ops.import_scene.gltf(filepath=out_glb)

    try:
        os.remove(out_glb)
    except OSError:
        pass

    return [o for o in context.scene.objects if o not in before]

RHINO_WORKER_CODE = r"""
import sys
import os
import pickle

site_dirs = sys.argv[1].split(os.pathsep) if len(sys.argv) > 1 and sys.argv[1] else []
filepath = sys.argv[2]
out_pickle = sys.argv[3]

for sdir in site_dirs:
    if sdir and os.path.isdir(sdir):
        try:
            import site
            site.addsitedir(sdir)
        except Exception:
            if sdir not in sys.path:
                sys.path.insert(0, sdir)

import rhino3dm

model = None
try:
    model = rhino3dm.File3dm.Read(filepath)
except Exception:
    pass

if not model:
    try:
        with open(filepath, "rb") as bf:
            model = rhino3dm.File3dm.FromByteArray(bf.read())
    except Exception:
        pass

if not model:
    base_file = os.path.basename(filepath)
    raise RuntimeError(
        f"Could not parse '{base_file}'. The file appears corrupted or unfinalized. "
        "Please save natively in Rhino (File > Save) as .3dm or export as .STEP."
    )

unit_scale = 1.0
try:
    unit_sys = model.Settings.ModelUnitSystem
    unit_scale = rhino3dm.UnitSystem.UnitScale(unit_sys, rhino3dm.UnitSystem.Meters)
    if not unit_scale or unit_scale <= 0:
        unit_scale = 1.0
except Exception:
    unit_scale = 1.0

objects_data = []
breps_without_mesh = 0

for obj in model.Objects:
    attr = obj.Attributes
    if not attr or not attr.Visible:
        continue

    layer = None
    if 0 <= attr.LayerIndex < len(model.Layers):
        layer = model.Layers[attr.LayerIndex]

    if layer and not layer.Visible:
        continue

    layer_name = layer.Name if layer and layer.Name else "Default"
    col = layer.Color if layer else (180, 180, 180, 255)
    color_rgba = (col[0] / 255.0, col[1] / 255.0, col[2] / 255.0, 1.0)

    geom = obj.Geometry
    if not geom:
        continue

    rhino_meshes = []
    geom_type = geom.ObjectType

    if geom_type == rhino3dm.ObjectType.Mesh:
        rhino_meshes.append(geom)
    elif geom_type == rhino3dm.ObjectType.Brep:
        for f in geom.Faces:
            try:
                m = f.GetMesh(rhino3dm.MeshType.Any)
                if m and len(m.Vertices) > 0:
                    rhino_meshes.append(m)
            except Exception:
                pass
        if not rhino_meshes:
            breps_without_mesh += 1
    elif geom_type == rhino3dm.ObjectType.Extrusion:
        try:
            m = geom.GetMesh(rhino3dm.MeshType.Any)
            if m and len(m.Vertices) > 0:
                rhino_meshes.append(m)
        except Exception:
            pass
    elif geom_type == rhino3dm.ObjectType.SubD:
        try:
            if hasattr(rhino3dm.Mesh, "CreateFromSubDControlNet"):
                m = rhino3dm.Mesh.CreateFromSubDControlNet(geom)
                if m and len(m.Vertices) > 0:
                    rhino_meshes.append(m)
        except Exception:
            pass

    if not rhino_meshes:
        continue

    all_verts = []
    all_faces = []
    all_normals = []
    has_valid_normals = True

    for rm in rhino_meshes:
        v_offset = len(all_verts)
        rm_verts = [(v.X, v.Y, v.Z) for v in rm.Vertices]
        all_verts.extend(rm_verts)

        for f in rm.Faces:
            if f[2] == f[3]:
                all_faces.append((f[0] + v_offset, f[1] + v_offset, f[2] + v_offset))
            else:
                all_faces.append((f[0] + v_offset, f[1] + v_offset, f[2] + v_offset, f[3] + v_offset))

        if len(rm.Normals) == len(rm.Vertices):
            all_normals.extend([(n.X, n.Y, n.Z) for n in rm.Normals])
        else:
            has_valid_normals = False

    if all_verts and all_faces:
        obj_name = attr.Name if attr.Name else f"{layer_name}_{len(objects_data) + 1}"
        objects_data.append({
            'name': obj_name,
            'layer_name': layer_name,
            'layer_color': color_rgba,
            'verts': all_verts,
            'faces': all_faces,
            'normals': all_normals if has_valid_normals and len(all_normals) == len(all_verts) else []
        })

payload = {
    'unit_scale': unit_scale,
    'objects': objects_data,
    'breps_without_mesh': breps_without_mesh
}

with open(out_pickle, 'wb') as f:
    pickle.dump(payload, f)
"""



def import_rhino_3dm(filepath, context):
    search_paths = get_extension_search_paths()
    sp_arg = os.pathsep.join(search_paths)
    tmp_dir = tempfile.gettempdir()
    worker_script = os.path.join(tmp_dir, f"_rf_3dm_worker_{uuid.uuid4().hex[:8]}.py")
    out_pickle = os.path.join(tmp_dir, f"_rf_3dm_{uuid.uuid4().hex[:8]}.pkl")

    with open(worker_script, "w", encoding="utf-8") as f:
        f.write(RHINO_WORKER_CODE)

    py_exe = get_python_exe()
    res = subprocess.run(
        [py_exe, worker_script, sp_arg, filepath, out_pickle],
        capture_output=True, text=True
    )

    if res.returncode != 0 or not os.path.exists(out_pickle):
        raw_err = (res.stderr or res.stdout or "").strip()
        clean_msg = "Unknown .3dm parsing error"
        for line in reversed(raw_err.splitlines()):
            line = line.strip()
            if not line:
                continue
            if "RuntimeError:" in line:
                clean_msg = line.split("RuntimeError:", 1)[1].strip()
                break
            elif "Error:" in line or "Exception:" in line:
                clean_msg = line
                break
            elif clean_msg == "Unknown .3dm parsing error":
                clean_msg = line
        try:
            if os.path.exists(worker_script):
                os.remove(worker_script)
        except OSError:
            pass
        raise RuntimeError(clean_msg)

    with open(out_pickle, "rb") as f:
        data = pickle.load(f)

    for p in (worker_script, out_pickle):
        try:
            if os.path.exists(p):
                os.remove(p)
        except OSError:
            pass

    objects_data = data.get("objects", [])
    breps_without_mesh = data.get("breps_without_mesh", 0)
    unit_scale = data.get("unit_scale", 1.0)

    created_objects = []

    for part in objects_data:
        m_name = part.get("name", "Rhino_Part")
        mesh = bpy.data.meshes.new(name=m_name)
        mesh.from_pydata(part["verts"], [], part["faces"])
        mesh.update()

        for poly in mesh.polygons:
            poly.use_smooth = True

        normals = part.get("normals", [])
        if normals and len(normals) == len(part["verts"]):
            if hasattr(mesh, "use_auto_smooth"):
                mesh.use_auto_smooth = True
            try:
                mesh.normals_split_custom_set_from_vertices(normals)
            except Exception:
                pass

        layer_name = part.get("layer_name", "Default")
        layer_color = part.get("layer_color", (0.8, 0.8, 0.8, 1.0))
        mat_name = f"Rhino_{layer_name}"
        mat = bpy.data.materials.get(mat_name)
        if not mat:
            mat = bpy.data.materials.new(name=mat_name)
            mat.use_nodes = True
            bsdf = next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
            if bsdf:
                col_socket = bsdf.inputs.get("Base Color") or bsdf.inputs.get("Color")
                if col_socket:
                    col_socket.default_value = (layer_color[0], layer_color[1], layer_color[2], 1.0)
                if "Roughness" in bsdf.inputs:
                    bsdf.inputs["Roughness"].default_value = 0.35

        obj = bpy.data.objects.new(m_name, mesh)
        context.scene.collection.objects.link(obj)
        obj.data.materials.append(mat)
        created_objects.append(obj)

    return created_objects, breps_without_mesh, unit_scale


def execute_rhino_import(context, filepath):
    return import_rhino_3dm(filepath, context)

# ------------------------------------------------------------------------
# CAD Operators: Dynamic Engine Setup, Import & 1-Click Hot-Reload
# ------------------------------------------------------------------------

class RENDERFLO_OT_bootstrap_cad_kernel(bpy.types.Operator):
    bl_idname = "renderflo.bootstrap_cad_kernel"
    bl_label = "Install CAD Engine Files (OCC & Rhino)"
    bl_description = "Install OpenCASCADE (STEP) and Rhino3DM CAD tessellation engines"
    bl_options = {'REGISTER'}

    package: bpy.props.EnumProperty(
        name="Package",
        items=[
            ('ALL', "All Engines (OCC & Rhino)", "Install both OpenCASCADE and Rhino3DM"),
            ('OCC', "OpenCASCADE (STEP / IGES)", "Install cascadio for STEP/STP/IGES solids"),
            ('RHINO', "Rhino3DM (.3dm)", "Install rhino3dm for native Rhino .3dm files"),
        ],
        default='ALL'
    )

    def execute(self, context):
        success, msg = install_cad_engine(target_pkg=self.package)
        if success:
            self.report({'INFO'}, f"ID RenderFlo: {msg}")
        else:
            self.report({'ERROR'}, f"ID RenderFlo: {msg}")
        for area in context.screen.areas:
            area.tag_redraw()
        return {'FINISHED'} if success else {'CANCELLED'}


class RENDERFLO_OT_recheck_cad_engine(bpy.types.Operator):
    bl_idname = "renderflo.recheck_cad_engine"
    bl_label = "Recheck CAD Engine Status"
    bl_description = "Rescan environment and paths for OpenCASCADE and Rhino3DM engines"
    bl_options = {'REGISTER'}

    def execute(self, context):
        occ = is_cascadio_ready(force_recheck=True)
        rhino = is_rhino_ready(force_recheck=True)
        if occ and rhino:
            self.report({'INFO'}, "ID RenderFlo: Both OpenCASCADE and Rhino3DM engines are active!")
        elif occ:
            self.report({'INFO'}, "ID RenderFlo: OpenCASCADE is active. Rhino3DM is not installed.")
        elif rhino:
            self.report({'INFO'}, "ID RenderFlo: Rhino3DM is active. OpenCASCADE is not installed.")
        else:
            self.report({'WARNING'}, "ID RenderFlo: No CAD engines detected in search paths.")
        for area in context.screen.areas:
            area.tag_redraw()
        return {'FINISHED'}


class RENDERFLO_OT_install_cad_dialog(bpy.types.Operator):
    bl_idname = "renderflo.install_cad_dialog"
    bl_label = "ID RenderFlo — CAD Engine Required"
    bl_description = "The CAD Tessellation Engine is required to import or reload CAD files"
    bl_options = {'REGISTER', 'INTERNAL'}

    missing_reason: bpy.props.StringProperty(
        name="Missing Reason",
        default="CAD Engine files (OpenCASCADE / OCC and Rhino3DM) are required to import CAD assemblies."
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=480)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.alert = True
        box.label(text="CAD Engine Installation Required", icon='ERROR')
        box.label(text=self.missing_reason)

        occ_ok = is_cascadio_ready()
        rhino_ok = is_rhino_ready()

        c = layout.box().column(align=True)
        r1 = c.row()
        r1.label(text="• OpenCASCADE (cascadio): STEP / STP / IGES solids", icon='CHECKMARK' if occ_ok else 'CANCEL')
        r1.label(text="Ready" if occ_ok else "Not Installed")

        r2 = c.row()
        r2.label(text="• Rhino3DM: Native Rhino .3DM Breps & SubDs", icon='CHECKMARK' if rhino_ok else 'CANCEL')
        r2.label(text="Ready" if rhino_ok else "Not Installed")

        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 1.3
        op = row.operator("renderflo.bootstrap_cad_kernel", text="Install CAD Engine Now (OCC & Rhino)", icon='IMPORT')
        op.package = 'ALL'

        layout.separator()
        layout.operator("renderflo.browse_cad_wheel", text="Browse Offline Wheel / Archive (.whl / .zip)...", icon='FILE_FOLDER')

    def execute(self, context):
        return bpy.ops.renderflo.bootstrap_cad_kernel('EXEC_DEFAULT', package='ALL')


class RENDERFLO_OT_browse_cad_wheel(bpy.types.Operator, ImportHelper):
    bl_idname = "renderflo.browse_cad_wheel"
    bl_label = "Select CAD Wheel or Archive (.whl / .zip)"
    bl_description = "Select an offline wheel (.whl) or zip archive containing CAD wheels"
    bl_options = {'REGISTER'}

    filename_ext = ".whl;.zip"
    filter_glob: bpy.props.StringProperty(
        default="*.whl;*.zip",
        options={'HIDDEN'},
        maxlen=255,
    )

    def execute(self, context):
        filepath = self.filepath
        if not filepath or not os.path.exists(filepath):
            self.report({'ERROR'}, "File not found")
            return {'CANCELLED'}

        success, msg = extract_wheel_or_archive(filepath)
        if success:
            self.report({'INFO'}, f"ID RenderFlo: {msg}")
            for area in context.screen.areas:
                area.tag_redraw()
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, f"ID RenderFlo: {msg}")
            return {'CANCELLED'}

class RENDERFLO_OT_import_cad(bpy.types.Operator, ImportHelper):
    bl_idname = "renderflo.import_cad"
    bl_label = "Import CAD (ID RenderFlo)"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".step"
    filter_glob: bpy.props.StringProperty(
        default="*.step;*.stp;*.3dm",
        options={'HIDDEN'},
        maxlen=255,
    )

    tess_preset: bpy.props.EnumProperty(
        name="Tessellation Quality",
        items=[
            ('ULTRA', "Ultra Fine (0.02mm)", "Highest accuracy for macro product shots"),
            ('HIGH', "High Quality (0.08mm)", "Balanced smooth fillets and polycount"),
            ('MEDIUM', "Medium (0.25mm)", "Optimized performance for large assemblies"),
            ('CUSTOM', "Custom Tolerances", "Manually specify linear and angular deflection"),
        ],
        default='HIGH'
    )
    linear_deflection: bpy.props.FloatProperty(name="Linear Deflection (mm)", default=0.08, min=0.001, max=10.0)
    angular_deflection: bpy.props.FloatProperty(name="Angular Deflection (deg)", default=15.0, min=1.0, max=90.0)
    up_axis: bpy.props.EnumProperty(
        name="CAD Up-Axis",
        items=[
            ('Z_UP', "Z-Up (Rhino / Fusion / Blender)", "Keep Z as Up-Axis"),
            ('Y_UP', "Y-Up (CAD Default)", "Rotate +90 deg on X to match Z-Up"),
        ],
        default='Z_UP'
    )
    unit_scale: bpy.props.EnumProperty(
        name="CAD Units",
        items=[
            ('MM_TO_M', "Millimeters (True Scale / Recommended)", "Converts CAD millimeters to real-world meters (0.001x)"),
            ('KEEP', "Raw Coordinates / Unscaled (1.0x)", "Preserves raw CAD coordinates without unit conversion (1 mm = 1 m)"),
            ('CM_TO_M', "Centimeters (0.01x)", "Scale by 0.01"),
            ('INCH_TO_M', "Inches (0.0254x)", "Scale by 0.0254"),
        ],
        default='MM_TO_M'
    )
    center_xy: bpy.props.BoolProperty(name="Center Product on X/Y Origin", default=True)
    snap_to_ground: bpy.props.BoolProperty(name="Snap Base to Floor (Z = 0)", default=True)
    auto_smooth_normals: bpy.props.BoolProperty(name="Weighted Normals (Clean Fillets)", default=True)

    def invoke(self, context, event):
        self.filter_glob = "*.step;*.stp;*.3dm"
        # If neither engine is ready, ask to install before opening file picker
        if not is_cascadio_ready() and not is_rhino_ready():
            return bpy.ops.renderflo.install_cad_dialog(
                'INVOKE_DEFAULT',
                missing_reason="OpenCASCADE (OCC) and Rhino3DM engines are required to import CAD files."
            )
        return super().invoke(context, event)

    def draw(self, context):
        layout = self.layout
        occ_ok = is_cascadio_ready()
        rhino_ok = is_rhino_ready()

        box = layout.box()
        if occ_ok and rhino_ok:
            box.label(text="Native CAD Engine Active (OpenCASCADE & Rhino)", icon='CHECKMARK')
        else:
            box.alert = True
            box.label(text="CAD Engine Incomplete / Missing", icon='ERROR')
            r = box.row(align=True)
            op = r.operator("renderflo.bootstrap_cad_kernel", text="Install CAD Engine (OCC & Rhino)", icon='IMPORT')
            op.package = 'ALL'

        box.prop(self, "tess_preset", text="Quality")
        if self.tess_preset == 'CUSTOM':
            col = box.column(align=True)
            col.prop(self, "linear_deflection")
            col.prop(self, "angular_deflection")

        box2 = layout.box()
        box2.label(text="Orientation & Units", icon='ORIENTATION_GLOBAL')
        box2.prop(self, "up_axis")
        box2.prop(self, "unit_scale")

        box3 = layout.box()
        box3.label(text="Auto-Prep Alignment", icon='MOD_REMESH')
        box3.prop(self, "center_xy")
        box3.prop(self, "snap_to_ground")
        box3.prop(self, "auto_smooth_normals")

    def execute(self, context):
        filepath = self.filepath
        if not filepath or not os.path.exists(filepath):
            self.report({'ERROR'}, f"File not found: {filepath}")
            return {'CANCELLED'}

        ext = os.path.splitext(filepath)[1].lower()
        base_name = os.path.splitext(os.path.basename(filepath))[0]

        # Check required engine for selected extension
        if not is_engine_ready_for_ext(ext):
            engine_name = "OpenCASCADE (cascadio)" if ext in {'.step', '.stp', '.iges', '.igs'} else "Rhino3DM"
            self.report({'ERROR'}, f"{engine_name} engine is required for {ext} files. Please install the CAD engine.")
            bpy.ops.renderflo.install_cad_dialog(
                'INVOKE_DEFAULT',
                missing_reason=f"{engine_name} is required to import {ext} files."
            )
            return {'CANCELLED'}

        if self.tess_preset == 'ULTRA':
            lin_tol, ang_tol = 0.02, 10.0
        elif self.tess_preset == 'HIGH':
            lin_tol, ang_tol = 0.08, 15.0
        elif self.tess_preset == 'MEDIUM':
            lin_tol, ang_tol = 0.25, 25.0
        else:
            lin_tol, ang_tol = self.linear_deflection, self.angular_deflection

        ang_rad = math.radians(ang_tol)
        before_objs = set(context.scene.objects)
        warn_breps = 0
        detected_scale = 1.0

        if ext in {'.step', '.stp', '.iges', '.igs'}:
            try:
                execute_universal_cad_import(context, filepath, lin_tol, ang_rad)
            except Exception as e:
                err_str = str(e)
                if any(k in err_str for k in ("cascadio", "OpenCASCADE")):
                    self.report({'ERROR'}, "OpenCASCADE (cascadio) engine missing or failed. Click 'Install CAD Engine'.")
                    bpy.ops.renderflo.install_cad_dialog(
                        'INVOKE_DEFAULT',
                        missing_reason="OpenCASCADE (cascadio) engine is missing or failed to initialize."
                    )
                else:
                    self.report({'ERROR'}, err_str)
                return {'CANCELLED'}
        elif ext == '.3dm':
            try:
                rhino_objs, warn_breps, detected_scale = import_rhino_3dm(filepath, context)
            except Exception as e:
                err_str = str(e)
                if any(k in err_str for k in ("rhino3dm", "Rhino")):
                    self.report({'ERROR'}, "Rhino3DM engine missing or failed. Click 'Install CAD Engine'.")
                    bpy.ops.renderflo.install_cad_dialog(
                        'INVOKE_DEFAULT',
                        missing_reason="Rhino3DM library is missing or failed to initialize."
                    )
                else:
                    self.report({'ERROR'}, err_str)
                return {'CANCELLED'}
        elif ext in {'.sldprt', '.sldasm', '.x_t', '.x_b', '.sat'}:
            self.report({'ERROR'}, f"SolidWorks and Parasolid files ({ext}) are not supported directly. Please export as STEP (.step / .stp) or Rhino (.3dm) in CAD, which ID RenderFlo imports with mathematical precision.")
            return {'CANCELLED'}
        elif ext == '.stl':
            safe_import_stl(filepath)
        elif ext == '.obj':
            safe_import_obj(filepath)
        elif ext == '.fbx':
            bpy.ops.import_scene.fbx(filepath=filepath)
        elif ext in {'.glb', '.gltf'}:
            bpy.ops.import_scene.gltf(filepath=filepath)
        elif ext == '.ply':
            safe_import_ply(filepath)
        else:
            self.report({'ERROR'}, f"Unsupported format: {ext}")
            return {'CANCELLED'}

        new_objs = [obj for obj in context.scene.objects if obj not in before_objs]
        if not new_objs:
            if ext == '.3dm' and warn_breps > 0:
                self.report({'WARNING'}, "No render meshes found in .3dm (saved in Wireframe mode). Save in Shaded mode in Rhino or export as .STEP.")
            else:
                self.report({'WARNING'}, "No geometry found in CAD file.")
            return {'CANCELLED'}

        cad_coll = bpy.data.collections.new(f"CAD_{base_name}")
        context.scene.collection.children.link(cad_coll)
        for obj in new_objs:
            for c in list(obj.users_collection):
                c.objects.unlink(obj)
            cad_coll.objects.link(obj)

        root_objs = [obj for obj in new_objs if obj.parent not in new_objs]
        assembly_root = bpy.data.objects.new(f"Assembly_{base_name}", None)
        assembly_root.empty_display_type = 'ARROWS'
        assembly_root.empty_display_size = 0.2
        cad_coll.objects.link(assembly_root)

        for r_obj in root_objs:
            r_obj.parent = assembly_root

        # Metadata tagging for 1-Click CAD Hot-Reload
        assembly_root["rf_cad_source_path"] = filepath
        assembly_root["rf_cad_tess_preset"] = self.tess_preset
        assembly_root["rf_cad_linear_deflection"] = lin_tol
        assembly_root["rf_cad_angular_deflection"] = ang_tol
        assembly_root["rf_cad_up_axis"] = self.up_axis
        assembly_root["rf_cad_unit_scale"] = self.unit_scale
        context.scene.rf_last_cad_filepath = filepath
        context.scene.rf_last_cad_collection = cad_coll.name

        if self.up_axis == 'Y_UP' and ext not in {'.glb', '.gltf', '.3dm'}:
            assembly_root.rotation_euler.x += math.radians(90.0)

        scale_map = {'MM_TO_M': 0.001, 'CM_TO_M': 0.01, 'INCH_TO_M': 0.0254, 'KEEP': 1.0}
        scale_factor = scale_map.get(self.unit_scale, 1.0)
        if ext == '.3dm' and self.unit_scale == 'MM_TO_M' and detected_scale and detected_scale > 0:
            scale_factor = detected_scale
        if scale_factor != 1.0:
            assembly_root.scale *= scale_factor

        context.view_layer.update()

        mesh_objs = [obj for obj in new_objs if obj.type == 'MESH']
        if self.auto_smooth_normals:
            for m_obj in mesh_objs:
                for poly in m_obj.data.polygons:
                    poly.use_smooth = True
                if not m_obj.data.has_custom_normals:
                    wn = m_obj.modifiers.new(name="RenderFlo_WeightedNormal", type='WEIGHTED_NORMAL')
                    wn.keep_sharp = True

        if mesh_objs and (self.center_xy or self.snap_to_ground):
            depsgraph = context.evaluated_depsgraph_get()
            min_x = min_y = min_z = float('inf')
            max_x = max_y = max_z = float('-inf')

            for m_obj in mesh_objs:
                eval_obj = m_obj.evaluated_get(depsgraph)
                for corner in eval_obj.bound_box:
                    world_pt = eval_obj.matrix_world @ Vector(corner)
                    min_x, max_x = min(min_x, world_pt.x), max(max_x, world_pt.x)
                    min_y, max_y = min(min_y, world_pt.y), max(max_y, world_pt.y)
                    min_z, max_z = min(min_z, world_pt.z), max(max_z, world_pt.z)

            offset = Vector((0.0, 0.0, 0.0))
            if self.center_xy:
                offset.x = -((min_x + max_x) * 0.5)
                offset.y = -((min_y + max_y) * 0.5)
            if self.snap_to_ground:
                offset.z = -min_z

            assembly_root.location += offset
            context.view_layer.update()

            from .studio_manager import ensure_light_target
            target = ensure_light_target(context)
            target.location = Vector((0.0, 0.0, (max_z - min_z) * 0.5 if self.snap_to_ground else (min_z + max_z) * 0.5))

        if ext == '.3dm' and warn_breps > 0:
            self.report({'WARNING'}, f"Imported '{base_name}', but {warn_breps} parts had no cached render meshes. Save in Shaded mode in Rhino or export as .STEP.")
        else:
            self.report({'INFO'}, f"ID RenderFlo: Imported '{base_name}' ({len(mesh_objs)} parts) into Model Set '{cad_coll.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_cad_hot_reload(bpy.types.Operator):
    bl_idname = "renderflo.cad_hot_reload"
    bl_label = "1-Click CAD Hot-Reload (Live Link)"
    bl_description = "Live-link reload updated CAD file from disk, replacing original geometry in-place while preserving all assigned CMF materials, transforms, and modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        filepath = scene.rf_last_cad_filepath

        assembly_obj = None
        if not filepath:
            for obj in context.selected_objects:
                if "rf_cad_source_path" in obj:
                    filepath = obj["rf_cad_source_path"]
                    assembly_obj = obj
                    break

        if not filepath or not os.path.exists(filepath):
            self.report({'WARNING'}, "No valid CAD source file found to reload. Import a CAD assembly first.")
            return {'CANCELLED'}

        base_name = os.path.splitext(os.path.basename(filepath))[0]
        coll_name = scene.rf_last_cad_collection or f"CAD_{base_name}"
        target_coll = bpy.data.collections.get(coll_name)

        if not target_coll:
            # Fallback search for CAD collection
            for coll in bpy.data.collections:
                if coll.name.startswith("CAD_") and base_name in coll.name:
                    target_coll = coll
                    break

        if not target_coll:
            self.report({'WARNING'}, f"CAD collection '{coll_name}' not found.")
            return {'CANCELLED'}

        # 1. Index existing objects and their assigned materials in target collection
        existing_objs = {obj.name: obj for obj in target_coll.objects if obj.type == 'MESH'}
        existing_by_base = {obj.name.split('.')[0]: obj for obj in target_coll.objects if obj.type == 'MESH'}
        assembly_root = next((o for o in target_coll.objects if o.type == 'EMPTY'), None)

        material_map = {}
        for obj in target_coll.objects:
            if obj.type == 'MESH':
                mats = [slot.material for slot in obj.material_slots if slot.material]
                material_map[obj.name] = mats
                material_map[obj.name.split('.')[0]] = mats

        # 2. Tessellation deflection tolerances
        lin_tol = 0.08
        ang_tol = 15.0
        if assembly_obj and "rf_cad_linear_deflection" in assembly_obj:
            lin_tol = assembly_obj["rf_cad_linear_deflection"]
            ang_tol = assembly_obj["rf_cad_angular_deflection"]

        ext = os.path.splitext(filepath)[1].lower()
        ang_rad = math.radians(ang_tol)
        before_objs = set(scene.objects)

        # Check required engine for selected extension before attempting reload
        if not is_engine_ready_for_ext(ext):
            engine_name = "OpenCASCADE (cascadio)" if ext in {'.step', '.stp', '.iges', '.igs'} else "Rhino3DM"
            self.report({'ERROR'}, f"{engine_name} engine is required to reload {ext} files. Please install the CAD engine.")
            bpy.ops.renderflo.install_cad_dialog(
                'INVOKE_DEFAULT',
                missing_reason=f"{engine_name} is required to reload {ext} files."
            )
            return {'CANCELLED'}

        # 3. Create temporary staging collection
        staging_coll = bpy.data.collections.new(f"_staging_reload_{uuid.uuid4().hex[:6]}")
        scene.collection.children.link(staging_coll)

        try:
            if ext in {'.step', '.stp', '.iges', '.igs'}:
                execute_universal_cad_import(context, filepath, lin_tol, ang_rad)
            elif ext == '.3dm':
                import_rhino_3dm(filepath, context)
            elif ext == '.stl':
                safe_import_stl(filepath)
            elif ext == '.obj':
                safe_import_obj(filepath)
            elif ext in {'.glb', '.gltf'}:
                bpy.ops.import_scene.gltf(filepath=filepath)
        except Exception as err:
            if staging_coll.name in scene.collection.children:
                scene.collection.children.unlink(staging_coll)
            bpy.data.collections.remove(staging_coll)
            err_str = str(err)
            if any(k in err_str for k in ("cascadio", "OpenCASCADE", "rhino3dm")):
                self.report({'ERROR'}, f"CAD engine missing: {err_str}")
                bpy.ops.renderflo.install_cad_dialog(
                    'INVOKE_DEFAULT',
                    missing_reason=err_str
                )
            else:
                self.report({'ERROR'}, f"Hot-reload failed: {err}")
            return {'CANCELLED'}

        new_objs = [o for o in scene.objects if o not in before_objs]
        if not new_objs:
            if staging_coll.name in scene.collection.children:
                scene.collection.children.unlink(staging_coll)
            bpy.data.collections.remove(staging_coll)
            self.report({'WARNING'}, "Reload produced no geometry.")
            return {'CANCELLED'}

        # Isolate new objects into staging collection
        for obj in new_objs:
            for c in list(obj.users_collection):
                c.objects.unlink(obj)
            staging_coll.objects.link(obj)

        # 4. In-Place Live Link Mesh Replacement
        updated_count = 0
        added_count = 0
        to_delete = []

        for n_obj in new_objs:
            if n_obj.type == 'MESH':
                # Match to existing object
                match_target = existing_objs.get(n_obj.name) or existing_by_base.get(n_obj.name.split('.')[0])

                if match_target:
                    # In-place swap of mesh data!
                    old_mesh = match_target.data
                    assigned_mats = material_map.get(match_target.name) or [slot.material for slot in match_target.material_slots if slot.material]

                    match_target.data = n_obj.data

                    # Re-attach preserved materials
                    match_target.data.materials.clear()
                    for m in assigned_mats:
                        if m:
                            match_target.data.materials.append(m)

                    for poly in match_target.data.polygons:
                        poly.use_smooth = True

                    if not match_target.data.has_custom_normals:
                        if not match_target.modifiers.get("RenderFlo_WeightedNormal"):
                            wn = match_target.modifiers.new(name="RenderFlo_WeightedNormal", type='WEIGHTED_NORMAL')
                            wn.keep_sharp = True

                    if old_mesh.users == 0:
                        try:
                            bpy.data.meshes.remove(old_mesh)
                        except Exception:
                            pass

                    to_delete.append(n_obj)
                    updated_count += 1
                else:
                    # Brand new part added in CAD: move into target collection
                    staging_coll.objects.unlink(n_obj)
                    target_coll.objects.link(n_obj)
                    if assembly_root:
                        n_obj.parent = assembly_root
                    added_count += 1
            else:
                to_delete.append(n_obj)

        # Clean up staging objects and staging collection
        for o in to_delete:
            try:
                bpy.data.objects.remove(o, do_unlink=True)
            except Exception:
                pass

        if staging_coll.name in scene.collection.children:
            scene.collection.children.unlink(staging_coll)
        try:
            bpy.data.collections.remove(staging_coll)
        except Exception:
            pass

        context.view_layer.update()
        self.report({'INFO'}, f"ID RenderFlo Live-Link: Reloaded '{base_name}' ({updated_count} parts updated in-place, {added_count} new parts added, all CMF materials preserved)")
        return {'FINISHED'}

class RENDERFLO_OT_export_cad(bpy.types.Operator, ExportHelper):
    bl_idname = "renderflo.export_cad"
    bl_label = "Export CAD Assembly"
    bl_description = "Export product CAD assembly to STL, OBJ, glTF/GLB, FBX, USD, PLY, Alembic, or Collada"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ""

    export_format: bpy.props.EnumProperty(
        name="Format",
        description="CAD and 3D manufacturing exchange format",
        items=[
            ('STL', "STL (.stl) - 3D Printing / Prototyping", "Stereolithography for rapid prototyping and additive manufacturing", 'MESH_DATA', 0),
            ('OBJ', "Wavefront OBJ (.obj) - Industrial Mesh", "Polygonal geometry with materials, UVs and normals", 'OBJECT_DATAMODE', 1),
            ('GLTF', "glTF 2.0 / GLB (.glb) - Web / AR", "Khronos glTF / GLB for interactive Web 3D and AR viewers", 'WORLD', 2),
            ('FBX', "Autodesk FBX (.fbx) - Cross-DCC / CAD", "Autodesk FilmBox format for CAD / DCC interoperability", 'OUTLINER_OB_MESH', 3),
            ('USD', "Universal Scene Description (.usd) - Omniverse / AR", "OpenUSD for Pixar, Apple Vision Pro, and NVIDIA Omniverse", 'SCENE_DATA', 4),
            ('PLY', "Stanford PLY (.ply) - Metrology / Scans", "Polygon file format for scan data and metrology inspection", 'POINTCLOUD_DATA', 5),
            ('ABC', "Alembic (.abc) - Production Cache", "High-performance geometry cache for production pipelines", 'FILE_CACHE', 6),
            ('DAE', "Collada (.dae) - Digital Asset Exchange", "XML-based digital asset exchange", 'FILE_FOLDER', 7),
        ],
        default='STL'
    )

    export_scope: bpy.props.EnumProperty(
        name="Scope",
        description="Which scene objects to export",
        items=[
            ('ASSEMBLY', "Product Assembly (Auto-filter)", "Export only product components, automatically excluding floor, backdrop, lights, and cameras"),
            ('SELECTED', "Selected Objects Only", "Export only currently selected objects in the 3D Viewport"),
            ('ALL', "Entire Scene", "Export all visible objects in the scene"),
        ],
        default='ASSEMBLY'
    )

    apply_modifiers: bpy.props.BoolProperty(
        name="Apply Modifiers",
        description="Bake non-destructive modifiers (weighted normals, bevels, booleans, lattice deformers) into exported mesh",
        default=True
    )

    export_materials: bpy.props.BoolProperty(
        name="Export Materials / Textures",
        description="Include material assignments, PBR textures, and color definitions",
        default=True
    )

    unit_scale: bpy.props.FloatProperty(
        name="Scale Factor",
        description="Geometry scale multiplier on export (1.0 = scene units)",
        default=1.0,
        min=0.0001,
        max=1000.0
    )

    def check(self, context):
        ext_map = {
            'STL': ".stl",
            'OBJ': ".obj",
            'GLTF': ".glb",
            'FBX': ".fbx",
            'USD': ".usd",
            'PLY': ".ply",
            'ABC': ".abc",
            'DAE': ".dae",
        }
        target_ext = ext_map.get(self.export_format, ".stl")
        base, ext = os.path.splitext(self.filepath)
        if ext.lower() != target_ext:
            self.filepath = base + target_ext
            return True
        return False

    def invoke(self, context, event):
        scene = context.scene
        ext_map = {
            'STL': ".stl",
            'OBJ': ".obj",
            'GLTF': ".glb",
            'FBX': ".fbx",
            'USD': ".usd",
            'PLY': ".ply",
            'ABC': ".abc",
            'DAE': ".dae",
        }
        target_ext = ext_map.get(self.export_format, ".stl")
        if scene.rf_last_cad_filepath:
            base_name = os.path.splitext(os.path.basename(scene.rf_last_cad_filepath))[0]
            self.filepath = f"{base_name}_Export{target_ext}"
        else:
            self.filepath = f"Product_Assembly{target_ext}"
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Export Format & Scope:", icon='EXPORT')
        box.prop(self, "export_format")
        box.prop(self, "export_scope")

        opt_box = layout.box()
        opt_box.label(text="Geometry & Scale:", icon='MODIFIER')
        opt_box.prop(self, "apply_modifiers")
        opt_box.prop(self, "unit_scale")
        if self.export_format in {'OBJ', 'GLTF', 'USD', 'FBX'}:
            opt_box.prop(self, "export_materials")

    def execute(self, context):
        scene = context.scene
        filepath = bpy.path.abspath(self.filepath)
        export_dir = os.path.dirname(filepath)
        if export_dir and not os.path.exists(export_dir):
            os.makedirs(export_dir, exist_ok=True)

        orig_selected = [o for o in context.selected_objects]
        orig_active = context.active_object

        assembly_objs = []
        if self.export_scope == 'ASSEMBLY':
            for obj in scene.objects:
                if obj.type not in {'MESH', 'CURVE', 'SURFACE', 'FONT'}:
                    continue
                if obj.name in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME, TARGET_EMPTY_NAME}:
                    continue
                if obj.name.startswith("RF_") or obj.name.startswith("RenderFlo_"):
                    continue
                if "Shadow_Floor" in obj.name or "Cutaway_Cutter" in obj.name or "Pin_" in obj.name or "Softbox_" in obj.name:
                    continue
                assembly_objs.append(obj)

            if not assembly_objs:
                assembly_objs = [o for o in scene.objects if o.type in {'MESH', 'CURVE'} and o.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}]

            for o in scene.objects:
                o.select_set(False)
            for o in assembly_objs:
                o.select_set(True)
            if assembly_objs:
                context.view_layer.objects.active = assembly_objs[0]

        fmt = self.export_format
        use_sel = (self.export_scope != 'ALL')

        try:
            if fmt == 'STL':
                if hasattr(bpy.ops.wm, "stl_export"):
                    bpy.ops.wm.stl_export(
                        filepath=filepath,
                        export_selected_objects=use_sel,
                        apply_modifiers=self.apply_modifiers,
                        global_scale=self.unit_scale
                    )
                elif hasattr(bpy.ops.export_mesh, "stl"):
                    bpy.ops.export_mesh.stl(
                        filepath=filepath,
                        use_selection=use_sel,
                        use_mesh_modifiers=self.apply_modifiers,
                        global_scale=self.unit_scale
                    )
            elif fmt == 'OBJ':
                if hasattr(bpy.ops.wm, "obj_export"):
                    bpy.ops.wm.obj_export(
                        filepath=filepath,
                        export_selected_objects=use_sel,
                        apply_modifiers=self.apply_modifiers,
                        global_scale=self.unit_scale,
                        export_materials=self.export_materials
                    )
                elif hasattr(bpy.ops.export_scene, "obj"):
                    bpy.ops.export_scene.obj(
                        filepath=filepath,
                        use_selection=use_sel,
                        use_mesh_modifiers=self.apply_modifiers,
                        global_scale=self.unit_scale,
                        use_materials=self.export_materials
                    )
            elif fmt == 'GLTF':
                ext = os.path.splitext(filepath)[1].lower()
                gl_fmt = 'GLB' if ext == '.glb' else 'GLTF_EMBEDDED'
                if hasattr(bpy.ops.export_scene, "gltf"):
                    bpy.ops.export_scene.gltf(
                        filepath=filepath,
                        export_format=gl_fmt,
                        use_selection=use_sel,
                        export_apply=self.apply_modifiers,
                        export_materials='EXPORT' if self.export_materials else 'NONE',
                        export_lights=False,
                        export_cameras=False
                    )
            elif fmt == 'FBX':
                if hasattr(bpy.ops.export_scene, "fbx"):
                    bpy.ops.export_scene.fbx(
                        filepath=filepath,
                        use_selection=use_sel,
                        use_mesh_modifiers=self.apply_modifiers,
                        global_scale=self.unit_scale
                    )
            elif fmt == 'USD':
                if hasattr(bpy.ops.wm, "usd_export"):
                    bpy.ops.wm.usd_export(
                        filepath=filepath,
                        selected_objects_only=use_sel,
                        export_materials=self.export_materials,
                        export_lights=False,
                        export_cameras=False
                    )
            elif fmt == 'PLY':
                if hasattr(bpy.ops.wm, "ply_export"):
                    bpy.ops.wm.ply_export(
                        filepath=filepath,
                        export_selected_objects=use_sel,
                        apply_modifiers=self.apply_modifiers,
                        global_scale=self.unit_scale
                    )
                elif hasattr(bpy.ops.export_mesh, "ply"):
                    bpy.ops.export_mesh.ply(
                        filepath=filepath,
                        use_selection=use_sel,
                        use_mesh_modifiers=self.apply_modifiers,
                        global_scale=self.unit_scale
                    )
            elif fmt == 'ABC':
                if hasattr(bpy.ops.wm, "alembic_export"):
                    bpy.ops.wm.alembic_export(
                        filepath=filepath,
                        selected=use_sel,
                        apply_subdiv=self.apply_modifiers
                    )
            elif fmt == 'DAE':
                if hasattr(bpy.ops.wm, "collada_export"):
                    bpy.ops.wm.collada_export(
                        filepath=filepath,
                        selected=use_sel,
                        apply_modifiers=self.apply_modifiers
                    )
            else:
                self.report({'ERROR'}, f"Unsupported format: {fmt}")
                return {'CANCELLED'}

            self.report({'INFO'}, f"Exported CAD ({fmt}): {os.path.basename(filepath)}")
            return {'FINISHED'}

        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {e}")
            return {'CANCELLED'}

        finally:
            if self.export_scope == 'ASSEMBLY':
                for o in scene.objects:
                    o.select_set(False)
                for o in orig_selected:
                    try:
                        o.select_set(True)
                    except Exception:
                        pass
                if orig_active:
                    try:
                        context.view_layer.objects.active = orig_active
                    except Exception:
                        pass


# ------------------------------------------------------------------------
# CNC Router Outline, Stock Blocker & DXF Engine
# ------------------------------------------------------------------------

def offset_polygon_2d(poly_pts, offset):
    """Offset a closed 2D polygon outward by a specified margin in mm/units."""
    n = len(poly_pts)
    if n < 3 or abs(offset) < 1e-5:
        return [Vector(p) for p in poly_pts]

    # Ensure CCW planar orientation
    area = sum((poly_pts[(i + 1) % n].x - poly_pts[i].x) * (poly_pts[(i + 1) % n].y + poly_pts[i].y) for i in range(n))
    if area > 0:
        poly_pts = list(reversed(poly_pts))

    out_pts = []
    for i in range(n):
        p_prev = poly_pts[(i - 1) % n]
        p_curr = poly_pts[i]
        p_next = poly_pts[(i + 1) % n]

        d1 = (p_curr - p_prev).normalized()
        d2 = (p_next - p_curr).normalized()

        # Outward normal for CCW winding
        n1 = Vector((d1.y, -d1.x))
        n2 = Vector((d2.y, -d2.x))

        bisector = (n1 + n2)
        if bisector.length > 1e-4:
            bisector = bisector.normalized()
            dot = bisector.dot(n1)
            scale = offset / max(dot, 0.2)
            out_pts.append(p_curr + bisector * scale)
        else:
            out_pts.append(p_curr + n1 * offset)

    return out_pts


def write_dxf_polyline_2d(filepath, pts_2d, layer_name="ROUTER_OUTLINE"):
    """Write standard AutoCAD DXF R12 ASCII file for CNC router CAM software."""
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("0\nSECTION\n2\nHEADER\n0\nENDSEC\n")
        f.write("0\nSECTION\n2\nTABLES\n0\nENDSEC\n")
        f.write("0\nSECTION\n2\nBLOCKS\n0\nENDSEC\n")
        f.write("0\nSECTION\n2\nENTITIES\n")
        f.write(f"0\nPOLYLINE\n8\n{layer_name}\n66\n1\n70\n1\n")
        for p in pts_2d:
            f.write(f"0\nVERTEX\n8\n{layer_name}\n10\n{p.x:.4f}\n20\n{p.y:.4f}\n30\n0.0\n")
        f.write(f"0\nSEQEND\n8\n{layer_name}\n")
        f.write("0\nENDSEC\n0\nEOF\n")


def create_stock_block_mesh(pts_2d, min_z, max_z, name="Product_Stock_Block"):
    """Generate 3D solid billet mesh representing the raw physical material block."""
    n = len(pts_2d)
    verts = [Vector((p.x, p.y, min_z)) for p in pts_2d] + [Vector((p.x, p.y, max_z)) for p in pts_2d]
    faces = [list(reversed(range(n))), list(range(n, 2 * n))]
    for i in range(n):
        nxt = (i + 1) % n
        faces.append([i, nxt, nxt + n, i + n])
    mesh = bpy.data.meshes.new(f"{name}_Mesh")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    obj.display_type = 'WIRE'
    return obj


class RENDERFLO_OT_generate_router_outline(bpy.types.Operator):
    bl_idname = "renderflo.generate_router_outline"
    bl_label = "Generate Router Outline Curve"
    bl_description = "Generate 2D perimeter outline curve and 3D stock billet from product geometry for CNC router blanking & rough cuts"
    bl_options = {'REGISTER', 'UNDO'}

    outline_mode: bpy.props.EnumProperty(
        name="Outline Mode",
        description="Method used to calculate the 2D router blanking outline",
        items=[
            ('CONVEX_HULL', "Convex Stock Blank (Vice / Fixture Outline)", "Best for blocking square/convex stock on a CNC router or bandsaw"),
            ('SLICE_CONTOUR', "Cross-Section Slice (Parting Line / Z-Level)", "Exact cross-section slice contour at specified Z plane"),
            ('BOUNDING_BOX', "Rectangular Stock Blank (Billet Footprint)", "Aligned minimum rectangular bounding outline"),
        ],
        default='CONVEX_HULL'
    )

    margin_mm: bpy.props.FloatProperty(
        name="Stock Margin (Offset)",
        description="Extra stock clearance offset around the product outline for safe roughing cuts",
        default=5.0,
        min=0.0,
        max=500.0,
        unit='LENGTH'
    )

    z_plane: bpy.props.EnumProperty(
        name="Z Placement",
        description="Vertical plane position for the 2D curve",
        items=[
            ('BED', "Router Bed (Z = 0)", "Directly on spoilboard / table"),
            ('BOTTOM', "Part Bottom (Z = min)", "At lowest part surface"),
            ('CENTER', "Parting Line / Midplane (Z = center)", "Middle split plane"),
            ('TOP', "Part Top (Z = max)", "At top stock reference surface"),
            ('CUSTOM', "Custom Z Height", "Specify arbitrary Z level"),
        ],
        default='BED'
    )

    custom_z: bpy.props.FloatProperty(
        name="Custom Z",
        description="User-specified Z level for outline placement",
        default=0.0,
        unit='LENGTH'
    )

    curve_type: bpy.props.EnumProperty(
        name="Curve Interpolation",
        items=[
            ('POLY', "Polyline (CNC / G-Code Native)", "Exact linear segments preferred by 2D CNC routers"),
            ('BEZIER', "Bézier Spline (Smooth Curvature)", "Continuous smooth curvature"),
        ],
        default='POLY'
    )

    create_stock_block: bpy.props.BoolProperty(
        name="Extrude 3D Stock Block",
        description="Generate a 3D translucent stock billet mesh representing the raw material blank for CNC roughing",
        default=True
    )

    stock_top_allowance: bpy.props.FloatProperty(
        name="Top Face Allowance",
        description="Additional stock on top of part for surface facing pass",
        default=2.0,
        min=0.0,
        max=100.0,
        unit='LENGTH'
    )

    stock_bottom_allowance: bpy.props.FloatProperty(
        name="Bottom Spoil Allowance",
        description="Additional stock below part for spoilboard clearance",
        default=2.0,
        min=0.0,
        max=100.0,
        unit='LENGTH'
    )

    export_dxf: bpy.props.BoolProperty(
        name="Export 2D DXF",
        description="Automatically save a .DXF file for direct loading into CNC CAM software (Vectric, Fusion CAM, Carbide Create, LightBurn)",
        default=False
    )

    dxf_filepath: bpy.props.StringProperty(
        name="DXF Path",
        subtype='FILE_PATH',
        default="//Product_Router_Blank.dxf"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="CNC Roughing & Blanking Outline:", icon='CURVE_DATA')
        box.prop(self, "outline_mode")
        box.prop(self, "margin_mm", text="Stock Margin (mm)")

        z_box = layout.box()
        z_box.label(text="Z Placement & Level:", icon='AXIS_TOP')
        z_box.prop(self, "z_plane")
        if self.z_plane == 'CUSTOM':
            z_box.prop(self, "custom_z")
        z_box.prop(self, "curve_type")

        stk_box = layout.box()
        stk_box.label(text="3D Stock Simulation:", icon='MESH_CUBE')
        stk_box.prop(self, "create_stock_block")
        if self.create_stock_block:
            row = stk_box.row(align=True)
            row.prop(self, "stock_top_allowance", text="Top (mm)")
            row.prop(self, "stock_bottom_allowance", text="Bottom (mm)")

        dxf_box = layout.box()
        dxf_box.label(text="CNC CAM Export:", icon='EXPORT')
        dxf_box.prop(self, "export_dxf")
        if self.export_dxf:
            dxf_box.prop(self, "dxf_filepath", text="Path")

    def execute(self, context):
        scene = context.scene
        targets = [o for o in context.selected_objects if o.type == 'MESH']
        if not targets:
            targets = [
                o for o in scene.objects
                if o.type == 'MESH'
                and o.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME, TARGET_EMPTY_NAME}
                and not o.name.startswith(('RF_', 'RenderFlo_'))
                and "Shadow_Floor" not in o.name
                and "Cutaway_Cutter" not in o.name
                and "Stock_Block" not in o.name
                and "Router_Outline" not in o.name
            ]

        if not targets:
            self.report({'WARNING'}, "No product mesh objects found to outline.")
            return {'CANCELLED'}

        import mathutils.geometry as mg

        world_verts = []
        for o in targets:
            mat = o.matrix_world
            for v in o.data.vertices:
                world_verts.append(mat @ v.co)

        if not world_verts:
            self.report({'WARNING'}, "Selected objects contain no vertices.")
            return {'CANCELLED'}

        min_x = min(v.x for v in world_verts)
        max_x = max(v.x for v in world_verts)
        min_y = min(v.y for v in world_verts)
        max_y = max(v.y for v in world_verts)
        min_z = min(v.z for v in world_verts)
        max_z = max(v.z for v in world_verts)
        center_z = (min_z + max_z) * 0.5

        if self.z_plane == 'BED':
            target_z = 0.0
        elif self.z_plane == 'BOTTOM':
            target_z = min_z
        elif self.z_plane == 'CENTER':
            target_z = center_z
        elif self.z_plane == 'TOP':
            target_z = max_z
        else:
            target_z = self.custom_z

        poly = []
        if self.outline_mode == 'CONVEX_HULL':
            pts_2d = [Vector((v.x, v.y)) for v in world_verts]
            hull_indices = mg.convex_hull_2d(pts_2d)
            poly = [pts_2d[i] for i in hull_indices]
        elif self.outline_mode == 'BOUNDING_BOX':
            poly = [
                Vector((min_x, min_y)),
                Vector((max_x, min_y)),
                Vector((max_x, max_y)),
                Vector((min_x, max_y))
            ]
        elif self.outline_mode == 'SLICE_CONTOUR':
            import bmesh
            bm = bmesh.new()
            for o in targets:
                temp_bm = bmesh.new()
                temp_bm.from_mesh(o.data)
                bmesh.ops.transform(temp_bm, matrix=o.matrix_world, verts=temp_bm.verts)
                temp_mesh = bpy.data.meshes.new("_temp_slice")
                temp_bm.to_mesh(temp_mesh)
                temp_bm.free()
                bm.from_mesh(temp_mesh)
                bpy.data.meshes.remove(temp_mesh)

            res = bmesh.ops.bisect_plane(
                bm,
                geom=bm.verts[:] + bm.edges[:] + bm.faces[:],
                plane_co=(0, 0, target_z),
                plane_no=(0, 0, 1)
            )
            cut_edges = [g for g in res['geom_cut'] if isinstance(g, bmesh.types.BMEdge)]
            if cut_edges:
                adj = {}
                for e in cut_edges:
                    v1, v2 = e.verts[0], e.verts[1]
                    adj.setdefault(v1, []).append(v2)
                    adj.setdefault(v2, []).append(v1)

                visited = set()
                loops = []
                for start_v in adj:
                    if start_v in visited:
                        continue
                    loop = [start_v]
                    visited.add(start_v)
                    curr = start_v
                    while True:
                        nxt = None
                        for neighbor in adj.get(curr, []):
                            if neighbor not in visited:
                                nxt = neighbor
                                break
                        if nxt is not None:
                            visited.add(nxt)
                            loop.append(nxt)
                            curr = nxt
                        else:
                            break
                    if len(loop) >= 3:
                        loops.append(loop)

                if loops:
                    best_loop = max(loops, key=lambda lp: (max(v.co.x for v in lp) - min(v.co.x for v in lp)) * (max(v.co.y for v in lp) - min(v.co.y for v in lp)))
                    poly = [Vector((v.co.x, v.co.y)) for v in best_loop]
            bm.free()

            if not poly:
                pts_2d = [Vector((v.x, v.y)) for v in world_verts]
                hull_indices = mg.convex_hull_2d(pts_2d)
                poly = [pts_2d[i] for i in hull_indices]

        # Stock margin unit scaling
        if (max_x - min_x) < 5.0 and self.margin_mm > 0.5:
            margin_val = self.margin_mm * 0.001
        else:
            margin_val = self.margin_mm

        expanded_pts = offset_polygon_2d(poly, margin_val)

        # Create Curve Object
        base_name = targets[0].name.split('.')[0]
        curve_name = f"{base_name}_Router_Outline"
        curve_data = bpy.data.curves.new(curve_name, type='CURVE')
        curve_data.dimensions = '2D'

        spline = curve_data.splines.new(self.curve_type)
        if self.curve_type == 'BEZIER':
            spline.bezier_points.add(len(expanded_pts) - 1)
            for i, p in enumerate(expanded_pts):
                bp = spline.bezier_points[i]
                bp.co = (p.x, p.y, target_z)
                bp.handle_left_type = 'AUTO'
                bp.handle_right_type = 'AUTO'
        else:
            spline.points.add(len(expanded_pts) - 1)
            for i, p in enumerate(expanded_pts):
                spline.points[i].co = (p.x, p.y, target_z, 1.0)

        spline.use_cyclic_u = True
        curve_obj = bpy.data.objects.new(curve_name, curve_data)
        context.scene.collection.objects.link(curve_obj)

        # Create 3D Stock Block
        if self.create_stock_block:
            top_allowance = self.stock_top_allowance * 0.001 if (max_x - min_x) < 5.0 and self.stock_top_allowance > 0.5 else self.stock_top_allowance
            btm_allowance = self.stock_bottom_allowance * 0.001 if (max_x - min_x) < 5.0 and self.stock_bottom_allowance > 0.5 else self.stock_bottom_allowance
            block_min_z = min_z - btm_allowance
            block_max_z = max_z + top_allowance
            block_obj = create_stock_block_mesh(expanded_pts, block_min_z, block_max_z, name=f"{base_name}_Stock_Billet")
            context.scene.collection.objects.link(block_obj)

        # Export DXF
        if self.export_dxf:
            dxf_path = bpy.path.abspath(self.dxf_filepath)
            write_dxf_polyline_2d(dxf_path, expanded_pts, layer_name=base_name)
            self.report({'INFO'}, f"Saved CNC Router Outline DXF: {os.path.basename(dxf_path)}")

        for o in context.scene.objects:
            o.select_set(False)
        curve_obj.select_set(True)
        context.view_layer.objects.active = curve_obj

        dim_x = max(p.x for p in expanded_pts) - min(p.x for p in expanded_pts)
        dim_y = max(p.y for p in expanded_pts) - min(p.y for p in expanded_pts)
        self.report({'INFO'}, f"Created Router Outline '{curve_obj.name}' ({len(expanded_pts)} pts, Blank Size: {dim_x:.1f} x {dim_y:.1f})")
        return {'FINISHED'}


class RENDERFLO_OT_export_router_dxf(bpy.types.Operator, ExportHelper):
    bl_idname = "renderflo.export_router_dxf"
    bl_label = "Export 2D Router Outline (DXF)"
    bl_description = "Export 2D curve outline to DXF for CNC router CAM software (Vectric, Fusion CAM, Carbide Create, LightBurn)"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".dxf"
    filter_glob: bpy.props.StringProperty(default="*.dxf", options={'HIDDEN'})

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type not in {'CURVE', 'MESH'}:
            obj = next((o for o in context.scene.objects if "Router_Outline" in o.name and o.type == 'CURVE'), None)

        if not obj:
            self.report({'WARNING'}, "Please select or generate a Router Outline curve first.")
            return {'CANCELLED'}

        pts_2d = []
        if obj.type == 'CURVE':
            for spl in obj.data.splines:
                if spl.type == 'BEZIER':
                    for bp in spl.bezier_points:
                        w_co = obj.matrix_world @ bp.co
                        pts_2d.append(Vector((w_co.x, w_co.y)))
                else:
                    for p in spl.points:
                        w_co = obj.matrix_world @ Vector((p.co[0], p.co[1], p.co[2]))
                        pts_2d.append(Vector((w_co.x, w_co.y)))
        elif obj.type == 'MESH':
            for v in obj.data.vertices:
                w_co = obj.matrix_world @ v.co
                pts_2d.append(Vector((w_co.x, w_co.y)))

        if len(pts_2d) < 3:
            self.report({'WARNING'}, "Not enough points in object to export 2D DXF.")
            return {'CANCELLED'}

        filepath = bpy.path.abspath(self.filepath)
        write_dxf_polyline_2d(filepath, pts_2d, layer_name=obj.name)
        self.report({'INFO'}, f"Exported CNC Router DXF: {os.path.basename(filepath)}")
        return {'FINISHED'}


def menu_func_import_cad(self, context):
    self.layout.operator(RENDERFLO_OT_import_cad.bl_idname, text="CAD Assembly (.step, .stp, .3dm) [ID RenderFlo]")



cad_classes = (
    RENDERFLO_OT_bootstrap_cad_kernel,
    RENDERFLO_OT_recheck_cad_engine,
    RENDERFLO_OT_install_cad_dialog,
    RENDERFLO_OT_browse_cad_wheel,
    RENDERFLO_OT_import_cad,
    RENDERFLO_OT_cad_hot_reload,
    RENDERFLO_OT_export_cad,
    RENDERFLO_OT_generate_router_outline,
    RENDERFLO_OT_export_router_dxf,
)


def register():
    for cls in cad_classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import_cad)
    try:
        refresh_engine_status()
    except Exception:
        pass


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import_cad)
    for cls in reversed(cad_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
