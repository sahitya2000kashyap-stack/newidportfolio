# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.3.0 — Studio Manager & Staging Engine.
Multi-Studio snapshots, Camera Framing & Aspect Ratios, Live Auto-Save,
Studio Lock, and Floor/Backdrop Staging.
"""

import bpy
import math
from mathutils import Vector

from ..state import (
    MASTER_LIGHT_COLL,
    MASTER_CAM_COLL,
    MASTER_CUTAWAY_COLL,
    TARGET_EMPTY_NAME,
    GROUND_PLANE_NAME,
    BACKDROP_OBJ_NAME,
    DOME_VISUALIZER_OBJ,
    DOME_PIN_PREFIX,
    CUTAWAY_BOX_NAME,
    ASPECT_PRESETS,
    is_internal_update,
    internal_update_guard,
)


# ------------------------------------------------------------------------
# Studio Scene Collections & Cameras
# ------------------------------------------------------------------------

def ensure_collection(scene, coll_name):
    coll = bpy.data.collections.get(coll_name)
    if not coll:
        coll = bpy.data.collections.new(coll_name)
        scene.collection.children.link(coll)
    elif coll.name not in scene.collection.children:
        try:
            scene.collection.children.link(coll)
        except Exception:
            pass
    return coll


def ensure_studio_light_collection(context, studio):
    master_coll = ensure_collection(context.scene, MASTER_LIGHT_COLL)
    if studio.light_collection_name:
        sub_coll = bpy.data.collections.get(studio.light_collection_name)
        if sub_coll:
            return sub_coll

    coll_name = f"Lights_{studio.name}"
    sub_coll = bpy.data.collections.get(coll_name)
    if not sub_coll:
        sub_coll = bpy.data.collections.new(coll_name)
    if sub_coll.name not in master_coll.children:
        try:
            master_coll.children.link(sub_coll)
        except Exception:
            pass
    studio.light_collection_name = sub_coll.name
    return sub_coll


def create_camera_for_studio(context, studio_name, match_viewport=True):
    scene = context.scene
    cam_coll = ensure_collection(scene, MASTER_CAM_COLL)

    cam_data = bpy.data.cameras.new(name=f"Cam_{studio_name}")
    cam_data.lens = 85.0
    cam_data.passepartout_alpha = 0.85

    cam_obj = bpy.data.objects.new(name=f"Cam_{studio_name}", object_data=cam_data)
    cam_coll.objects.link(cam_obj)

    placed = False
    if scene.camera and not match_viewport:
        cam_obj.matrix_world = scene.camera.matrix_world.copy()
        if scene.camera.data and hasattr(scene.camera.data, "lens"):
            cam_data.lens = scene.camera.data.lens
        placed = True

    if not placed and context.screen:
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D' and space.region_3d:
                        cam_obj.matrix_world = space.region_3d.view_matrix.inverted()
                        placed = True
                        break
                if placed:
                    break

    if not placed:
        cam_obj.location = (0.0, -3.5, 1.5)
        cam_obj.rotation_euler = (math.radians(70.0), 0.0, 0.0)

    scene.camera = cam_obj
    return cam_obj


def ensure_light_target(context):
    target = bpy.data.objects.get(TARGET_EMPTY_NAME)
    if not target:
        target = bpy.data.objects.new(TARGET_EMPTY_NAME, None)
        target.empty_display_type = 'SPHERE'
        target.empty_display_size = 0.25
        target.location = (0.0, 0.0, 0.0)
        master_coll = ensure_collection(context.scene, MASTER_LIGHT_COLL)
        master_coll.objects.link(target)
    return target


def switch_exclusive_studio_lights(context, active_studio):
    scene = context.scene
    active_coll_name = active_studio.light_collection_name
    for s in scene.rf_studios:
        if s.light_collection_name:
            coll = bpy.data.collections.get(s.light_collection_name)
            if coll:
                is_current = (coll.name == active_coll_name)
                coll.hide_viewport = not is_current
                coll.hide_render = not is_current


# ------------------------------------------------------------------------
# Aspect Ratio & Framing Logic
# ------------------------------------------------------------------------

def update_studio_aspect_ratio(self, context):
    if is_internal_update():
        return
    with internal_update_guard():
        if self.aspect_preset != 'CUSTOM':
            for code, _, _, w, h in ASPECT_PRESETS:
                if code == self.aspect_preset:
                    base = self.base_resolution
                    if w >= h:
                        self.res_x = base
                        self.res_y = int(round(base * (h / w)))
                    else:
                        self.res_y = base
                        self.res_x = int(round(base * (w / h)))
                    break

        if context and context.scene:
            scene = context.scene
            if 0 <= scene.rf_studio_index < len(scene.rf_studios):
                if scene.rf_studios[scene.rf_studio_index] == self and self.use_resolution:
                    scene.render.resolution_x = self.res_x
                    scene.render.resolution_y = self.res_y
                    scene.render.resolution_percentage = self.res_scale
                    if scene.camera and scene.camera.data:
                        scene.camera.data.sensor_fit = 'VERTICAL' if (self.res_y > self.res_x) else 'HORIZONTAL'


def on_studio_camera_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    if self.camera_obj and self.camera_obj.type == 'CAMERA':
        context.scene.camera = self.camera_obj


# ------------------------------------------------------------------------
# Standard CAD Camera View Directions & Alignment Engine
# ------------------------------------------------------------------------

STANDARD_VIEW_DIRECTIONS = {
    'FRONT': (Vector((0.0, -1.0, 0.0)), (math.radians(90.0), 0.0, 0.0)),
    'BACK': (Vector((0.0, 1.0, 0.0)), (math.radians(90.0), 0.0, math.radians(180.0))),
    'LEFT': (Vector((-1.0, 0.0, 0.0)), (math.radians(90.0), 0.0, math.radians(-90.0))),
    'RIGHT': (Vector((1.0, 0.0, 0.0)), (math.radians(90.0), 0.0, math.radians(90.0))),
    'TOP': (Vector((0.0, 0.0, 1.0)), (0.0, 0.0, 0.0)),
    'BOTTOM': (Vector((0.0, 0.0, -1.0)), (math.radians(180.0), 0.0, 0.0)),
    'ISO': (Vector((-0.57735, -0.57735, 0.57735)), (math.radians(54.736), 0.0, math.radians(-45.0))),
}


def get_scene_target_and_distance(scene, cam_obj=None):
    target = bpy.data.objects.get(TARGET_EMPTY_NAME)
    center = target.matrix_world.translation.copy() if target else None

    min_c = [float('inf')] * 3
    max_c = [float('-inf')] * 3
    count = 0

    for obj in scene.objects:
        if obj.type not in {'MESH', 'CURVE', 'SURFACE'}:
            continue
        name_l = obj.name.lower()
        if "shadow" in name_l or "floor" in name_l or "backdrop" in name_l or "orb" in name_l:
            continue
        if obj.hide_viewport or obj.hide_render or obj.hide_get():
            continue
        for corner in obj.bound_box:
            w_pt = obj.matrix_world @ Vector(corner)
            for i in range(3):
                min_c[i] = min(min_c[i], w_pt[i])
                max_c[i] = max(max_c[i], w_pt[i])
        count += 1

    if count > 0:
        bbox_center = Vector([(min_c[i] + max_c[i]) * 0.5 for i in range(3)])
        bbox_size = max(max_c[i] - min_c[i] for i in range(3))
        if center is None:
            center = bbox_center
    else:
        bbox_center = Vector((0.0, 0.0, 0.0))
        bbox_size = 2.0
        if center is None:
            center = bbox_center

    if cam_obj:
        cur_dist = (cam_obj.location - center).length
        if cur_dist > 0.05:
            dist = cur_dist
        else:
            dist = max(1.8, bbox_size * 2.2)
    else:
        dist = max(1.8, bbox_size * 2.2)

    return center, dist


def apply_standard_camera_view(studio, context, view_name):
    if view_name not in STANDARD_VIEW_DIRECTIONS:
        return False
    scene = context.scene

    if not studio.camera_obj or studio.camera_obj.type != 'CAMERA':
        studio.camera_obj = create_camera_for_studio(context, studio.name, match_viewport=False)

    cam_obj = studio.camera_obj
    center, dist = get_scene_target_and_distance(scene, cam_obj)
    pos_dir, rot_euler = STANDARD_VIEW_DIRECTIONS[view_name]

    cam_obj.location = center + pos_dir * dist
    cam_obj.rotation_euler = rot_euler
    scene.camera = cam_obj

    try:
        context.view_layer.update()
    except Exception:
        pass

    if getattr(scene, "rf_auto_save_studios", True):
        capture_studio_state(context, studio)

    return True


def on_studio_image_style_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    if self.use_image_style:
        apply_image_style_to_scene(context.scene, self)


def apply_image_style_to_scene(scene, studio):
    scene.view_settings.exposure = studio.exposure
    if hasattr(studio, "contrast") and hasattr(scene.view_settings, "look"):
        try:
            scene.view_settings.look = studio.contrast
        except Exception:
            pass
    scene.render.film_transparent = studio.film_transparent
    if studio.film_transparent:
        scene.render.image_settings.file_format = 'PNG'
        scene.render.image_settings.color_mode = 'RGBA'


def on_studio_bloom_update(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    scene = context.scene
    if 0 <= scene.rf_studio_index < len(scene.rf_studios) and scene.rf_studios[scene.rf_studio_index] == self:
        apply_bloom_to_scene(scene, self)


def apply_bloom_to_scene(scene, studio):
    """Configures the Blender Compositor Glare node for this studio's bloom/glow settings."""
    if not hasattr(scene, "node_tree"):
        return

    # If studio does not use bloom:
    if not getattr(studio, "use_bloom", False):
        if scene.node_tree:
            glare = scene.node_tree.nodes.get("RenderFlo_Bloom")
            if glare:
                glare.mute = True

            comp = scene.node_tree.nodes.get("Composite") or next((n for n in scene.node_tree.nodes if n.type == 'COMPOSITE'), None)
            rl = scene.node_tree.nodes.get("Render Layers") or next((n for n in scene.node_tree.nodes if n.type == 'R_LAYERS'), None)

            # Ensure direct link from Render Layers to Composite when bloom is off
            if rl and comp and rl.outputs.get('Image') and comp.inputs.get('Image'):
                if not any(l.to_node == comp for l in rl.outputs['Image'].links):
                    scene.node_tree.links.new(rl.outputs['Image'], comp.inputs['Image'])

            # If only RenderFlo helper nodes exist, disable use_nodes completely so Cycles renders beauty pass natively
            non_rf_nodes = [n for n in scene.node_tree.nodes if n.name not in {"Render Layers", "Composite", "Viewer", "Reroute", "RenderFlo_Bloom", "RenderFlo_SetAlpha"}]
            if not non_rf_nodes:
                scene.use_nodes = False
        else:
            scene.use_nodes = False

        set_viewport_compositor_mode('DISABLED')
        return

    scene.use_nodes = True
    tree = scene.node_tree

    # Remove any old RenderFlo_SetAlpha node that breaks Viewport Compositor real-time preview
    old_sa = tree.nodes.get("RenderFlo_SetAlpha")
    if old_sa:
        tree.nodes.remove(old_sa)

    # Find or create Render Layers node
    rl = tree.nodes.get("Render Layers")
    if not rl:
        rl = next((n for n in tree.nodes if n.type == 'R_LAYERS'), None)
    if not rl:
        rl = tree.nodes.new('CompositorNodeRLayers')
        rl.location = (-400, 400)

    # Ensure Render Layers targets the active view layer
    if hasattr(bpy.context, "view_layer") and bpy.context.view_layer:
        try:
            rl.layer = bpy.context.view_layer.name
        except Exception:
            pass
    elif len(scene.view_layers) > 0:
        try:
            rl.layer = scene.view_layers[0].name
        except Exception:
            pass

    # Find or create Composite node
    comp = tree.nodes.get("Composite")
    if not comp:
        comp = next((n for n in tree.nodes if n.type == 'COMPOSITE'), None)
    if not comp:
        comp = tree.nodes.new('CompositorNodeComposite')
        comp.location = (450, 400)

    # Find or create RenderFlo_Bloom Glare node
    glare = tree.nodes.get("RenderFlo_Bloom")
    if not glare:
        glare = tree.nodes.new('CompositorNodeGlare')
        glare.name = "RenderFlo_Bloom"
        glare.label = "Studio Bloom / Glow"
        glare.location = (-100, 400)

    glare.mute = False

    # Choose glare_type: BLOOM in Blender 4.2+, FOG_GLOW fallback
    enum_types = [item.identifier for item in glare.bl_rna.properties['glare_type'].enum_items]
    if 'BLOOM' in enum_types:
        glare.glare_type = 'BLOOM'
    elif 'FOG_GLOW' in enum_types:
        glare.glare_type = 'FOG_GLOW'

    # Set parameters via socket inputs (Blender 4.2+) or legacy attributes
    if 'Strength' in glare.inputs:
        glare.inputs['Strength'].default_value = studio.bloom_intensity
    if 'Size' in glare.inputs:
        glare.inputs['Size'].default_value = studio.bloom_radius
    elif hasattr(glare, 'size'):
        try:
            glare.size = int(max(6, min(9, round(studio.bloom_radius * 10))))
        except Exception:
            pass

    if 'Threshold' in glare.inputs:
        glare.inputs['Threshold'].default_value = studio.bloom_threshold
    elif hasattr(glare, 'threshold'):
        try:
            glare.threshold = studio.bloom_threshold
        except Exception:
            pass

    if 'Tint' in glare.inputs:
        glare.inputs['Tint'].default_value = (studio.bloom_tint[0], studio.bloom_tint[1], studio.bloom_tint[2], 1.0)

    # Direct connection: RL (Image) -> Glare (Image) -> Composite (Image)
    # This is fully supported by Blender's real-time Viewport Compositor and preserves alpha cleanly
    if rl.outputs.get('Image') and glare.inputs.get('Image'):
        if not any(l.to_node == glare and l.to_socket == glare.inputs['Image'] for l in rl.outputs['Image'].links):
            tree.links.new(rl.outputs['Image'], glare.inputs['Image'])

    if glare.outputs.get('Image') and comp.inputs.get('Image'):
        tree.links.new(glare.outputs['Image'], comp.inputs['Image'])

    # If Viewer node exists, also route to viewer
    viewer = next((n for n in tree.nodes if n.type == 'VIEWER'), None)
    if viewer and viewer.inputs.get('Image') and glare.outputs.get('Image'):
        tree.links.new(glare.outputs['Image'], viewer.inputs['Image'])

    # Enable real-time Viewport Compositor so Bloom is visible live in the 3D viewport
    if getattr(studio, "bloom_viewport", True):
        set_viewport_compositor_mode('ALWAYS')
    else:
        set_viewport_compositor_mode('DISABLED')


def set_viewport_compositor_mode(mode='ALWAYS'):
    """Set the real-time Viewport Compositor mode across 3D Viewports ('ALWAYS', 'CAMERA', or 'DISABLED')."""
    try:
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    for space in area.spaces:
                        if space.type == 'VIEW_3D' and hasattr(space, "shading"):
                            if hasattr(space.shading, "use_compositor"):
                                space.shading.use_compositor = mode
    except Exception:
        pass


def disable_viewport_compositor():
    """Disable real-time Viewport Compositor across 3D Viewports."""
    set_viewport_compositor_mode('DISABLED')


def on_studio_lock_change(self, context):
    if not context or not context.scene:
        return
    if self.camera_obj:
        for i in range(3):
            self.camera_obj.lock_location[i] = self.is_locked
            self.camera_obj.lock_rotation[i] = self.is_locked
            self.camera_obj.lock_scale[i] = self.is_locked

    if self.light_collection_name:
        coll = bpy.data.collections.get(self.light_collection_name)
        if coll:
            for obj in coll.objects:
                if obj.type == 'LIGHT':
                    for i in range(3):
                        obj.lock_location[i] = self.is_locked
                        obj.lock_rotation[i] = self.is_locked
                        obj.lock_scale[i] = self.is_locked


def get_all_layer_collections(layer_coll):
    """Traverse all nested layer collections in the view layer."""
    yield layer_coll
    for child in layer_coll.children:
        yield from get_all_layer_collections(child)


def apply_collection_states(context, studio):
    """Apply collection visibility / isolation (Model Sets)."""
    state_map = {item.name: item for item in studio.collection_states}
    if context and hasattr(context, "view_layer") and context.view_layer:
        root_layer_coll = context.view_layer.layer_collection
        for lc in get_all_layer_collections(root_layer_coll):
            if lc.collection.name in state_map:
                st = state_map[lc.collection.name]
                lc.exclude = st.hide_viewport
                lc.hide_viewport = False
                lc.collection.hide_viewport = False
                lc.collection.hide_render = st.hide_render
    else:
        for st in studio.collection_states:
            coll = bpy.data.collections.get(st.name)
            if coll:
                coll.hide_viewport = st.hide_viewport
                coll.hide_render = st.hide_render


def apply_object_transforms(studio):
    """Apply saved object positions / rotations (Exploded Views)."""
    for t_item in studio.object_transforms:
        obj = bpy.data.objects.get(t_item.object_name)
        if obj:
            obj.location = t_item.location
            obj.rotation_euler = t_item.rotation_euler
            obj.scale = t_item.scale


def on_studio_use_collections_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    scene = context.scene
    if 0 <= scene.rf_studio_index < len(scene.rf_studios) and scene.rf_studios[scene.rf_studio_index] == self:
        if self.use_collections:
            apply_collection_states(context, self)


def on_studio_use_transforms_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    scene = context.scene
    if 0 <= scene.rf_studio_index < len(scene.rf_studios) and scene.rf_studios[scene.rf_studio_index] == self:
        if self.use_transforms:
            capture_studio_state(context, self)


def apply_part_visibility(studio):
    """Apply saved object visibility (hidden / visible parts) for this studio."""
    for pv in studio.part_visibilities:
        obj = bpy.data.objects.get(pv.object_name)
        if obj:
            obj.hide_set(pv.hide_viewport)
            obj.hide_viewport = pv.hide_viewport
            obj.hide_render = pv.hide_render


def on_studio_use_part_visibility_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    scene = context.scene
    if 0 <= scene.rf_studio_index < len(scene.rf_studios) and scene.rf_studios[scene.rf_studio_index] == self:
        if self.use_part_visibility:
            capture_studio_state(context, self)
        else:
            from .flex_deform import get_product_objects
            for obj in get_product_objects(scene):
                obj.hide_set(False)
                obj.hide_viewport = False
                obj.hide_render = False


def on_active_studio_index_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    scene = context.scene
    if len(scene.rf_studios) == 0:
        return
    # Clamp index safely
    clamped_idx = max(0, min(scene.rf_studio_index, len(scene.rf_studios) - 1))
    if scene.rf_studio_index != clamped_idx:
        scene.rf_studio_index = clamped_idx
        return

    # Automatically activate studio when list selection changes
    current_active = getattr(scene, "rf_active_studio_index", -1)
    if current_active != clamped_idx:
        bpy.ops.renderflo.activate_studio(index=clamped_idx)
        return

    studio = scene.rf_studios[clamped_idx]
    from .cmf_materials import sync_studio_cmf_toggles
    sync_studio_cmf_toggles(scene, studio)

    # Sync ribbon dropdowns
    try:
        scene.rf_active_studio_enum = str(clamped_idx)
        scene.rf_active_aspect_preset_enum = studio.aspect_preset
        scene.rf_active_cmf_enum = studio.cmf_mode
    except Exception:
        pass


# ------------------------------------------------------------------------
# State Capture & Apply Pipelines
# ------------------------------------------------------------------------

def capture_studio_state(context, studio):
    if studio.is_locked:
        return

    with internal_update_guard():
        scene = context.scene
        ensure_studio_light_collection(context, studio)
        from .cmf_materials import sync_studio_cmf_toggles, record_materials_into_collection
        sync_studio_cmf_toggles(scene, studio)

        # Only update camera if this studio is the one currently loaded in the 3D scene,
        # or if the studio does not have any camera assigned yet.
        # This prevents switching studios without locking from overwriting cameras.
        active_idx = getattr(scene, "rf_active_studio_index", scene.rf_studio_index)
        is_active_studio = (0 <= active_idx < len(scene.rf_studios) and scene.rf_studios[active_idx] == studio)

        if scene.camera and (is_active_studio or not studio.camera_obj):
            studio.camera_obj = scene.camera
        if not studio.world_name:
            studio.world_name = scene.world.name if scene.world else f"World_{bpy.path.clean_name(studio.name)}"

        ignored_colls = {s.light_collection_name for s in scene.rf_studios if s.light_collection_name}
        ignored_colls.add(MASTER_LIGHT_COLL)
        ignored_colls.add(MASTER_CAM_COLL)
        ignored_colls.add(MASTER_CUTAWAY_COLL)

        studio.collection_states.clear()
        if context and hasattr(context, "view_layer") and context.view_layer:
            root_layer_coll = context.view_layer.layer_collection
            for lc in get_all_layer_collections(root_layer_coll):
                if lc == root_layer_coll or lc.collection.name in ignored_colls:
                    continue
                item = studio.collection_states.add()
                item.name = lc.collection.name
                item.hide_viewport = lc.exclude or lc.hide_viewport or lc.collection.hide_viewport
                item.hide_render = lc.collection.hide_render
        else:
            for coll in bpy.data.collections:
                if coll.name in ignored_colls:
                    continue
                item = studio.collection_states.add()
                item.name = coll.name
                item.hide_viewport = coll.hide_viewport
                item.hide_render = coll.hide_render

        # Only record into studio-specific material snapshot; do NOT overwrite global CMF presets
        record_materials_into_collection(scene, studio.object_materials)

        studio.object_transforms.clear()
        for obj in list(scene.objects):
            if (obj.type in {'MESH', 'CURVE', 'SURFACE', 'EMPTY'} and
                    obj.name not in {TARGET_EMPTY_NAME, GROUND_PLANE_NAME, BACKDROP_OBJ_NAME, DOME_VISUALIZER_OBJ, CUTAWAY_BOX_NAME} and
                    not obj.name.startswith(DOME_PIN_PREFIX)):
                t_item = studio.object_transforms.add()
                t_item.object_name = obj.name
                t_item.location = obj.location
                t_item.rotation_euler = obj.rotation_euler
                t_item.scale = obj.scale

        studio.part_visibilities.clear()
        has_hidden_part = False
        for obj in list(scene.objects):
            if (obj.type in {'MESH', 'CURVE', 'SURFACE', 'EMPTY'} and
                    obj.name not in {TARGET_EMPTY_NAME, GROUND_PLANE_NAME, BACKDROP_OBJ_NAME, DOME_VISUALIZER_OBJ, CUTAWAY_BOX_NAME} and
                    not obj.name.startswith(DOME_PIN_PREFIX) and
                    not obj.name.startswith("Studio_Light_") and
                    obj.type != 'LIGHT' and obj.type != 'CAMERA'):
                pv = studio.part_visibilities.add()
                pv.object_name = obj.name
                is_hidden = obj.hide_get() or obj.hide_viewport or obj.hide_render
                pv.hide_viewport = bool(is_hidden)
                pv.hide_render = bool(obj.hide_render or is_hidden)
                if is_hidden:
                    has_hidden_part = True
        if has_hidden_part:
            studio.use_part_visibility = True

        studio.light_states.clear()
        for obj in list(scene.objects):
            if obj.type == 'LIGHT':
                l_item = studio.light_states.add()
                l_item.light_obj_name = obj.name
                l_item.location = obj.location
                l_item.rotation_euler = obj.rotation_euler
                l_item.scale = obj.scale
                l_item.energy = obj.data.energy
                l_item.color = obj.data.color
                if hasattr(obj.data, "size"):
                    l_item.size = obj.data.size
                l_item.hide_viewport = obj.hide_get()
                l_item.hide_render = obj.hide_render


def apply_studio_state(context, studio):
    with internal_update_guard():
        scene = context.scene
        from .cmf_materials import sync_studio_cmf_toggles, apply_cmf_to_scene
        from .lighting_hdri import rebuild_studio_hdri_nodes, update_studio_dome_visualizer
        from .batch_queue import apply_render_quality_settings

        sync_studio_cmf_toggles(scene, studio)

        if studio.use_camera and studio.camera_obj and studio.camera_obj.type == 'CAMERA':
            scene.camera = studio.camera_obj

        if studio.use_resolution:
            scene.render.resolution_x = studio.res_x
            scene.render.resolution_y = studio.res_y
            scene.render.resolution_percentage = studio.res_scale
            if scene.camera and scene.camera.data:
                scene.camera.data.sensor_fit = 'VERTICAL' if (studio.res_y > studio.res_x) else 'HORIZONTAL'

        if studio.use_lights:
            world = None
            if studio.world_name:
                world = bpy.data.worlds.get(studio.world_name)
            if not world:
                world_name = f"World_{bpy.path.clean_name(studio.name)}"
                world = bpy.data.worlds.get(world_name)
                if not world:
                    world = bpy.data.worlds.new(world_name)
                studio.world_name = world.name
            scene.world = world

            rebuild_studio_hdri_nodes(studio, scene, force=True)
            update_studio_dome_visualizer(studio, context)
            switch_exclusive_studio_lights(context, studio)

            for l_item in studio.light_states:
                obj = bpy.data.objects.get(l_item.light_obj_name)
                if obj and obj.type == 'LIGHT':
                    obj.location = l_item.location
                    obj.rotation_euler = l_item.rotation_euler
                    obj.scale = l_item.scale
                    obj.data.energy = l_item.energy
                    obj.data.color = l_item.color
                    if hasattr(obj.data, "size"):
                        obj.data.size = l_item.size
                    obj.hide_set(l_item.hide_viewport)
                    obj.hide_render = l_item.hide_render

        if studio.use_collections:
            apply_collection_states(context, studio)

        if studio.use_transforms:
            apply_object_transforms(studio)

        if getattr(studio, "use_part_visibility", False):
            apply_part_visibility(studio)
        else:
            # If any studio in the project uses part visibility, restore all product objects to unhidden
            if any(getattr(s, "use_part_visibility", False) for s in scene.rf_studios):
                from .flex_deform import get_product_objects
                for obj in get_product_objects(scene):
                    obj.hide_set(False)
                    obj.hide_viewport = False
                    obj.hide_render = False

        apply_cmf_to_scene(scene, studio)

        if studio.use_image_style:
            apply_image_style_to_scene(scene, studio)
        if getattr(studio, "viewport_show_dome", False) and not studio.film_transparent:
            scene.render.film_transparent = False

        apply_bloom_to_scene(scene, studio)

        target_samples = studio.studio_samples if studio.use_custom_samples else scene.rf_render_samples
        apply_render_quality_settings(scene, target_samples)

        try:
            scene.rf_active_studio_enum = str(scene.rf_studio_index)
            scene.rf_active_aspect_preset_enum = studio.aspect_preset
            scene.rf_active_cmf_enum = studio.cmf_mode
        except Exception:
            pass


# ------------------------------------------------------------------------
# Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_toggle_render_preview(bpy.types.Operator):
    bl_idname = "renderflo.toggle_render_preview"
    bl_label = "Toggle Render Preview"

    def execute(self, context):
        from .batch_queue import configure_cycles_gpu
        scene = context.scene
        configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)
        active_s = scene.rf_studios[scene.rf_studio_index] if (0 <= scene.rf_studio_index < len(scene.rf_studios)) else None
        live_bloom = bool(active_s and getattr(active_s, "use_bloom", False) and getattr(active_s, "bloom_viewport", True))
        comp_mode = 'ALWAYS' if live_bloom else 'DISABLED'

        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.shading.type = 'SOLID' if space.shading.type == 'RENDERED' else 'RENDERED'
                        if hasattr(space.shading, "use_compositor"):
                            space.shading.use_compositor = comp_mode
        return {'FINISHED'}


class RENDERFLO_OT_add_curved_backdrop(bpy.types.Operator):
    bl_idname = "renderflo.add_curved_backdrop"
    bl_label = "Add Studio Curved Backdrop"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        target = ensure_light_target(context)
        b_obj = bpy.data.objects.get(BACKDROP_OBJ_NAME)

        if not b_obj:
            mesh = bpy.data.meshes.new(BACKDROP_OBJ_NAME)
            w, d, h = 10.0, 6.0, 5.0
            verts = [(-w, -d, 0.0), (w, -d, 0.0), (w, d * 0.5, 0.0), (-w, d * 0.5, 0.0), (-w, d * 0.5, h), (w, d * 0.5, h)]
            faces = [(0, 1, 2, 3), (3, 2, 5, 4)]
            mesh.from_pydata(verts, [], faces)
            mesh.update()

            b_obj = bpy.data.objects.new(BACKDROP_OBJ_NAME, mesh)
            scene.collection.objects.link(b_obj)

            bev = b_obj.modifiers.new(name="Bevel", type='BEVEL')
            bev.width = 2.5
            bev.segments = 16

            sub = b_obj.modifiers.new(name="Subsurf", type='SUBSURF')
            sub.levels = 1

            for p in mesh.polygons:
                p.use_smooth = True

            mat = bpy.data.materials.new(name="RenderFlo_Backdrop_Mat")
            mat.use_nodes = True
            bsdf = mat.node_tree.nodes.get("Principled BSDF")
            if bsdf:
                col_socket = bsdf.inputs.get("Base Color") or bsdf.inputs.get("Color")
                if col_socket:
                    col_socket.default_value = (0.85, 0.85, 0.85, 1.0)
                rough_socket = bsdf.inputs.get("Roughness")
                if rough_socket:
                    rough_socket.default_value = 0.6
            b_obj.data.materials.append(mat)

        b_obj.location = (target.location.x, target.location.y, 0.0)
        self.report({'INFO'}, "Created/Aligned Studio Backdrop")
        return {'FINISHED'}


class RENDERFLO_OT_snap_shadow_floor(bpy.types.Operator):
    bl_idname = "renderflo.snap_shadow_floor"
    bl_label = "Snap Shadow Catcher Floor to Product"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        min_z = None
        center_x, center_y = 0.0, 0.0
        mesh_count = 0

        depsgraph = context.evaluated_depsgraph_get()
        for obj in list(scene.objects):
            if obj.type == 'MESH' and obj.visible_get() and obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                eval_obj = obj.evaluated_get(depsgraph)
                for corner in eval_obj.bound_box:
                    pt = eval_obj.matrix_world @ Vector(corner)
                    if min_z is None or pt.z < min_z:
                        min_z = pt.z
                center_x += obj.matrix_world.translation.x
                center_y += obj.matrix_world.translation.y
                mesh_count += 1

        if min_z is None:
            min_z = 0.0
        if mesh_count > 0:
            center_x /= mesh_count
            center_y /= mesh_count

        floor_obj = bpy.data.objects.get(GROUND_PLANE_NAME)
        if not floor_obj:
            bpy.ops.mesh.primitive_plane_add(size=25.0, location=(center_x, center_y, min_z))
            floor_obj = context.active_object
            floor_obj.name = GROUND_PLANE_NAME
        else:
            floor_obj.location = (center_x, center_y, min_z)

        floor_obj.is_shadow_catcher = True
        floor_obj.display_type = 'WIRE'
        self.report({'INFO'}, f"Shadow Catcher Floor snapped to Z = {min_z:.3f}")
        return {'FINISHED'}


class RENDERFLO_OT_add_studio(bpy.types.Operator):
    bl_idname = "renderflo.add_studio"
    bl_label = "Create New Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        with internal_update_guard():
            scene = context.scene
            prev_studio = scene.rf_studios[scene.rf_studio_index] if (0 <= scene.rf_studio_index < len(scene.rf_studios)) else None

            if prev_studio and not prev_studio.is_locked and getattr(scene, "rf_auto_save_studios", True):
                capture_studio_state(context, prev_studio)

            from .cmf_materials import record_materials_into_collection, sync_studio_cmf_toggles

            if len(scene.rf_cmf_presets) == 0:
                first_cmf = scene.rf_cmf_presets.add()
                first_cmf.name = "Default"
                record_materials_into_collection(scene, first_cmf.object_materials)
            elif len(scene.rf_studios) >= 1:
                # Auto-save baseline scene materials into "Default" CMF when 2nd studio or higher is created
                default_cmf = next((c for c in scene.rf_cmf_presets if c.name == "Default"), None)
                if not default_cmf:
                    default_cmf = scene.rf_cmf_presets.add()
                    default_cmf.name = "Default"
                record_materials_into_collection(scene, default_cmf.object_materials)

            new_studio = scene.rf_studios.add()
            new_studio.name = f"Studio_{len(scene.rf_studios):02d}"
            new_studio.studio_samples = scene.rf_render_samples

            new_world_name = f"World_{new_studio.name}"
            new_world = bpy.data.worlds.new(new_world_name)
            new_studio.world_name = new_world.name

            if prev_studio:
                new_studio.aspect_preset = prev_studio.aspect_preset
                new_studio.base_resolution = prev_studio.base_resolution
                new_studio.res_x = prev_studio.res_x
                new_studio.res_y = prev_studio.res_y
                new_studio.res_scale = prev_studio.res_scale
                new_studio.exposure = prev_studio.exposure
                new_studio.contrast = getattr(prev_studio, "contrast", 'None')
                new_studio.standard_view = getattr(prev_studio, "standard_view", 'CUSTOM')
                new_studio.film_transparent = prev_studio.film_transparent
                new_studio.use_collections = prev_studio.use_collections
                new_studio.use_transforms = prev_studio.use_transforms
                new_studio.use_bloom = getattr(prev_studio, "use_bloom", False)
                new_studio.bloom_intensity = getattr(prev_studio, "bloom_intensity", 1.0)
                new_studio.bloom_radius = getattr(prev_studio, "bloom_radius", 0.5)
                new_studio.bloom_threshold = getattr(prev_studio, "bloom_threshold", 1.0)
                new_studio.bloom_tint = tuple(getattr(prev_studio, "bloom_tint", (1.0, 1.0, 1.0)))
                new_studio.bloom_viewport = getattr(prev_studio, "bloom_viewport", True)
                new_studio.use_part_visibility = getattr(prev_studio, "use_part_visibility", False)
                if new_studio.use_part_visibility:
                    for pv in prev_studio.part_visibilities:
                        new_pv = new_studio.part_visibilities.add()
                        new_pv.object_name = pv.object_name
                        new_pv.hide_viewport = pv.hide_viewport
                        new_pv.hide_render = pv.hide_render

                if scene.rf_studio_clone_lights:
                    new_studio.use_lights = prev_studio.use_lights
                    new_studio.lighting_tab = prev_studio.lighting_tab
                    new_studio.use_hdri_dome = prev_studio.use_hdri_dome
                    new_studio.use_custom_hdri = getattr(prev_studio, "use_custom_hdri", False)
                    new_studio.hdri_image = getattr(prev_studio, "hdri_image", None)
                    new_studio.hdri_image_strength = getattr(prev_studio, "hdri_image_strength", 1.0)
                    new_studio.hdri_base_color = tuple(prev_studio.hdri_base_color)
                    new_studio.hdri_base_energy = prev_studio.hdri_base_energy
                    new_studio.hdri_rotation = prev_studio.hdri_rotation
                    new_studio.hdri_glow_size = getattr(prev_studio, "hdri_glow_size", 1.0)
                    new_studio.viewport_show_dome = getattr(prev_studio, "viewport_show_dome", True)

                    for p in prev_studio.hdri_pins:
                        new_p = new_studio.hdri_pins.add()
                        new_p.name = p.name
                        new_p.enabled = p.enabled
                        new_p.pin_shape = p.pin_shape
                        new_p.azimuth = p.azimuth
                        new_p.elevation = p.elevation
                        new_p.radius = p.radius
                        new_p.aspect = p.aspect
                        new_p.rotation = p.rotation
                        new_p.falloff = p.falloff
                        new_p.energy = p.energy
                        new_p.color = tuple(p.color)
                else:
                    new_studio.use_lights = True
                    new_studio.lighting_tab = 'HDRI'
                    new_studio.use_hdri_dome = True
                    new_studio.use_custom_hdri = False
                    new_studio.hdri_image = None
                    new_studio.hdri_image_strength = 1.0
                    new_studio.hdri_base_color = (0.05, 0.05, 0.06)
                    new_studio.hdri_base_energy = 0.5
                    new_studio.hdri_rotation = 0.0
                    new_studio.hdri_glow_size = 1.0
                    new_studio.viewport_show_dome = True

                    p0 = new_studio.hdri_pins.add()
                    p0.name = "Key_Pin"
                    p0.azimuth = 45.0
                    p0.elevation = 35.0
                    p0.radius = 0.18
                    p0.falloff = 0.15
                    p0.energy = 15.0
                    p0.color = (1.0, 1.0, 1.0)
            else:
                new_studio.res_x = scene.render.resolution_x
                new_studio.res_y = scene.render.resolution_y
                new_studio.exposure = scene.view_settings.exposure
                new_studio.contrast = getattr(scene.view_settings, "look", 'None') or 'None'
                new_studio.film_transparent = scene.render.film_transparent

                p0 = new_studio.hdri_pins.add()
                p0.name = "Key_Pin"
                p0.azimuth = 45.0
                p0.elevation = 35.0
                p0.radius = 0.18
                p0.falloff = 0.15
                p0.energy = 15.0
                p0.color = (1.0, 1.0, 1.0)

            if scene.rf_studio_new_cam_mode == 'NEW_VIEW':
                new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=True)
            elif scene.rf_studio_new_cam_mode == 'NEW_COPY':
                new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=False)
            else:
                if prev_studio and prev_studio.camera_obj:
                    new_studio.camera_obj = prev_studio.camera_obj
                elif scene.camera:
                    new_studio.camera_obj = scene.camera
                else:
                    new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=True)

            new_light_coll = ensure_studio_light_collection(context, new_studio)
            if scene.rf_studio_clone_lights and prev_studio and prev_studio.light_collection_name:
                prev_coll = bpy.data.collections.get(prev_studio.light_collection_name)
                if prev_coll:
                    for obj in list(prev_coll.objects):
                        if obj.type == 'LIGHT':
                            new_obj = obj.copy()
                            new_obj.data = obj.data.copy()
                            new_obj.name = f"{new_studio.name}_{obj.name}"
                            new_light_coll.objects.link(new_obj)

            if prev_studio and prev_studio.cmf_mode:
                new_studio.cmf_mode = prev_studio.cmf_mode
            elif len(scene.rf_cmf_presets) > 0:
                new_studio.cmf_mode = scene.rf_cmf_presets[0].name
            else:
                new_studio.cmf_mode = "Default"

            for s in scene.rf_studios:
                sync_studio_cmf_toggles(scene, s)

            new_idx = len(scene.rf_studios) - 1
            scene.rf_studio_index = new_idx
            scene.rf_active_studio_index = new_idx
            scene.world = new_world
            switch_exclusive_studio_lights(context, new_studio)
            capture_studio_state(context, new_studio)
            apply_studio_state(context, new_studio)

        self.report({'INFO'}, f"ID RenderFlo: Created '{new_studio.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_make_unique_camera(bpy.types.Operator):
    bl_idname = "renderflo.make_unique_camera"
    bl_label = "Spawn Dedicated Camera for This Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            studio.camera_obj = create_camera_for_studio(context, studio.name, match_viewport=False)
        return {'FINISHED'}


class RENDERFLO_OT_set_standard_camera_view(bpy.types.Operator):
    bl_idname = "renderflo.set_standard_camera_view"
    bl_label = "Set Standard Camera View"
    bl_description = "Align studio camera to a standard CAD orthographic view angle"
    bl_options = {'REGISTER', 'UNDO'}

    view: bpy.props.EnumProperty(
        name="View",
        items=[
            ('FRONT', "Front", "Standard CAD Front orthographic view (-Y)"),
            ('RIGHT', "Right", "Standard CAD Right orthographic view (+X)"),
            ('LEFT', "Left", "Standard CAD Left orthographic view (-X)"),
            ('TOP', "Top", "Standard CAD Top orthographic view (+Z)"),
            ('BOTTOM', "Bottom", "Standard CAD Bottom orthographic view (-Z)"),
            ('BACK', "Back", "Standard CAD Back orthographic view (+Y)"),
            ('ISO', "Isometric", "Standard CAD 3D Isometric angle"),
        ],
        default='FRONT'
    )

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            studio.standard_view = self.view
            apply_standard_camera_view(studio, context, self.view)
            self.report({'INFO'}, f"Aligned camera to {self.view.title()} view")
            return {'FINISHED'}
        self.report({'WARNING'}, "No active studio")
        return {'CANCELLED'}


class RENDERFLO_OT_toggle_camera_ortho(bpy.types.Operator):
    bl_idname = "renderflo.toggle_camera_ortho"
    bl_label = "Toggle Orthographic / Perspective"
    bl_description = "Switch active studio camera between Perspective and Orthographic projection mode"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        cam = scene.camera
        if not cam or cam.type != 'CAMERA':
            self.report({'WARNING'}, "No active camera in scene")
            return {'CANCELLED'}

        cam_data = cam.data
        if cam_data.type == 'ORTHO':
            cam_data.type = 'PERSP'
            self.report({'INFO'}, "Camera set to Perspective mode")
        else:
            cam_data.type = 'ORTHO'
            self.report({'INFO'}, "Camera set to Orthographic mode")
        return {'FINISHED'}


class RENDERFLO_OT_update_studio(bpy.types.Operator):
    bl_idname = "renderflo.update_studio"
    bl_label = "Update Studio State"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        if 0 <= self.index < len(scene.rf_studios):
            studio = scene.rf_studios[self.index]
            active_idx = getattr(scene, "rf_active_studio_index", scene.rf_studio_index)
            # If updating a studio not currently loaded in the 3D scene, activate it first so we don't capture the wrong camera/scene
            if self.index != active_idx:
                bpy.ops.renderflo.activate_studio(index=self.index)
            else:
                from .cmf_materials import sync_studio_cmf_toggles
                sync_studio_cmf_toggles(scene, studio)
                capture_studio_state(context, studio)
            self.report({'INFO'}, f"Saved state for '{studio.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_activate_studio(bpy.types.Operator):
    bl_idname = "renderflo.activate_studio"
    bl_label = "Activate Studio"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        if not (0 <= self.index < len(scene.rf_studios)):
            return {'CANCELLED'}

        active_idx = getattr(scene, "rf_active_studio_index", -1)
        prev_studio = None
        if 0 <= active_idx < len(scene.rf_studios):
            prev_studio = scene.rf_studios[active_idx]
            # Live auto-save previous studio's state before switching, only if unlocked and different
            if getattr(scene, "rf_auto_save_studios", True) and not prev_studio.is_locked and active_idx != self.index:
                capture_studio_state(context, prev_studio)

        target_studio = scene.rf_studios[self.index]
        scene.rf_active_studio_index = self.index
        scene.rf_studio_index = self.index

        from .cmf_materials import sync_studio_cmf_toggles
        sync_studio_cmf_toggles(scene, target_studio)

        # If switching away from an exploded studio to a normal studio, restore rest positions
        if prev_studio and prev_studio.use_transforms and not target_studio.use_transforms:
            if len(target_studio.object_transforms) > 0:
                apply_object_transforms(target_studio)

        # If switching away from a studio with hidden parts to one without, ensure product parts are visible
        if prev_studio and getattr(prev_studio, "use_part_visibility", False) and not getattr(target_studio, "use_part_visibility", False):
            from .flex_deform import get_product_objects
            for obj in get_product_objects(scene):
                obj.hide_set(False)
                obj.hide_viewport = False
                obj.hide_render = False

        apply_studio_state(context, target_studio)
        return {'FINISHED'}


class RENDERFLO_OT_capture_studio_transforms(bpy.types.Operator):
    bl_idname = "renderflo.capture_studio_transforms"
    bl_label = "Store Current Positions"
    bl_description = "Capture current 3D component positions and rotations into this studio snapshot"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            with internal_update_guard():
                studio.use_transforms = True
            capture_studio_state(context, studio)
            self.report({'INFO'}, f"ID RenderFlo: Saved exploded part positions for '{studio.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_reset_studio_transforms(bpy.types.Operator):
    bl_idname = "renderflo.reset_studio_transforms"
    bl_label = "Reset to Assembled"
    bl_description = "Restore all product components back to their original assembled positions"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        rest_map = {}
        if len(scene.rf_studios) > 0 and len(scene.rf_studios[0].object_transforms) > 0:
            for t in scene.rf_studios[0].object_transforms:
                rest_map[t.object_name] = (t.location, t.rotation_euler, t.scale)

        from ..state import REST_LOCATION_PROP
        from .flex_deform import get_product_objects
        objs = get_product_objects(scene)
        for obj in objs:
            if obj.name in rest_map:
                loc, rot, scl = rest_map[obj.name]
                obj.location = loc.copy() if hasattr(loc, "copy") else loc
                obj.rotation_euler = rot.copy() if hasattr(rot, "copy") else rot
                obj.scale = scl.copy() if hasattr(scl, "copy") else scl
            elif REST_LOCATION_PROP in obj:
                try:
                    obj.location = Vector(obj[REST_LOCATION_PROP])
                except Exception:
                    pass

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            capture_studio_state(context, studio)

        self.report({'INFO'}, "ID RenderFlo: Reset parts to assembled positions")
        return {'FINISHED'}


class RENDERFLO_OT_remove_studio(bpy.types.Operator):
    bl_idname = "renderflo.remove_studio"
    bl_label = "Remove Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        idx = scene.rf_studio_index
        if 0 <= idx < len(scene.rf_studios):
            studio = scene.rf_studios[idx]
            if studio.light_collection_name:
                coll = bpy.data.collections.get(studio.light_collection_name)
                if coll:
                    for obj in list(coll.objects):
                        bpy.data.objects.remove(obj, do_unlink=True)
                    bpy.data.collections.remove(coll)
            if studio.world_name:
                w_obj = bpy.data.worlds.get(studio.world_name)
                if w_obj:
                    bpy.data.worlds.remove(w_obj)
            scene.rf_studios.remove(idx)
            new_idx = max(0, min(idx, len(scene.rf_studios) - 1))
            scene.rf_studio_index = new_idx
            scene.rf_active_studio_index = new_idx
            if len(scene.rf_studios) > 0:
                apply_studio_state(context, scene.rf_studios[scene.rf_studio_index])
        return {'FINISHED'}


class RENDERFLO_OT_select_target(bpy.types.Operator):
    bl_idname = "renderflo.select_target"
    bl_label = "Select Light Target"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        target = ensure_light_target(context)
        for o in context.selected_objects:
            o.select_set(False)
        target.select_set(True)
        context.view_layer.objects.active = target
        return {'FINISHED'}


class RENDERFLO_OT_activate_gpu_now(bpy.types.Operator):
    bl_idname = "renderflo.activate_gpu_now"
    bl_label = "Verify & Activate GPU Now"
    bl_options = {'REGISTER'}

    def execute(self, context):
        from .batch_queue import configure_cycles_gpu, apply_render_quality_settings
        scene = context.scene
        hw_label = configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)
        apply_render_quality_settings(scene, scene.rf_render_samples)
        self.report({'INFO'}, f"ID RenderFlo: Render device set to {hw_label} @ {scene.rf_render_samples} Samples")
        return {'FINISHED'}


class RENDERFLO_OT_move_studio(bpy.types.Operator):
    bl_idname = "renderflo.move_studio"
    bl_label = "Move Studio"
    bl_description = "Move active studio up or down in the studio sequence"
    bl_options = {'REGISTER', 'UNDO'}

    direction: bpy.props.EnumProperty(
        items=[('UP', "Up", "Move up"), ('DOWN', "Down", "Move down")],
        default='UP'
    )

    def execute(self, context):
        scene = context.scene
        count = len(scene.rf_studios)
        if count < 2:
            return {'FINISHED'}

        idx = scene.rf_studio_index
        if self.direction == 'UP':
            if idx > 0:
                scene.rf_studios.move(idx, idx - 1)
                scene.rf_studio_index = idx - 1
                scene.rf_active_studio_index = idx - 1
        elif self.direction == 'DOWN':
            if idx < count - 1:
                scene.rf_studios.move(idx, idx + 1)
                scene.rf_studio_index = idx + 1
                scene.rf_active_studio_index = idx + 1

        try:
            scene.rf_active_studio_enum = str(scene.rf_studio_index)
        except Exception:
            pass

        return {'FINISHED'}


class RENDERFLO_OT_capture_part_visibility(bpy.types.Operator):
    bl_idname = "renderflo.capture_part_visibility"
    bl_label = "Store Part Visibility"
    bl_description = "Capture current hidden/visible status of all parts into this studio snapshot"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            with internal_update_guard():
                studio.use_part_visibility = True
            capture_studio_state(context, studio)
            hidden_count = sum(1 for p in studio.part_visibilities if p.hide_viewport or p.hide_render)
            self.report({'INFO'}, f"ID RenderFlo: Saved part visibility for '{studio.name}' ({hidden_count} hidden)")
        return {'FINISHED'}


class RENDERFLO_OT_reset_part_visibility(bpy.types.Operator):
    bl_idname = "renderflo.reset_part_visibility"
    bl_label = "Show All Parts"
    bl_description = "Unhide all product components and make them visible in this studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        from .flex_deform import get_product_objects
        for obj in get_product_objects(scene):
            obj.hide_set(False)
            obj.hide_viewport = False
            obj.hide_render = False

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            with internal_update_guard():
                studio.use_part_visibility = False
                for p in studio.part_visibilities:
                    p.hide_viewport = False
                    p.hide_render = False

        self.report({'INFO'}, "ID RenderFlo: Unhid all product components")
        return {'FINISHED'}


class RENDERFLO_OT_fix_viewport_compositor(bpy.types.Operator):
    bl_idname = "renderflo.fix_viewport_compositor"
    bl_label = "Toggle Live Viewport Bloom"
    bl_description = "Toggle live Bloom / Glow GPU compositing directly in the 3D Viewport"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        items=[('ALWAYS', "Enable Live Bloom", "Show bloom live in 3D viewport"),
               ('DISABLED', "Disable Viewport Bloom", "Turn off live bloom to optimize viewport performance")],
        default='ALWAYS'
    )

    def execute(self, context):
        set_viewport_compositor_mode(self.mode)
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        status = "enabled (live GPU bloom active)" if self.mode == 'ALWAYS' else "disabled (standard shading)"
        self.report({'INFO'}, f"ID RenderFlo: Live Viewport Bloom {status}")
        return {'FINISHED'}


studio_classes = (
    RENDERFLO_OT_toggle_render_preview,
    RENDERFLO_OT_fix_viewport_compositor,
    RENDERFLO_OT_add_curved_backdrop,
    RENDERFLO_OT_snap_shadow_floor,
    RENDERFLO_OT_add_studio,
    RENDERFLO_OT_make_unique_camera,
    RENDERFLO_OT_set_standard_camera_view,
    RENDERFLO_OT_toggle_camera_ortho,
    RENDERFLO_OT_update_studio,
    RENDERFLO_OT_activate_studio,
    RENDERFLO_OT_move_studio,
    RENDERFLO_OT_capture_studio_transforms,
    RENDERFLO_OT_reset_studio_transforms,
    RENDERFLO_OT_capture_part_visibility,
    RENDERFLO_OT_reset_part_visibility,
    RENDERFLO_OT_remove_studio,
    RENDERFLO_OT_select_target,
    RENDERFLO_OT_activate_gpu_now,
)


def register():
    for cls in studio_classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(studio_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

