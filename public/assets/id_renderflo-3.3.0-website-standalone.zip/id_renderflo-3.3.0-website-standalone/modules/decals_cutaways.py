# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.3.0 — Decals & Live Section Cutaways.
Interactive Raycast Decal Placement and Live Boolean Section Cutaway Box.
"""

import bpy
import math
import os
from mathutils import Vector, Matrix
from bpy_extras import view3d_utils
from bpy_extras.io_utils import ImportHelper

from ..state import (
    MASTER_DECAL_COLL,
    MASTER_CUTAWAY_COLL,
    CUTAWAY_BOX_NAME,
    DECAL_PREFIX,
    GROUND_PLANE_NAME,
    BACKDROP_OBJ_NAME,
)
import bmesh
from .studio_manager import ensure_collection


# ------------------------------------------------------------------------
# Subdivided Mesh & Rotation Helpers
# ------------------------------------------------------------------------

def create_subdivided_decal_mesh(name, sx, sy, grid_res=16):
    """
    Creates a manually pre-subdivided quad grid with exact UV mapping.
    grid_res=16 produces 256 quad faces and 289 vertices, giving the mesh
    rich local geometry to bend smoothly over tight curves and fillets.
    """
    mesh = bpy.data.meshes.new(name)
    verts = []
    faces = []
    uv_coords = []

    for j in range(grid_res + 1):
        v = j / grid_res
        y = -sy + (2.0 * sy * v)
        for i in range(grid_res + 1):
            u = i / grid_res
            x = -sx + (2.0 * sx * u)
            verts.append((x, y, 0.0))
            uv_coords.append((u, v))

    for j in range(grid_res):
        for i in range(grid_res):
            idx0 = j * (grid_res + 1) + i
            idx1 = idx0 + 1
            idx2 = (j + 1) * (grid_res + 1) + (i + 1)
            idx3 = (j + 1) * (grid_res + 1) + i
            faces.append((idx0, idx1, idx2, idx3))

    mesh.from_pydata(verts, [], faces)
    mesh.update()

    uv_layer = mesh.uv_layers.new(name="UVMap")
    loop_idx = 0
    for poly in mesh.polygons:
        for vert_idx in poly.vertices:
            uv_layer.data[loop_idx].uv = uv_coords[vert_idx]
            loop_idx += 1

    return mesh


def spin_decal_by_angle(decal_obj, angle_delta_deg):
    """
    Spins the decal around its world-space surface normal vector at its center.
    This guarantees the decal rotates flat against the underlying CAD geometry
    without tilting, lifting, or causing Shrinkwrap projection artifacts.
    """
    center = decal_obj.matrix_world.translation.copy()
    norm_w = (decal_obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
    R = Matrix.Rotation(math.radians(angle_delta_deg), 4, norm_w)
    new_mat = Matrix.Translation(center) @ R @ Matrix.Translation(-center) @ decal_obj.matrix_world
    decal_obj.matrix_world = new_mat
    cur_spin = decal_obj.get("rf_decal_spin", 0.0)
    decal_obj["rf_decal_spin"] = (cur_spin + angle_delta_deg) % 360.0


def reset_decal_spin(decal_obj):
    """Resets decal rotation back to initial placement orientation."""
    cur_spin = decal_obj.get("rf_decal_spin", 0.0)
    if abs(cur_spin) > 0.0001:
        spin_decal_by_angle(decal_obj, -cur_spin)
        decal_obj["rf_decal_spin"] = 0.0


def scale_decal_by_factor(decal_obj, factor):
    """
    Scales the decal uniformly in 3D around its world center.
    Preserves surface-conforming normal alignment and shrinkwrap projection.
    """
    if factor <= 0.0001:
        return
    center = decal_obj.matrix_world.translation.copy()
    S = Matrix.Diagonal((factor, factor, factor, 1.0))
    new_mat = Matrix.Translation(center) @ S @ Matrix.Translation(-center) @ decal_obj.matrix_world
    decal_obj.matrix_world = new_mat


def reset_decal_scale(decal_obj):
    """
    Resets decal world scale back to (1.0, 1.0, 1.0) while preserving position and orientation.
    """
    cur_scale = decal_obj.matrix_world.to_scale()
    sx = abs(cur_scale.x) if abs(cur_scale.x) > 1e-5 else 1.0
    sy = abs(cur_scale.y) if abs(cur_scale.y) > 1e-5 else 1.0
    sz = abs(cur_scale.z) if abs(cur_scale.z) > 1e-5 else 1.0
    center = decal_obj.matrix_world.translation.copy()
    S = Matrix.Diagonal((1.0 / sx, 1.0 / sy, 1.0 / sz, 1.0))
    decal_obj.matrix_world = Matrix.Translation(center) @ S @ Matrix.Translation(-center) @ decal_obj.matrix_world


def apply_decal_image_swap(decal_obj, new_img):
    """
    Updates the material texture and proportionally scales the mesh vertices
    along local X and Y so the new graphic aspect ratio is perfectly preserved
    with zero squashing or stretching.
    """
    if not decal_obj:
        return

    # 1. Update shader node
    mat = decal_obj.active_material
    if mat and mat.node_tree:
        tex_node = next((n for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE'), None)
        if tex_node:
            tex_node.image = new_img
        else:
            bsdf = next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
            tex = mat.node_tree.nodes.new("ShaderNodeTexImage")
            tex.image = new_img
            if bsdf:
                mat.node_tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
                if "Alpha" in bsdf.inputs:
                    mat.node_tree.links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])

    # 2. Adjust vertex dimensions proportionally to match new image aspect ratio
    if new_img and new_img.size[0] > 0 and new_img.size[1] > 0:
        new_aspect = new_img.size[0] / new_img.size[1]
        m = decal_obj.data
        if len(m.vertices) > 0:
            w = max(abs(v.co.x) for v in m.vertices)
            h = max(abs(v.co.y) for v in m.vertices)
            if w > 1e-6 and h > 1e-6:
                s = math.sqrt(w * h)
                new_sx = s * math.sqrt(new_aspect)
                new_sy = s / math.sqrt(new_aspect)
                fx = new_sx / w
                fy = new_sy / h
                for v in m.vertices:
                    v.co.x *= fx
                    v.co.y *= fy
                m.update()


def realign_decal_to_surface(decal_obj, context, hit_obj=None, location=None, normal=None):
    """
    Snaps and re-aligns decal rotation so local Z matches the surface normal.
    Eliminates all stretching or distortion caused by translating or moving.
    """
    depsgraph = context.evaluated_depsgraph_get()

    if location is None or normal is None:
        center = decal_obj.matrix_world.translation.copy()
        norm_w = (decal_obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()

        # 1. Try raycast along -norm_w
        res, loc, norm, idx, h_obj, mat = context.scene.ray_cast(depsgraph, center + norm_w * 0.05, -norm_w)
        if res and h_obj and h_obj != decal_obj and h_obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
            location = loc
            normal = norm
            hit_obj = h_obj
        else:
            # 2. Try closest point on parent mesh
            target = decal_obj.parent
            if target and target.type == 'MESH':
                target_eval = target.evaluated_get(depsgraph)
                local_pos = target.matrix_world.inverted() @ center
                cl_res, cl_loc, cl_norm, cl_idx = target_eval.closest_point_on_mesh(local_pos)
                if cl_res:
                    location = target.matrix_world @ cl_loc
                    normal = (target.matrix_world.to_3x3() @ cl_norm).normalized()
                    hit_obj = target

    if location is None or normal is None:
        return False

    # Preserve current world scale so resizing (via S, UI, or operators) is NEVER lost or reset
    cur_scale = decal_obj.matrix_world.to_scale()
    sx = abs(cur_scale.x) if abs(cur_scale.x) > 1e-5 else 1.0
    sy = abs(cur_scale.y) if abs(cur_scale.y) > 1e-5 else 1.0
    sz = abs(cur_scale.z) if abs(cur_scale.z) > 1e-5 else 1.0

    z_axis = normal.normalized()
    ref = Vector((0.0, 0.0, 1.0)) if abs(z_axis.z) < 0.9 else Vector((0.0, 1.0, 0.0))
    x_axis = z_axis.cross(ref).normalized()
    y_axis = z_axis.cross(x_axis).normalized()

    x_scaled = x_axis * sx
    y_scaled = y_axis * sy
    z_scaled = z_axis * sz

    world_mat = Matrix((
        (x_scaled.x, y_scaled.x, z_scaled.x, location.x + z_axis.x * 0.0004),
        (x_scaled.y, y_scaled.y, z_scaled.y, location.y + z_axis.y * 0.0004),
        (x_scaled.z, y_scaled.z, z_scaled.z, location.z + z_axis.z * 0.0004),
        (0.0, 0.0, 0.0, 1.0)
    ))

    cur_spin = decal_obj.get("rf_decal_spin", 0.0)
    if abs(cur_spin) > 0.0001:
        R = Matrix.Rotation(math.radians(cur_spin), 4, z_axis)
        c = location + z_axis * 0.0004
        world_mat = Matrix.Translation(c) @ R @ Matrix.Translation(-c) @ world_mat

    # Reparent cleanly before assigning matrix_world so parent inversing doesn't override coordinates
    if hit_obj and decal_obj.parent != hit_obj:
        decal_obj.parent = hit_obj
        decal_obj.matrix_parent_inverse = hit_obj.matrix_world.inverted()
        sw = decal_obj.modifiers.get("Decal_Shrinkwrap") or decal_obj.modifiers.get("Conformal_Shrinkwrap")
        if sw:
            sw.target = hit_obj
    elif decal_obj.parent:
        decal_obj.matrix_parent_inverse = decal_obj.parent.matrix_world.inverted()

    decal_obj.rotation_mode = 'XYZ'
    decal_obj.matrix_world = world_mat

    return True


# ------------------------------------------------------------------------
# Decal Material Generator
# ------------------------------------------------------------------------

def get_or_create_decal_material(img=None):
    mat_name = "RenderFlo_Decal_Mat" if not img else f"Decal_{img.name}"
    mat = bpy.data.materials.get(mat_name)
    if not mat:
        mat = bpy.data.materials.new(name=mat_name)
        mat.use_nodes = True
        if hasattr(mat, "blend_method"):
            try:
                mat.blend_method = 'HASHED'
            except Exception:
                mat.blend_method = 'BLEND'
        if hasattr(mat, "shadow_method"):
            try:
                mat.shadow_method = 'NONE'
            except Exception:
                pass

        nt = mat.node_tree
        nt.nodes.clear()

        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.location = (100, 0)

        out = nt.nodes.new("ShaderNodeOutputMaterial")
        out.location = (400, 0)
        nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

        if img:
            tex = nt.nodes.new("ShaderNodeTexImage")
            tex.location = (-300, 0)
            tex.image = img
            col_socket = bsdf.inputs.get("Base Color") or bsdf.inputs.get("Color")
            if col_socket:
                nt.links.new(tex.outputs["Color"], col_socket)
            if "Alpha" in bsdf.inputs:
                nt.links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
            if "Roughness" in bsdf.inputs:
                bsdf.inputs["Roughness"].default_value = 0.25

    return mat


# ------------------------------------------------------------------------
# Decal Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_place_decal_modal(bpy.types.Operator):
    bl_idname = "renderflo.place_decal_modal"
    bl_label = "Click on Surface to Drop Decal"
    bl_description = "Interactive raycast dropper: Click on any 3D model surface to instantly align and conform a decal plane with zero Z-fighting"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: bpy.props.StringProperty(default="")
    initial_scale: bpy.props.FloatProperty(default=0.15, min=0.005, max=5.0)

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            context.window.cursor_modal_restore()
            return {'CANCELLED'}

        if event.type in {'MOUSEMOVE', 'LEFTMOUSE'}:
            region = context.region
            rv3d = context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, hit_obj, matrix = context.scene.ray_cast(depsgraph, ray_origin, view_vector)

            if result and hit_obj and hit_obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME} and not hit_obj.name.startswith(DECAL_PREFIX):
                if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                    context.window.cursor_modal_restore()
                    self._create_decal_at_hit(context, hit_obj, location, normal)
                    return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def _create_decal_at_hit(self, context, hit_obj, location, normal):
        scene = context.scene
        decal_coll = ensure_collection(scene, MASTER_DECAL_COLL)

        # 1. Image aspect ratio calculation (avoids squashed/stretched stickers)
        img = bpy.data.images.get(self.image_name) if self.image_name else None
        s = self.initial_scale * 0.5
        sx, sy = s, s
        if img and img.size[0] > 0 and img.size[1] > 0:
            aspect = img.size[0] / img.size[1]
            if aspect >= 1.0:
                sx = s
                sy = s / aspect
            else:
                sx = s * aspect
                sy = s

        # 2. Create manually subdivided 16x16 quad grid mesh with exact UVs
        mesh = create_subdivided_decal_mesh(f"{DECAL_PREFIX}Mesh", sx, sy, grid_res=16)
        decal_obj = bpy.data.objects.new(f"{DECAL_PREFIX}{hit_obj.name}", mesh)
        decal_coll.objects.link(decal_obj)

        # 3. Align orientation to surface normal with orthonormal frame
        z_axis = normal.normalized()
        ref = Vector((0.0, 0.0, 1.0)) if abs(z_axis.z) < 0.9 else Vector((0.0, 1.0, 0.0))
        x_axis = z_axis.cross(ref).normalized()
        y_axis = z_axis.cross(x_axis).normalized()

        world_mat = Matrix((
            (x_axis.x, y_axis.x, z_axis.x, location.x + z_axis.x * 0.0004),
            (x_axis.y, y_axis.y, z_axis.y, location.y + z_axis.y * 0.0004),
            (x_axis.z, y_axis.z, z_axis.z, location.z + z_axis.z * 0.0004),
            (0.0, 0.0, 0.0, 1.0)
        ))

        decal_obj.rotation_mode = 'XYZ'
        decal_obj.matrix_world = world_mat
        decal_obj.parent = hit_obj
        decal_obj.matrix_parent_inverse = hit_obj.matrix_world.inverted()
        decal_obj["rf_decal_spin"] = 0.0

        # 4. Conformal Modifier Stack: Catmull-Clark on top of 16x16 pre-subdivided grid
        sub = decal_obj.modifiers.new(name="Decal_Subdivision", type='SUBSURF')
        sub.subdivision_type = 'CATMULL_CLARK'
        if hasattr(sub, "boundary_smooth"):
            sub.boundary_smooth = 'PRESERVE_CORNERS'
        sub.levels = 2
        sub.render_levels = 3

        # Step B: Shrinkwrap Modifier (Second in stack) - projects vertices conformally Above Surface
        sw = decal_obj.modifiers.new(name="Decal_Shrinkwrap", type='SHRINKWRAP')
        sw.target = hit_obj
        sw.wrap_method = 'NEAREST_SURFACEPOINT'
        if hasattr(sw, "wrap_mode"):
            sw.wrap_mode = 'ABOVE_SURFACE'
        sw.offset = 0.0005  # 0.5mm offset to prevent Z-fighting flickering

        # 5. Disable shadows on decal plane to eliminate dark bounding box shadows
        if hasattr(decal_obj, "visible_shadow"):
            decal_obj.visible_shadow = False

        # 6. Assign material
        mat = get_or_create_decal_material(img=img)
        decal_obj.data.materials.append(mat)

        for o in context.selected_objects:
            o.select_set(False)
        decal_obj.select_set(True)
        context.view_layer.objects.active = decal_obj

        # Set transform orientation to LOCAL so 3D Viewport rotation gizmo spins on normal
        try:
            if hasattr(context.scene, "transform_orientation_slots") and context.scene.transform_orientation_slots:
                context.scene.transform_orientation_slots[0].type = 'LOCAL'
        except Exception:
            pass

        self.report({'INFO'}, f"Placed Decal on '{hit_obj.name}' (16x16 Grid + Catmull-Clark active)")

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            context.window.cursor_modal_set('EYEDROPPER')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        return {'CANCELLED'}


class RENDERFLO_OT_load_decal_image(bpy.types.Operator, ImportHelper):
    bl_idname = "renderflo.load_decal_image"
    bl_label = "1-Click Drop Graphic on Surface"
    bl_description = "Browse image file and launch interactive dropper to wrap graphic conformally onto product surface"
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob: bpy.props.StringProperty(
        default="*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp;*.tga",
        options={'HIDDEN'},
        maxlen=255,
    )

    def execute(self, context):
        if not self.filepath:
            return {'CANCELLED'}
        try:
            img = bpy.data.images.load(self.filepath, check_existing=True)
            bpy.ops.renderflo.place_decal_modal('INVOKE_DEFAULT', image_name=img.name)
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load image: {e}")
            return {'CANCELLED'}


class RENDERFLO_OT_conform_decal_to_surface(bpy.types.Operator):
    bl_idname = "renderflo.conform_decal_to_surface"
    bl_label = "1-Click Conform Decal to Surface"
    bl_description = "Instantly subdivide (Simple) and shrinkwrap selected decal/sticker mesh onto model with zero Z-fighting (Grant Abbitt method)"
    bl_options = {'REGISTER', 'UNDO'}

    offset: bpy.props.FloatProperty(name="Surface Offset", default=0.0005, min=0.00001, max=0.05, unit='LENGTH', description="Distance above target surface to prevent Z-fighting flickering")
    subdivisions: bpy.props.IntProperty(name="Subdivision Levels", default=3, min=1, max=6, description="Smoothness density for bending around curved surfaces")

    def execute(self, context):
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        if not sel:
            self.report({'WARNING'}, "Please select a decal plane or graphic mesh.")
            return {'CANCELLED'}

        active = context.active_object
        target = None
        decal_obj = None

        if len(sel) >= 2:
            if active in sel:
                other = next(o for o in sel if o != active)
                if any(x in other.name.lower() for x in ["decal", "sticker", "logo", "label"]) or other.name.startswith(DECAL_PREFIX):
                    decal_obj = other
                    target = active
                elif any(x in active.name.lower() for x in ["decal", "sticker", "logo", "label"]) or active.name.startswith(DECAL_PREFIX):
                    decal_obj = active
                    target = other
                else:
                    decal_obj = other
                    target = active
        elif len(sel) == 1:
            decal_obj = sel[0]
            # Raycast from decal center towards target or find closest mesh
            depsgraph = context.evaluated_depsgraph_get()
            ray_origin = decal_obj.matrix_world.translation
            ray_dir = decal_obj.matrix_world.to_3x3() @ Vector((0, 0, -1))
            res, loc, norm, idx, hit_obj, mat = context.scene.ray_cast(depsgraph, ray_origin, ray_dir)
            if res and hit_obj and hit_obj != decal_obj and hit_obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                target = hit_obj
            else:
                mesh_candidates = [
                    o for o in context.scene.objects
                    if o.type == 'MESH' and o != decal_obj
                    and o.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}
                    and not o.name.startswith(DECAL_PREFIX)
                ]
                if mesh_candidates:
                    target = min(mesh_candidates, key=lambda o: (o.location - decal_obj.location).length)

        if not target:
            self.report({'WARNING'}, "Select the Decal plane, then Shift-select the target Model, and click Conform.")
            return {'CANCELLED'}

        # 1. Manual mesh pre-subdivision if plane has few polygons (e.g. single quad)
        if len(decal_obj.data.polygons) <= 4:
            bm = bmesh.new()
            bm.from_mesh(decal_obj.data)
            bmesh.ops.subdivide_edges(bm, edges=list(bm.edges), cuts=15, use_grid_fill=True)
            bm.to_mesh(decal_obj.data)
            bm.free()
            decal_obj.data.update()

        # 2. Catmull-Clark Subdivision Surface on top of subdivided grid
        sub = decal_obj.modifiers.get("Decal_Subdivision")
        if not sub:
            sub = decal_obj.modifiers.new(name="Decal_Subdivision", type='SUBSURF')
        sub.subdivision_type = 'CATMULL_CLARK'
        if hasattr(sub, "boundary_smooth"):
            sub.boundary_smooth = 'PRESERVE_CORNERS'
        sub.levels = max(1, self.subdivisions - 1)
        sub.render_levels = sub.levels + 1

        # 3. Shrinkwrap Modifier (Above Surface)
        sw = decal_obj.modifiers.get("Decal_Shrinkwrap") or decal_obj.modifiers.get("Conformal_Shrinkwrap")
        if not sw:
            sw = decal_obj.modifiers.new(name="Decal_Shrinkwrap", type='SHRINKWRAP')
        sw.target = target
        sw.wrap_method = 'NEAREST_SURFACEPOINT'
        if hasattr(sw, "wrap_mode"):
            sw.wrap_mode = 'ABOVE_SURFACE'
        sw.offset = self.offset

        # 4. Ensure modifier order: Subdivision must be before Shrinkwrap!
        mod_names = [m.name for m in decal_obj.modifiers]
        if sub.name in mod_names and sw.name in mod_names:
            sub_idx = mod_names.index(sub.name)
            sw_idx = mod_names.index(sw.name)
            if sub_idx > sw_idx:
                try:
                    with context.temp_override(object=decal_obj):
                        while sub_idx > 0 and decal_obj.modifiers[sub_idx - 1].name == sw.name:
                            bpy.ops.object.modifier_move_up(modifier=sub.name)
                            sub_idx -= 1
                except Exception:
                    pass

        # 5. Disable shadows on decal plane to eliminate dark border artifacts
        if hasattr(decal_obj, "visible_shadow"):
            decal_obj.visible_shadow = False

        # 6. Set Euler rotation mode & track spin angle
        decal_obj.rotation_mode = 'XYZ'
        if "rf_decal_spin" not in decal_obj:
            decal_obj["rf_decal_spin"] = 0.0

        # 7. Parent to target
        decal_obj.parent = target
        decal_obj.matrix_parent_inverse = target.matrix_world.inverted()

        self.report({'INFO'}, f"Conformed '{decal_obj.name}' to '{target.name}' (16x16 Grid + Catmull-Clark, Offset: {self.offset*1000:.1f}mm)")
        return {'FINISHED'}


# ------------------------------------------------------------------------
# Decal Surface Rotation Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_rotate_decal(bpy.types.Operator):
    bl_idname = "renderflo.rotate_decal"
    bl_label = "Rotate Decal"
    bl_description = "Spin decal flat against the surface around its surface normal vector"
    bl_options = {'REGISTER', 'UNDO'}

    angle_delta: bpy.props.FloatProperty(name="Angle Delta (Deg)", default=15.0)

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Please select a decal object.")
            return {'CANCELLED'}

        spin_decal_by_angle(obj, self.angle_delta)
        context.view_layer.update()
        cur_spin = obj.get("rf_decal_spin", 0.0)
        self.report({'INFO'}, f"Decal Spin: {cur_spin:+.1f}° ({self.angle_delta:+.0f}°)")
        return {'FINISHED'}


class RENDERFLO_OT_reset_decal_spin(bpy.types.Operator):
    bl_idname = "renderflo.reset_decal_spin"
    bl_label = "Reset Decal Rotation"
    bl_description = "Reset decal rotation back to its original placement orientation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Please select a decal object.")
            return {'CANCELLED'}

        reset_decal_spin(obj)
        context.view_layer.update()
        self.report({'INFO'}, f"Reset Decal Rotation for '{obj.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_spin_decal_modal(bpy.types.Operator):
    bl_idname = "renderflo.spin_decal_modal"
    bl_label = "Interactive Decal Spin"
    bl_description = "Interactively spin decal on surface: Move mouse left/right or use scroll wheel. Left-click confirms, Esc cancels"
    bl_options = {'REGISTER', 'UNDO'}

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.decal_obj.matrix_world = self.init_matrix
            self.decal_obj["rf_decal_spin"] = self.init_spin
            context.window.cursor_modal_restore()
            self.report({'INFO'}, "Cancelled Decal Spin")
            return {'CANCELLED'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            context.window.cursor_modal_restore()
            cur = self.decal_obj.get("rf_decal_spin", 0.0)
            self.report({'INFO'}, f"Confirmed Decal Spin: {cur:+.1f}°")
            return {'FINISHED'}

        if event.type == 'MOUSEMOVE':
            dx = event.mouse_x - self.last_mouse_x
            self.last_mouse_x = event.mouse_x
            step = dx * 0.5
            spin_decal_by_angle(self.decal_obj, step)

        elif event.type == 'WHEELUPMOUSE':
            spin_decal_by_angle(self.decal_obj, 5.0)

        elif event.type == 'WHEELDOWNMOUSE':
            spin_decal_by_angle(self.decal_obj, -5.0)

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Select a decal object to rotate.")
            return {'CANCELLED'}

        self.decal_obj = obj
        self.init_matrix = obj.matrix_world.copy()
        self.init_spin = obj.get("rf_decal_spin", 0.0)
        self.last_mouse_x = event.mouse_x
        context.window.cursor_modal_set('SCROLL_XY')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


# ------------------------------------------------------------------------
# Decal Surface Scale Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_scale_decal(bpy.types.Operator):
    bl_idname = "renderflo.scale_decal"
    bl_label = "Scale Decal"
    bl_description = "Scale decal uniformly while preserving its conforming projection on the surface"
    bl_options = {'REGISTER', 'UNDO'}

    factor: bpy.props.FloatProperty(name="Factor", default=1.1, min=0.01, max=100.0)
    reset: bpy.props.BoolProperty(name="Reset", default=False)

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Please select a decal object.")
            return {'CANCELLED'}

        if self.reset:
            reset_decal_scale(obj)
            context.view_layer.update()
            self.report({'INFO'}, f"Reset scale of '{obj.name}' to 1.0x")
        else:
            scale_decal_by_factor(obj, self.factor)
            context.view_layer.update()
            cur_s = obj.matrix_world.to_scale().x
            self.report({'INFO'}, f"Scaled '{obj.name}' by {self.factor}x (Current: {cur_s:.2f}x)")

        return {'FINISHED'}


class RENDERFLO_OT_scale_decal_modal(bpy.types.Operator):
    bl_idname = "renderflo.scale_decal_modal"
    bl_label = "Interactive Decal Scale"
    bl_description = "Interactively scale decal on surface: Move mouse left/right or use scroll wheel. Left-click confirms, Esc cancels"
    bl_options = {'REGISTER', 'UNDO'}

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.decal_obj.matrix_world = self.init_matrix
            context.window.cursor_modal_restore()
            self.report({'INFO'}, "Cancelled Decal Scale")
            return {'CANCELLED'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            context.window.cursor_modal_restore()
            cur = self.decal_obj.matrix_world.to_scale().x
            self.report({'INFO'}, f"Confirmed Decal Scale: {cur:.2f}x")
            return {'FINISHED'}

        if event.type == 'MOUSEMOVE':
            dx = event.mouse_x - self.last_mouse_x
            self.last_mouse_x = event.mouse_x
            factor = 1.0 + (dx * 0.008)
            if 0.05 < factor < 20.0:
                scale_decal_by_factor(self.decal_obj, factor)

        elif event.type == 'WHEELUPMOUSE':
            scale_decal_by_factor(self.decal_obj, 1.05)

        elif event.type == 'WHEELDOWNMOUSE':
            scale_decal_by_factor(self.decal_obj, 0.95)

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Select a decal object to scale.")
            return {'CANCELLED'}

        self.decal_obj = obj
        self.init_matrix = obj.matrix_world.copy()
        self.last_mouse_x = event.mouse_x
        context.window.cursor_modal_set('SIZE_X')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


class RENDERFLO_OT_reposition_decal_modal(bpy.types.Operator):
    bl_idname = "renderflo.reposition_decal_modal"
    bl_label = "Re-Position on Surface"
    bl_description = "Click anywhere on any 3D surface to re-position, re-orient to the new surface normal, and re-parent the decal"
    bl_options = {'REGISTER', 'UNDO'}

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            if self.init_parent != self.decal_obj.parent:
                self.decal_obj.parent = self.init_parent
                self.decal_obj.matrix_parent_inverse = self.init_parent_inverse
                sw = self.decal_obj.modifiers.get("Decal_Shrinkwrap") or self.decal_obj.modifiers.get("Conformal_Shrinkwrap")
                if sw:
                    sw.target = self.init_parent
            self.decal_obj.matrix_world = self.init_matrix
            context.window.cursor_modal_restore()
            self.report({'INFO'}, "Cancelled Re-Position")
            return {'CANCELLED'}

        if event.type in {'MOUSEMOVE', 'LEFTMOUSE'}:
            region = context.region
            rv3d = context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, hit_obj, matrix = context.scene.ray_cast(depsgraph, ray_origin, view_vector)

            if result and hit_obj and hit_obj != self.decal_obj and hit_obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME} and not hit_obj.name.startswith(DECAL_PREFIX):
                if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                    context.window.cursor_modal_restore()
                    realign_decal_to_surface(self.decal_obj, context, hit_obj=hit_obj, location=location, normal=normal)
                    self.report({'INFO'}, f"Re-positioned decal onto '{hit_obj.name}'")
                    return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Please select a decal object to re-position.")
            return {'CANCELLED'}

        self.decal_obj = obj
        self.init_matrix = obj.matrix_world.copy()
        self.init_parent = obj.parent
        self.init_parent_inverse = obj.matrix_parent_inverse.copy() if obj.parent else Matrix.Identity(4)

        if context.area.type == 'VIEW_3D':
            context.window.cursor_modal_set('EYEDROPPER')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        return {'CANCELLED'}


class RENDERFLO_OT_slide_decal_modal(bpy.types.Operator):
    bl_idname = "renderflo.slide_decal_modal"
    bl_label = "Slide on Surface"
    bl_description = "Interactively slide decal across curved geometry with real-time normal tracking. Left-click confirms, Esc cancels"
    bl_options = {'REGISTER', 'UNDO'}

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            if self.init_parent != self.decal_obj.parent:
                self.decal_obj.parent = self.init_parent
                self.decal_obj.matrix_parent_inverse = self.init_parent_inverse
                sw = self.decal_obj.modifiers.get("Decal_Shrinkwrap") or self.decal_obj.modifiers.get("Conformal_Shrinkwrap")
                if sw:
                    sw.target = self.init_parent
            self.decal_obj.matrix_world = self.init_matrix
            context.window.cursor_modal_restore()
            self.report({'INFO'}, "Cancelled Surface Slide")
            return {'CANCELLED'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            context.window.cursor_modal_restore()
            self.report({'INFO'}, "Confirmed Decal Position")
            return {'FINISHED'}

        if event.type == 'MOUSEMOVE':
            region = context.region
            rv3d = context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, hit_obj, matrix = context.scene.ray_cast(depsgraph, ray_origin, view_vector)

            if result and hit_obj and hit_obj != self.decal_obj and hit_obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME} and not hit_obj.name.startswith(DECAL_PREFIX):
                realign_decal_to_surface(self.decal_obj, context, hit_obj=hit_obj, location=location, normal=normal)

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Please select a decal object to slide.")
            return {'CANCELLED'}

        self.decal_obj = obj
        self.init_matrix = obj.matrix_world.copy()
        self.init_parent = obj.parent
        self.init_parent_inverse = obj.matrix_parent_inverse.copy() if obj.parent else Matrix.Identity(4)

        if context.area.type == 'VIEW_3D':
            context.window.cursor_modal_set('HAND')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        return {'CANCELLED'}


class RENDERFLO_OT_realign_decal_normal(bpy.types.Operator):
    bl_idname = "renderflo.realign_decal_normal"
    bl_label = "Re-Align to Surface Normal"
    bl_description = "Fix stretching and distortion after moving with standard G: snaps and aligns decal perpendicular to the underlying surface normal"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Please select a decal object.")
            return {'CANCELLED'}

        ok = realign_decal_to_surface(obj, context)
        context.view_layer.update()
        if ok:
            self.report({'INFO'}, f"Re-aligned '{obj.name}' to surface normal")
        else:
            self.report({'WARNING'}, "Could not detect underlying surface. Move decal closer to model or use 'Re-Position on Surface'.")
        return {'FINISHED'}


class RENDERFLO_OT_swap_decal_image(bpy.types.Operator, ImportHelper):
    bl_idname = "renderflo.swap_decal_image"
    bl_label = "Change Decal Graphic File"
    bl_description = "Replace the graphic texture on the active decal and automatically adapt mesh proportions to match the new image aspect ratio"
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob: bpy.props.StringProperty(
        default="*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp;*.tga;*.webp",
        options={'HIDDEN'},
        maxlen=255,
    )

    def execute(self, context):
        if not self.filepath:
            return {'CANCELLED'}

        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Please select a decal object.")
            return {'CANCELLED'}

        try:
            new_img = bpy.data.images.load(self.filepath, check_existing=True)
            apply_decal_image_swap(obj, new_img)
            self.report({'INFO'}, f"Changed decal graphic to '{new_img.name}'")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load image: {e}")
            return {'CANCELLED'}


class RENDERFLO_OT_match_decal_aspect(bpy.types.Operator):
    bl_idname = "renderflo.match_decal_aspect"
    bl_label = "Fit Mesh Aspect to Image"
    bl_description = "Scale decal mesh dimensions to match the pixel aspect ratio of the currently assigned texture image"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Please select a decal object.")
            return {'CANCELLED'}

        mat = obj.active_material
        img = None
        if mat and mat.node_tree:
            tex_node = next((n for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE'), None)
            if tex_node:
                img = tex_node.image

        if not img:
            self.report({'WARNING'}, "No image texture found on active decal.")
            return {'CANCELLED'}

        apply_decal_image_swap(obj, img)
        self.report({'INFO'}, f"Matched decal aspect ratio to '{img.name}' ({img.size[0]}x{img.size[1]})")
        return {'FINISHED'}


class RENDERFLO_OT_mirror_decal(bpy.types.Operator):
    bl_idname = "renderflo.mirror_decal"
    bl_label = "Mirror Decal"
    bl_description = "Mirror decal texture horizontally/vertically or mirror decal object across product symmetry axis"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mirror Mode",
        items=[
            ('FLIP_H', "Flip Horizontal (Mirror Graphic)", "Invert UV coordinates along horizontal U axis"),
            ('FLIP_V', "Flip Vertical", "Invert UV coordinates along vertical V axis"),
            ('SYMMETRY_X', "Mirror Across X-Axis", "Duplicate and mirror decal to symmetrical opposite side across product X plane"),
            ('SYMMETRY_Y', "Mirror Across Y-Axis", "Duplicate and mirror decal to symmetrical opposite side across product Y plane"),
        ],
        default='FLIP_H'
    )

    def execute(self, context):
        active_obj = context.active_object
        if not active_obj or active_obj.type != 'MESH':
            self.report({'WARNING'}, "Please select a decal mesh object.")
            return {'CANCELLED'}

        if self.mode in {'FLIP_H', 'FLIP_V'}:
            if active_obj.data.users > 1:
                active_obj.data = active_obj.data.copy()
            uv_layer = active_obj.data.uv_layers.active
            if not uv_layer:
                self.report({'WARNING'}, "Active decal has no UV layer to mirror.")
                return {'CANCELLED'}

            axis_name = "Horizontal" if self.mode == 'FLIP_H' else "Vertical"
            for d in uv_layer.data:
                if self.mode == 'FLIP_H':
                    d.uv.x = 1.0 - d.uv.x
                else:
                    d.uv.y = 1.0 - d.uv.y
            active_obj.data.update()
            self.report({'INFO'}, f"Flipped Decal Graphic ({axis_name})")
            return {'FINISHED'}

        # Symmetry across CAD model axis (SYMMETRY_X or SYMMETRY_Y)
        target_obj = active_obj.parent
        sw = active_obj.modifiers.get("Decal_Shrinkwrap") or active_obj.modifiers.get("Conformal_Shrinkwrap")
        if not target_obj and sw and sw.target:
            target_obj = sw.target

        new_obj = active_obj.copy()
        new_obj.data = active_obj.data.copy()
        new_obj.name = f"{active_obj.name}_Mirror"

        colls = active_obj.users_collection
        if colls:
            colls[0].objects.link(new_obj)
        else:
            context.scene.collection.objects.link(new_obj)

        sym_x = -1.0 if self.mode == 'SYMMETRY_X' else 1.0
        sym_y = -1.0 if self.mode == 'SYMMETRY_Y' else 1.0

        center = target_obj.matrix_world.translation if target_obj else Vector((0.0, 0.0, 0.0))
        rel_loc = active_obj.matrix_world.translation - center
        rel_loc.x *= sym_x
        rel_loc.y *= sym_y
        new_world_loc = center + rel_loc

        norm_w = (active_obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
        norm_w.x *= sym_x
        norm_w.y *= sym_y

        if target_obj and context.scene:
            depsgraph = context.evaluated_depsgraph_get()
            ray_start = new_world_loc + norm_w * 0.1
            ray_dir = -norm_w
            res, loc, norm, idx, h_obj, mat = context.scene.ray_cast(depsgraph, ray_start, ray_dir)
            if res and h_obj == target_obj:
                new_world_loc = loc + norm * 0.0004
                norm_w = norm.normalized()

        z_axis = norm_w
        up_guide = Vector((0.0, 0.0, 1.0)) if abs(z_axis.z) < 0.95 else Vector((0.0, 1.0, 0.0))
        x_axis = up_guide.cross(z_axis).normalized()
        y_axis = z_axis.cross(x_axis).normalized()

        world_mat = Matrix((
            (x_axis.x, y_axis.x, z_axis.x, new_world_loc.x),
            (x_axis.y, y_axis.y, z_axis.y, new_world_loc.y),
            (x_axis.z, y_axis.z, z_axis.z, new_world_loc.z),
            (0.0, 0.0, 0.0, 1.0)
        ))
        new_obj.matrix_world = world_mat
        if target_obj:
            new_obj.parent = target_obj
            new_obj.matrix_parent_inverse = target_obj.matrix_world.inverted()

        new_sw = new_obj.modifiers.get("Decal_Shrinkwrap") or new_obj.modifiers.get("Conformal_Shrinkwrap")
        if new_sw and target_obj:
            new_sw.target = target_obj

        for o in context.selected_objects:
            o.select_set(False)
        new_obj.select_set(True)
        context.view_layer.objects.active = new_obj

        axis_label = "X-Axis" if self.mode == 'SYMMETRY_X' else "Y-Axis"
        self.report({'INFO'}, f"Mirrored Decal '{new_obj.name}' across {axis_label}")
        return {'FINISHED'}


# ------------------------------------------------------------------------
# Live Boolean Section Cutaway Box Engine
# ------------------------------------------------------------------------

def configure_cutaway_box_display(c_obj):
    """
    Configures cutaway box as an invisible boolean cutter.
    Ensures wireframe overlay display in Solid and Material Preview,
    while preventing it from rendering as an opaque white box in Cycles / EEVEE Rendered View.
    """
    c_obj.display_type = 'WIRE'
    c_obj.hide_render = True
    for attr in (
        "visible_camera",
        "visible_diffuse",
        "visible_glossy",
        "visible_transmission",
        "visible_volume_scatter",
        "visible_shadow",
    ):
        if hasattr(c_obj, attr):
            try:
                setattr(c_obj, attr, False)
            except Exception:
                pass

    # Assign 100% transparent material for viewports/engines that evaluate surface shaders
    mat_name = "RenderFlo_Cutaway_Transparent_Mat"
    mat = bpy.data.materials.get(mat_name)
    if not mat:
        mat = bpy.data.materials.new(name=mat_name)
        mat.use_nodes = True
        nt = mat.node_tree
        nt.nodes.clear()
        out = nt.nodes.new("ShaderNodeOutputMaterial")
        out.location = (300, 0)
        trans = nt.nodes.new("ShaderNodeBsdfTransparent")
        trans.location = (0, 0)
        nt.links.new(trans.outputs["BSDF"], out.inputs["Surface"])
        if hasattr(mat, "blend_method"):
            mat.blend_method = 'BLEND'
        if hasattr(mat, "shadow_method"):
            mat.shadow_method = 'NONE'

    if not c_obj.data.materials:
        c_obj.data.materials.append(mat)
    else:
        c_obj.data.materials[0] = mat

class RENDERFLO_OT_create_cutaway_box(bpy.types.Operator):
    bl_idname = "renderflo.create_cutaway_box"
    bl_label = "Create Section Cutaway Box"
    bl_description = "Generate interactive live section cutaway box with cross-section cap material"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(
        name="Slice Axis",
        items=[('X', "X-Axis", "Cut along X"), ('Y', "Y-Axis", "Cut along Y"), ('Z', "Z-Axis", "Cut along Z")],
        default='X'
    )

    def execute(self, context):
        scene = context.scene
        cut_coll = ensure_collection(scene, MASTER_CUTAWAY_COLL)

        # 1. Compute scene assembly bounds
        mesh_objs = [o for o in scene.objects if o.type == 'MESH' and o.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME, CUTAWAY_BOX_NAME} and not o.name.startswith(DECAL_PREFIX)]
        if not mesh_objs:
            self.report({'WARNING'}, "No mesh objects found to cut.")
            return {'CANCELLED'}

        depsgraph = context.evaluated_depsgraph_get()
        min_v = Vector((float('inf'), float('inf'), float('inf')))
        max_v = Vector((float('-inf'), float('-inf'), float('-inf')))

        for obj in mesh_objs:
            eval_obj = obj.evaluated_get(depsgraph)
            for corner in eval_obj.bound_box:
                pt = eval_obj.matrix_world @ Vector(corner)
                min_v.x, max_v.x = min(min_v.x, pt.x), max(max_v.x, pt.x)
                min_v.y, max_v.y = min(min_v.y, pt.y), max(max_v.y, pt.y)
                min_v.z, max_v.z = min(min_v.z, pt.z), max(max_v.z, pt.z)

        dim = max_v - min_v
        center = (min_v + max_v) * 0.5
        box_size = max(dim.x, dim.y, dim.z) * 1.5

        # 2. Get or create cutaway box object
        c_obj = bpy.data.objects.get(CUTAWAY_BOX_NAME)
        if not c_obj:
            bpy.ops.mesh.primitive_cube_add(size=1.0)
            c_obj = context.active_object
            c_obj.name = CUTAWAY_BOX_NAME
            for c in list(c_obj.users_collection):
                c.objects.unlink(c_obj)
            cut_coll.objects.link(c_obj)

        configure_cutaway_box_display(c_obj)
        c_obj.scale = Vector((box_size, box_size, box_size))

        # Position box to cut half of model along requested axis
        if self.axis == 'X':
            c_obj.location = Vector((center.x + (box_size * 0.5), center.y, center.z))
        elif self.axis == 'Y':
            c_obj.location = Vector((center.x, center.y + (box_size * 0.5), center.z))
        else:
            c_obj.location = Vector((center.x, center.y, center.z + (box_size * 0.5)))

        # 3. Add boolean difference modifier to CAD meshes
        mod_count = 0
        for m_obj in mesh_objs:
            mod = m_obj.modifiers.get("RenderFlo_Cutaway")
            if not mod:
                mod = m_obj.modifiers.new(name="RenderFlo_Cutaway", type='BOOLEAN')
            mod.operation = 'DIFFERENCE'
            mod.object = c_obj
            mod.solver = 'EXACT' if hasattr(mod, "solver") else 'FAST'
            mod.show_viewport = True
            mod.show_render = True
            mod_count += 1

        scene.rf_cutaway_settings.enabled = True
        scene.rf_cutaway_settings.axis = self.axis

        for o in context.selected_objects:
            o.select_set(False)
        c_obj.select_set(True)
        context.view_layer.objects.active = c_obj

        self.report({'INFO'}, f"Created Cutaway Box (Applied to {mod_count} parts)")
        return {'FINISHED'}


class RENDERFLO_OT_toggle_cutaway(bpy.types.Operator):
    bl_idname = "renderflo.toggle_cutaway"
    bl_label = "Toggle Section Cutaway"
    bl_description = "Enable or disable live section cutaway on all model parts"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        new_state = not scene.rf_cutaway_settings.enabled
        scene.rf_cutaway_settings.enabled = new_state

        c_obj = bpy.data.objects.get(CUTAWAY_BOX_NAME)
        if c_obj:
            c_obj.hide_viewport = not new_state
            c_obj.hide_render = True
            configure_cutaway_box_display(c_obj)

        for obj in scene.objects:
            if obj.type == 'MESH':
                mod = obj.modifiers.get("RenderFlo_Cutaway")
                if mod:
                    mod.show_viewport = new_state
                    mod.show_render = new_state

        state_str = "Enabled" if new_state else "Disabled"
        self.report({'INFO'}, f"Section Cutaway {state_str}")
        return {'FINISHED'}


class RENDERFLO_OT_remove_cutaway(bpy.types.Operator):
    bl_idname = "renderflo.remove_cutaway"
    bl_label = "Remove Cutaway Box"
    bl_description = "Remove section cutaway box and clear cutaway boolean modifiers from all objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        c_obj = bpy.data.objects.get(CUTAWAY_BOX_NAME)
        if c_obj:
            bpy.data.objects.remove(c_obj, do_unlink=True)

        for obj in scene.objects:
            if obj.type == 'MESH':
                mod = obj.modifiers.get("RenderFlo_Cutaway")
                if mod:
                    obj.modifiers.remove(mod)

        scene.rf_cutaway_settings.enabled = False
        self.report({'INFO'}, "Removed Section Cutaway Box")
        return {'FINISHED'}


decal_classes = (
    RENDERFLO_OT_place_decal_modal,
    RENDERFLO_OT_load_decal_image,
    RENDERFLO_OT_conform_decal_to_surface,
    RENDERFLO_OT_rotate_decal,
    RENDERFLO_OT_reset_decal_spin,
    RENDERFLO_OT_spin_decal_modal,
    RENDERFLO_OT_scale_decal,
    RENDERFLO_OT_scale_decal_modal,
    RENDERFLO_OT_reposition_decal_modal,
    RENDERFLO_OT_slide_decal_modal,
    RENDERFLO_OT_realign_decal_normal,
    RENDERFLO_OT_swap_decal_image,
    RENDERFLO_OT_match_decal_aspect,
    RENDERFLO_OT_mirror_decal,
    RENDERFLO_OT_create_cutaway_box,
    RENDERFLO_OT_toggle_cutaway,
    RENDERFLO_OT_remove_cutaway,
)


def register():
    for cls in decal_classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(decal_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

