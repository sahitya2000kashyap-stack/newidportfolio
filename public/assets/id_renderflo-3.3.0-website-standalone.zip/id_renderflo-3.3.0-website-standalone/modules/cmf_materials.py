# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.3.0 — CMF (Color, Material, Finish) Matrix & Procedural Industrial Materials.
Preserves CMF snapshots across studios and generates procedural manufacturing finishes:
VDI 3400 Mold-Tech, Anodized Aluminum, Brushed Metal, Soft-Touch Silicone, Clear PC, and Speaker Grills.
"""

import bpy
import math

from ..state import (
    GROUND_PLANE_NAME,
    BACKDROP_OBJ_NAME,
    is_internal_update,
    internal_update_guard,
)


# ------------------------------------------------------------------------
# Material Recording & Restoration Engine
# ------------------------------------------------------------------------

def record_materials_into_collection(scene, mat_collection_prop):
    mat_collection_prop.clear()
    for obj in list(scene.objects):
        if obj.name in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
            continue
        if obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT'} and len(obj.material_slots) > 0:
            obj_item = mat_collection_prop.add()
            obj_item.object_name = obj.name
            for idx, slot in enumerate(obj.material_slots):
                slot_item = obj_item.slots.add()
                slot_item.slot_index = idx
                slot_item.material_name = slot.material.name if slot.material else ""


def restore_materials_from_collection(mat_collection_prop):
    for obj_item in mat_collection_prop:
        obj = bpy.data.objects.get(obj_item.object_name)
        if not obj:
            # Fallback to match by base name without duplicate numerical suffixes
            clean_name = obj_item.object_name.split('.')[0]
            for candidate in bpy.data.objects:
                if candidate.name.split('.')[0] == clean_name and candidate.type in {'MESH', 'CURVE', 'SURFACE'}:
                    obj = candidate
                    break
        if not obj or obj.type not in {'MESH', 'CURVE', 'SURFACE'}:
            continue

        for slot_item in obj_item.slots:
            mat = bpy.data.materials.get(slot_item.material_name) if slot_item.material_name else None
            idx = slot_item.slot_index

            # Auto-extend material slots if object has fewer slots
            while len(obj.material_slots) <= idx:
                obj.data.materials.append(None)

            if idx < len(obj.material_slots):
                obj.material_slots[idx].material = mat


def ensure_default_cmf(scene):
    """Ensure there is at least one CMF preset named 'Default', migrating legacy keywords."""
    for c in scene.rf_cmf_presets:
        if c.name in {'CMF_01_Default', 'CMF_01'}:
            c.name = "Default"
    for s in scene.rf_studios:
        if s.cmf_mode in {'CMF_01_Default', 'CMF_01', 'NONE', 'CUSTOM'}:
            s.cmf_mode = "Default"
    if hasattr(scene, "rf_active_cmf_enum") and scene.rf_active_cmf_enum in {'CMF_01_Default', 'CMF_01', 'NONE', 'CUSTOM'}:
        with internal_update_guard():
            try:
                scene.rf_active_cmf_enum = "Default"
            except Exception:
                pass

    if len(scene.rf_cmf_presets) == 0:
        first_cmf = scene.rf_cmf_presets.add()
        first_cmf.name = "Default"
        record_materials_into_collection(scene, first_cmf.object_materials)
        return first_cmf
    return scene.rf_cmf_presets[0]


def sync_studio_cmf_toggles(scene, studio):
    ensure_default_cmf(scene)
    existing_map = {t.cmf_name: t.enabled for t in studio.cmf_matrix_toggles}
    studio.cmf_matrix_toggles.clear()
    for cmf in scene.rf_cmf_presets:
        t = studio.cmf_matrix_toggles.add()
        t.cmf_name = cmf.name
        t.enabled = existing_map.get(cmf.name, True)


def apply_cmf_to_scene(scene, studio):
    if not studio.use_materials:
        return
    ensure_default_cmf(scene)
    target_name = studio.cmf_mode if (studio.cmf_mode and studio.cmf_mode not in {'NONE', 'CUSTOM'}) else "Default"
    cmf = next((c for c in scene.rf_cmf_presets if c.name == target_name), None)
    if not cmf and len(scene.rf_cmf_presets) > 0:
        cmf = scene.rf_cmf_presets[0]
    if cmf:
        restore_materials_from_collection(cmf.object_materials)
        with internal_update_guard():
            try:
                scene.rf_active_cmf_enum = cmf.name
                studio.cmf_mode = cmf.name
            except Exception:
                pass


def on_studio_cmf_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    sync_studio_cmf_toggles(context.scene, self)
    apply_cmf_to_scene(context.scene, self)


def on_studio_use_materials_change(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    sync_studio_cmf_toggles(context.scene, self)
    if self.use_materials:
        apply_cmf_to_scene(context.scene, self)


# ------------------------------------------------------------------------
# Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_sync_cmf_matrix(bpy.types.Operator):
    bl_idname = "renderflo.sync_cmf_matrix"
    bl_label = "Sync Colorway Matrix List"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        for s in scene.rf_studios:
            sync_studio_cmf_toggles(scene, s)
        return {'FINISHED'}


class RENDERFLO_OT_clone_active_material(bpy.types.Operator):
    bl_idname = "renderflo.clone_active_material"
    bl_label = "Clone Slot Material as New"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.active_material:
            self.report({'WARNING'}, "Select an object with an active material slot first.")
            return {'CANCELLED'}

        orig_mat = obj.active_material
        new_mat = orig_mat.copy()
        new_mat.name = f"{orig_mat.name}_Var"
        obj.active_material = new_mat
        self.report({'INFO'}, f"Cloned material to '{new_mat.name}' on {obj.name}")
        return {'FINISHED'}


class RENDERFLO_OT_save_new_cmf(bpy.types.Operator):
    bl_idname = "renderflo.save_new_cmf"
    bl_label = "Save Current Materials as New CMF"
    bl_options = {'REGISTER', 'UNDO'}

    cmf_name: bpy.props.StringProperty(name="CMF Name", default="CMF_New_Colorway")

    def invoke(self, context, event):
        self.cmf_name = f"CMF_{len(context.scene.rf_cmf_presets) + 1:02d}"
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene
        new_cmf = scene.rf_cmf_presets.add()
        existing_names = {c.name for c in scene.rf_cmf_presets if c != new_cmf}
        base_name = self.cmf_name
        counter = 1
        while base_name in existing_names:
            base_name = f"{self.cmf_name}_{counter}"
            counter += 1
        new_cmf.name = base_name
        record_materials_into_collection(scene, new_cmf.object_materials)

        for s in scene.rf_studios:
            sync_studio_cmf_toggles(scene, s)

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            scene.rf_studios[scene.rf_studio_index].cmf_mode = new_cmf.name

        with internal_update_guard():
            try:
                scene.rf_active_cmf_enum = new_cmf.name
            except Exception:
                pass

        self.report({'INFO'}, f"Created CMF Colorway: '{new_cmf.name}'")
        return {'FINISHED'}


class RENDERFLO_OT_update_active_cmf(bpy.types.Operator):
    bl_idname = "renderflo.update_active_cmf"
    bl_label = "Overwrite CMF Preset with Current Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        ensure_default_cmf(scene)
        target_name = scene.rf_active_cmf_enum if hasattr(scene, "rf_active_cmf_enum") else "Default"
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if studio.cmf_mode and studio.cmf_mode not in {'NONE', 'CUSTOM'}:
                target_name = studio.cmf_mode

        cmf = next((c for c in scene.rf_cmf_presets if c.name == target_name), None)
        if not cmf:
            cmf = scene.rf_cmf_presets[0]
        if cmf:
            record_materials_into_collection(scene, cmf.object_materials)
            self.report({'INFO'}, f"Updated '{cmf.name}' with current product materials")
        return {'FINISHED'}


class RENDERFLO_OT_rename_cmf(bpy.types.Operator):
    bl_idname = "renderflo.rename_cmf"
    bl_label = "Rename CMF Colorway"
    bl_description = "Change the name of this CMF Colorway and update all studios"
    bl_options = {'REGISTER', 'UNDO'}

    target_cmf_name: bpy.props.StringProperty(name="Target CMF", default="")
    new_name: bpy.props.StringProperty(name="New Colorway Name", default="")

    def invoke(self, context, event):
        scene = context.scene
        ensure_default_cmf(scene)
        if not self.target_cmf_name:
            if hasattr(scene, "rf_active_cmf_enum") and scene.rf_active_cmf_enum:
                self.target_cmf_name = scene.rf_active_cmf_enum
            elif 0 <= scene.rf_studio_index < len(scene.rf_studios):
                st = scene.rf_studios[scene.rf_studio_index]
                if st.cmf_mode:
                    self.target_cmf_name = st.cmf_mode

        if not self.target_cmf_name:
            if len(scene.rf_cmf_presets) > 0:
                self.target_cmf_name = scene.rf_cmf_presets[0].name
            else:
                self.report({'WARNING'}, "No CMF Colorway preset available to rename.")
                return {'CANCELLED'}

        self.new_name = self.target_cmf_name
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label(text=f"Rename '{self.target_cmf_name}':", icon='COLOR')
        col.prop(self, "new_name", text="Name")

    def execute(self, context):
        scene = context.scene
        old_name = self.target_cmf_name.strip()
        if not old_name:
            if hasattr(scene, "rf_active_cmf_enum") and scene.rf_active_cmf_enum:
                old_name = scene.rf_active_cmf_enum
            elif len(scene.rf_cmf_presets) > 0:
                old_name = scene.rf_cmf_presets[0].name
        new_name = self.new_name.strip()

        if not new_name:
            self.report({'ERROR'}, "Colorway name cannot be empty.")
            return {'CANCELLED'}

        if new_name == old_name:
            return {'FINISHED'}

        if any(c.name == new_name for c in scene.rf_cmf_presets if c.name != old_name):
            self.report({'ERROR'}, f"A colorway named '{new_name}' already exists.")
            return {'CANCELLED'}

        target_cmf = next((c for c in scene.rf_cmf_presets if c.name == old_name), None)
        if not target_cmf:
            self.report({'WARNING'}, f"Colorway '{old_name}' not found.")
            return {'CANCELLED'}

        # 1. Update preset name
        target_cmf.name = new_name

        # 2. Update studio references & matrix toggles
        for s in scene.rf_studios:
            if s.cmf_mode == old_name:
                s.cmf_mode = new_name
            for t in s.cmf_matrix_toggles:
                if t.cmf_name == old_name:
                    t.cmf_name = new_name

        # 3. Update scene active CMF enum
        with internal_update_guard():
            try:
                if scene.rf_active_cmf_enum == old_name:
                    scene.rf_active_cmf_enum = new_name
            except Exception:
                pass

        self.report({'INFO'}, f"Renamed CMF Colorway: '{old_name}' -> '{new_name}'")
        return {'FINISHED'}


class RENDERFLO_OT_delete_cmf(bpy.types.Operator):
    bl_idname = "renderflo.delete_cmf"
    bl_label = "Delete CMF Colorway"
    bl_description = "Remove this CMF Colorway preset from the library"
    bl_options = {'REGISTER', 'UNDO'}

    target_cmf_name: bpy.props.StringProperty(name="Target CMF", default="")

    def execute(self, context):
        scene = context.scene
        target_name = self.target_cmf_name.strip()
        if not target_name:
            if hasattr(scene, "rf_active_cmf_enum") and scene.rf_active_cmf_enum:
                target_name = scene.rf_active_cmf_enum

        idx = next((i for i, c in enumerate(scene.rf_cmf_presets) if c.name == target_name), None)
        if idx is None:
            self.report({'WARNING'}, f"Colorway '{target_name}' not found.")
            return {'CANCELLED'}

        if len(scene.rf_cmf_presets) <= 1:
            self.report({'WARNING'}, "Cannot delete the last remaining colorway preset.")
            return {'CANCELLED'}

        scene.rf_cmf_presets.remove(idx)

        # Fallback for studios using this colorway
        fallback = scene.rf_cmf_presets[0].name
        for s in scene.rf_studios:
            if s.cmf_mode == target_name:
                s.cmf_mode = fallback
            sync_studio_cmf_toggles(scene, s)

        with internal_update_guard():
            try:
                if scene.rf_active_cmf_enum == target_name:
                    scene.rf_active_cmf_enum = fallback
            except Exception:
                pass

        self.report({'INFO'}, f"Deleted Colorway '{target_name}'")
        return {'FINISHED'}


class RENDERFLO_OT_create_colorway_variant(bpy.types.Operator):
    bl_idname = "renderflo.create_colorway_variant"
    bl_label = "Create Colorway Variant (Duplicate Materials)"
    bl_description = "Duplicate all unique materials across product components for an independent CMF colorway"
    bl_options = {'REGISTER', 'UNDO'}

    colorway_name: bpy.props.StringProperty(
        name="Colorway Name",
        description="Name of the new CMF colorway preset",
        default="Colorway_02"
    )

    def invoke(self, context, event):
        scene = context.scene
        self.colorway_name = f"Colorway_{len(scene.rf_cmf_presets) + 1:02d}"
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene
        c_name = self.colorway_name.strip()
        if not c_name:
            self.report({'ERROR'}, "Colorway name cannot be empty.")
            return {'CANCELLED'}

        # Ensure unique name among CMF presets
        existing_names = {c.name for c in scene.rf_cmf_presets}
        base_name = c_name
        counter = 1
        while base_name in existing_names:
            base_name = f"{c_name}_{counter}"
            counter += 1
        final_colorway_name = base_name

        from ..state import GROUND_PLANE_NAME, BACKDROP_OBJ_NAME, DOME_VISUALIZER_OBJ
        excluded = {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME, DOME_VISUALIZER_OBJ}

        product_objs = [
            obj for obj in scene.objects
            if obj.name not in excluded and obj.type in {'MESH', 'CURVE', 'SURFACE'} and len(obj.material_slots) > 0
        ]

        if not product_objs:
            self.report({'WARNING'}, "No product objects with material slots found.")
            return {'CANCELLED'}

        # Map original material -> new duplicated material
        cloned_map = {}
        for obj in product_objs:
            for slot in obj.material_slots:
                if slot.material and slot.material not in cloned_map:
                    orig_mat = slot.material
                    new_mat = orig_mat.copy()
                    new_mat.name = f"{orig_mat.name}_{final_colorway_name}"
                    cloned_map[orig_mat] = new_mat

        # Reassign material slots on each component to the cloned copies
        for obj in product_objs:
            for slot in obj.material_slots:
                if slot.material and slot.material in cloned_map:
                    slot.material = cloned_map[slot.material]

        # Record this new set of materials into a new CMF preset
        new_cmf = scene.rf_cmf_presets.add()
        new_cmf.name = final_colorway_name
        record_materials_into_collection(scene, new_cmf.object_materials)

        # Sync studio matrix toggles
        for s in scene.rf_studios:
            sync_studio_cmf_toggles(scene, s)

        # Update active studio and scene active CMF enum
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            scene.rf_studios[scene.rf_studio_index].cmf_mode = final_colorway_name

        with internal_update_guard():
            try:
                scene.rf_active_cmf_enum = final_colorway_name
            except Exception:
                pass

        self.report({'INFO'}, f"Created Colorway '{final_colorway_name}' ({len(cloned_map)} materials cloned)")
        return {'FINISHED'}


class RENDERFLO_OT_activate_cmf_preset(bpy.types.Operator):
    """Activate this CMF Colorway preset and apply it to the scene"""
    bl_idname = "renderflo.activate_cmf_preset"
    bl_label = "Activate Colorway"
    bl_options = {'REGISTER', 'UNDO'}

    target_cmf_name: bpy.props.StringProperty(name="Target CMF Name", default="")

    def execute(self, context):
        scene = context.scene
        if not self.target_cmf_name:
            return {'CANCELLED'}
        scene.rf_active_cmf_enum = self.target_cmf_name
        self.report({'INFO'}, f"Activated CMF Colorway: '{self.target_cmf_name}'")
        return {'FINISHED'}


cmf_classes = (
    RENDERFLO_OT_activate_cmf_preset,
    RENDERFLO_OT_sync_cmf_matrix,
    RENDERFLO_OT_clone_active_material,
    RENDERFLO_OT_save_new_cmf,
    RENDERFLO_OT_create_colorway_variant,
    RENDERFLO_OT_rename_cmf,
    RENDERFLO_OT_delete_cmf,
    RENDERFLO_OT_update_active_cmf,
)


def register():
    for cls in cmf_classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(cmf_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

