# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.3.0 — Viewport Header Ribbon Bar & Surface Analysis.
Appends quick Studio / CMF selectors, Orbit Switcher (Rhino / SolidWorks / Blender),
and Zebra MatCap Class-A surface curvature analysis to the 3D Viewport Header.
"""

import bpy


# ------------------------------------------------------------------------
# Viewport Orbit & MatCap Mode Handlers
# ------------------------------------------------------------------------

def on_orbit_mode_change(self, context):
    prefs = bpy.context.preferences.inputs
    mode = context.scene.rf_orbit_mode

    if mode == 'RHINO':
        prefs.view_rotate_method = 'TURNTABLE'
        prefs.use_zoom_to_mouse = True
        prefs.use_rotate_around_active = True
    elif mode == 'SOLIDWORKS':
        prefs.view_rotate_method = 'TRACKBALL'
        prefs.use_zoom_to_mouse = True
        prefs.use_rotate_around_active = True
    else:  # 'BLENDER'
        prefs.view_rotate_method = 'TURNTABLE'
        prefs.use_zoom_to_mouse = False
        prefs.use_rotate_around_active = False


def on_zebra_matcap_change(self, context):
    scene = context.scene
    is_zebra = scene.rf_zebra_enabled

    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D' and hasattr(space, "shading"):
                    if is_zebra:
                        space.shading.type = 'SOLID'
                        space.shading.light = 'MATCAP'
                        # Look for zebra or high-contrast reflection matcap
                        matcaps = ['zebra.exr', 'check_rim_dark.exr', 'metal_carpaint.exr']
                        for mc in matcaps:
                            try:
                                space.shading.studio_light = mc
                                break
                            except Exception:
                                pass
                    else:
                        space.shading.type = 'SOLID'
                        space.shading.light = 'STUDIO'
            area.tag_redraw()


# ------------------------------------------------------------------------
# Quick Popovers
# ------------------------------------------------------------------------

class RENDERFLO_PT_quick_studio_popover(bpy.types.Panel):
    bl_label = "Studio Snapshots"
    bl_idname = "RENDERFLO_PT_quick_studio_popover"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        row = layout.row(align=True)
        row.operator("renderflo.add_studio", text="New Studio", icon='ADD')
        row.operator("renderflo.snap_shadow_floor", text="Floor Plane", icon='MESH_PLANE')

        if len(scene.rf_studios) > 0:
            s_row = layout.row()
            s_row.template_list("RENDERFLO_UL_studio_list", "", scene, "rf_studios", scene, "rf_studio_index", rows=4)
            s_col = s_row.column(align=True)
            s_col.operator("renderflo.move_studio", icon='TRIA_UP', text="").direction = 'UP'
            s_col.operator("renderflo.move_studio", icon='TRIA_DOWN', text="").direction = 'DOWN'
            s_col.separator()
            s_col.operator("renderflo.remove_studio", icon='REMOVE', text="")

            if 0 <= scene.rf_studio_index < len(scene.rf_studios):
                studio = scene.rf_studios[scene.rf_studio_index]
                t_row = layout.row(align=True)
                t_row.prop(studio, "use_collections", text="Model Sets", toggle=True, icon='OUTLINER_COLLECTION')
                t_row.prop(studio, "use_transforms", text="Exploded / Part Pos", toggle=True, icon='ARROW_LEFTRIGHT')
                t_row.prop(studio, "use_part_visibility", text="Part Visibility", toggle=True, icon='HIDE_OFF')


class RENDERFLO_PT_quick_lighting_popover(bpy.types.Panel):
    bl_label = "Quick Lighting"
    bl_idname = "RENDERFLO_PT_quick_lighting_popover"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            row = layout.row(align=True)
            row.operator("renderflo.interactive_hdri_canvas", text="2D HDRI Pin Canvas", icon='WINDOW')
            row.operator("renderflo.add_hdri_pin", text="+ Pin", icon='ADD')

            row2 = layout.row(align=True)
            op_k = row2.operator("renderflo.spawn_studio_light", text="+ Key", icon='LIGHT_SUN')
            op_k.preset = 'KEY'
            op_r = row2.operator("renderflo.spawn_studio_light", text="+ Rim", icon='LIGHT_SPOT')
            op_r.preset = 'RIM'


# ------------------------------------------------------------------------
# 1-Click Studio & CMF Stepper Cycle Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_cycle_studio(bpy.types.Operator):
    bl_idname = "renderflo.cycle_studio"
    bl_label = "Cycle Studio Snapshot"
    bl_description = "Switch directly to previous or next studio snapshot without opening list"
    bl_options = {'REGISTER', 'UNDO'}

    direction: bpy.props.EnumProperty(
        items=[('PREV', 'Previous', ''), ('NEXT', 'Next', '')],
        default='NEXT'
    )

    def execute(self, context):
        scene = context.scene
        count = len(scene.rf_studios)
        if count == 0:
            return {'CANCELLED'}

        cur_idx = scene.rf_studio_index
        if not (0 <= cur_idx < count):
            cur_idx = 0

        if self.direction == 'NEXT':
            new_idx = (cur_idx + 1) % count
        else:
            new_idx = (cur_idx - 1 + count) % count

        bpy.ops.renderflo.activate_studio(index=new_idx)
        return {'FINISHED'}


class RENDERFLO_OT_cycle_cmf(bpy.types.Operator):
    bl_idname = "renderflo.cycle_cmf"
    bl_label = "Cycle CMF Colorway"
    bl_description = "Switch directly to previous or next CMF colorway preset without opening list"
    bl_options = {'REGISTER', 'UNDO'}

    direction: bpy.props.EnumProperty(
        items=[('PREV', 'Previous', ''), ('NEXT', 'Next', '')],
        default='NEXT'
    )

    def execute(self, context):
        scene = context.scene
        presets = scene.rf_cmf_presets
        count = len(presets)
        if count == 0:
            return {'CANCELLED'}

        current_name = scene.rf_active_cmf_enum
        cur_idx = next((i for i, p in enumerate(presets) if p.name == current_name), 0)

        if self.direction == 'NEXT':
            new_idx = (cur_idx + 1) % count
        else:
            new_idx = (cur_idx - 1 + count) % count

        scene.rf_active_cmf_enum = presets[new_idx].name
        return {'FINISHED'}


# ------------------------------------------------------------------------
# Topbar, Viewport Header Ribbon & Bottom Action Bar Draw Functions
# ------------------------------------------------------------------------

def draw_topbar(self, context):
    layout = self.layout
    scene = getattr(context, "scene", None)
    if not scene or not hasattr(scene, "rf_studios"):
        return

    row = layout.row(align=True)
    row.scale_x = 0.95
    row.separator(factor=1.5)

    # CAD Quick Actions in Topbar
    row.operator("renderflo.import_cad", text="Import CAD (.STEP/.3DM)", icon='IMPORT')
    row.operator("renderflo.cad_hot_reload", text="Hot-Reload CAD", icon='FILE_REFRESH')

    row.separator(factor=1.0)

    # Studio Quick Selector with 1-Click Steppers
    row.label(text="Studio:")
    if len(scene.rf_studios) > 0:
        prev_st = row.operator("renderflo.cycle_studio", text="", icon='TRIA_LEFT')
        prev_st.direction = 'PREV'
        row.prop(scene, "rf_active_studio_enum", text="")
        next_st = row.operator("renderflo.cycle_studio", text="", icon='TRIA_RIGHT')
        next_st.direction = 'NEXT'

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            lock_icon = 'LOCKED' if studio.is_locked else 'UNLOCKED'
            row.prop(studio, "is_locked", text="", icon=lock_icon)
        row.popover(panel="RENDERFLO_PT_quick_studio_popover", text="")
    else:
        row.label(text="None")
    row.operator("renderflo.add_studio", text="", icon='ADD')

    row.separator(factor=1.0)

    # CMF Quick Selector with 1-Click Steppers
    row.label(text="CMF:")
    if hasattr(scene, "rf_cmf_presets") and len(scene.rf_cmf_presets) > 0:
        prev_cmf = row.operator("renderflo.cycle_cmf", text="", icon='TRIA_LEFT')
        prev_cmf.direction = 'PREV'
        row.prop(scene, "rf_active_cmf_enum", text="")
        next_cmf = row.operator("renderflo.cycle_cmf", text="", icon='TRIA_RIGHT')
        next_cmf.direction = 'NEXT'

        op_ren = row.operator("renderflo.rename_cmf", text="", icon='GREASEPENCIL')
        op_ren.target_cmf_name = scene.rf_active_cmf_enum
        row.operator("renderflo.create_colorway_variant", text="", icon='DUPLICATE')
    else:
        row.prop(scene, "rf_active_cmf_enum", text="")

    row.separator(factor=1.0)

    # Ratio Quick Selector in Topbar
    row.label(text="Ratio:")
    row.prop(scene, "rf_active_aspect_preset_enum", text="")


def draw_viewport_ribbon(self, context):
    layout = self.layout
    scene = getattr(context, "scene", None)
    if not scene or not hasattr(scene, "rf_orbit_mode"):
        return

    ribbon = layout.row(align=True)
    ribbon.scale_x = 0.95

    # Ratio Quick Selector in Viewport
    ribbon.label(text="Ratio:")
    ribbon.prop(scene, "rf_active_aspect_preset_enum", text="")

    ribbon.separator(factor=1.5)

    # [Zebra] MatCap Curvature Analysis
    z_icon = 'HIDE_OFF' if scene.rf_zebra_enabled else 'HIDE_ON'
    ribbon.prop(scene, "rf_zebra_enabled", text="Zebra", icon=z_icon)

    ribbon.separator(factor=2.0)


def draw_viewport_footer(self, context):
    layout = self.layout
    scene = getattr(context, "scene", None)
    if not scene or not hasattr(scene, "rf_explode_factor"):
        return

    row = layout.row(align=True)
    row.scale_x = 1.0

    # Explode slider
    sub_ex = row.row(align=True)
    sub_ex.prop(scene, "rf_explode_factor", text="Explode", slider=True)

    row.separator(factor=2.0)

    # Turntable slider
    sub_tt = row.row(align=True)
    sub_tt.prop(scene, "rf_turntable_angle", text="Turntable", slider=True)

    row.separator(factor=2.0)

    # RENDER Button
    if getattr(scene, "rf_is_batch_rendering", False):
        r_row = row.row(align=True)
        r_row.alert = True
        r_row.operator("renderflo.cancel_batch_render", text=f"Cancel ({scene.rf_batch_progress:.0f}%)", icon='CANCEL')
    else:
        r_row = row.row(align=True)
        r_row.scale_x = 1.25
        r_row.operator("renderflo.render_action_bar", text="RENDER", icon='RENDER_STILL')


ribbon_classes = (
    RENDERFLO_OT_cycle_studio,
    RENDERFLO_OT_cycle_cmf,
    RENDERFLO_PT_quick_studio_popover,
    RENDERFLO_PT_quick_lighting_popover,
)


def register():
    for cls in ribbon_classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_editor_menus.append(draw_topbar)
    bpy.types.VIEW3D_HT_header.append(draw_viewport_ribbon)
    if hasattr(bpy.types, "STATUSBAR_HT_header"):
        bpy.types.STATUSBAR_HT_header.append(draw_viewport_footer)


def unregister():
    if hasattr(bpy.types, "STATUSBAR_HT_header"):
        try:
            bpy.types.STATUSBAR_HT_header.remove(draw_viewport_footer)
        except Exception:
            pass
    bpy.types.VIEW3D_HT_header.remove(draw_viewport_ribbon)
    bpy.types.TOPBAR_MT_editor_menus.remove(draw_topbar)
    for cls in reversed(ribbon_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

