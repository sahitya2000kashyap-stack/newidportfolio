# ID RenderFlo — Release Notes

**Universal Industrial Design Studio & Parametric CAD Pipeline for Blender**  
*Created by Sahitya Kashyap ([sahityakashyap.in](https://sahityakashyap.in))*

---

## 🚀 What's New in v3.0.0

### 1. 🎛️ Reorganized 6-Menu Industrial Design Lifecycle Dock
The N-Panel sidebar dock has been redesigned into a continuous 6-stage industrial design workflow:
1. **CAD Bridge**: STEP & Rhino `.3dm` import, unit calibration, origin centering, and 1-Click Hot-Reload.
2. **Studios**: Multi-shot camera framing, focal length presets, padlock protection, and custom render samples.
3. **Lighting**: Procedural HDRI dome, interactive 2D pin canvas, and physical studio softboxes.
4. **CMF Matrix**: Color, Material & Finish variants, VDI 3400 mold-tech textures, and anodized/brushed metals.
5. **Decals & FX**: Raycast surface sticker dropper, conformal shrinkwrap with zero Z-fighting, and live section cutaways.
6. **Render & DXF**: GPU batch queue, custom output directory selector, and manufacturing DXF export.

### 2. ⚡ Unified Persistent Topbar Ribbon
Directly accessible from Blender's main topbar alongside standard menus:
* **CAD Quick Actions**: `Import CAD (.STEP/.3DM)` and `Hot-Reload CAD` buttons.
* **Studio Selector**: Active studio dropdown, camera padlock toggle, camera settings popover, and `+ Add Studio`.
* **CMF Quick Matrix**: Active CMF variant selector, `Rename Variant`, and `Duplicate Colorway` buttons.
* **Aspect Ratio Selector**: 1-Click social, hero, and ultrawide format presets (`1:1`, `4:5`, `16:9`, `9:16`, `2.39:1`).

### 3. 📐 CAD Import True Scale & Orientation Defaults
* **True Scale Default**: Set to **Millimeters (True Scale / Recommended - 0.001x)**. In Blender, 1 unit = 1 meter. Converting millimeter CAD assemblies by 0.001x ensures accurate real-world dimensions for Cycles lighting, shadow falloff, and camera depth-of-field.
* **Z-Up Default**: Default CAD Up-Axis set to **Z-Up** to natively match Rhino, Fusion 360, and Blender coordinate systems.
* **Streamlined Pipeline**: Streamlined strictly for `.step`/`.stp` and Rhino `.3dm` with 1-click hot-reload; stripped non-functional `.sldprt` and `.x_t` mentions.

### 4. 🔢 Per-Studio Custom Render Samples
* Restored custom sample limits per studio item (`use_custom_samples` and `studio_samples`).
* Real-time bidirectional sync with `scene.cycles.samples`: allow quick draft angles at 128 samples while hero closeups render at 1024+ samples.

### 5. 📂 Interactive Render Output Directory
* Added a dedicated output directory picker in the Render tab and Studio Dashboard.
* **1-Click Open Folder**: Dedicated button opens the destination folder directly in Windows File Explorer, macOS Finder, or Linux file manager.

### 6. 🏷️ Decals & Section Cutaways Refinement
* Streamlined the decal workflow to focus on high-precision raycast decal dropping, normal alignment, spin controls, and conformal shrinkwrapping.
* Removed experimental mesh displace deformers to prevent geometry corruption on dense CAD assemblies.
* Fast live boolean section cutaways with interactive slicing box.

### 7. 🏭 Consolidated Manufacturing Export
* Moved 1-Click DXF silhouette and flat pattern export into the Render & DXF tab for a unified product handoff stage.

---

## 🌟 What's New in v2.4.1

### 1. 📦 Official Blender Extensions Platform Compliance
* **Pre-Bundled Python Wheels**: Fully self-contained offline architecture. Includes official compiled binary wheels for `cascadio` (OpenCASCADE STEP converter) and `rhino3dm` (Rhino 3D parser).
* **Cross-Platform Support**: Tailored wheel builds for **Windows (`windows-x64`)**, **Linux (`linux-x64`)**, **macOS Apple Silicon (`macos-arm64`)**, and **macOS Intel (`macos-x64`)**.
* **Zero Host Contamination & Offline Execution**: Eliminates runtime `pip`, `ensurepip`, and external network downloads on setup. The `network` permission requirement has been removed from `blender_manifest.toml`.
* **Direct In-Memory CAD Pipeline**: Rhino `.3dm` files and STEP `.step/.stp` assemblies are converted and imported directly into Blender in memory, removing intermediate worker script files and disk pickle serialization for significantly faster import speeds.

### 2. ⚡ Depsgraph & Performance Stability Optimization
* **Removed Depsgraph Mutating Handlers**: Removed `renderflo_auto_save_handler` from `bpy.app.handlers.depsgraph_update_post`. Mutating RNA properties during depsgraph evaluation is discouraged by Blender core developers as it causes viewport lag, undo-history corruption, and dependency graph re-evaluation cycles.
* **Rock-Solid Event-Driven Persistence**: Studio states and lighting configurations are now captured cleanly on explicit user actions (switching studios, adding lights, or clicking "Update Studio State").

### 3. 🛡️ Python Environment Isolation
* **Forwarded Blender Environment (`bpy.app.python_args`)**: External process and helper invocations pass `*bpy.app.python_args` (`-I` isolated mode) directly after `sys.executable`. This prevents system-wide environment variables (such as `PYTHONPATH` or `PYTHONHOME`) from conflicting with Blender's Python runtime.
* **Eliminated `sys.path` Tampering**: Completely removed all manual insertions and modifications to `sys.path` and `sys.modules`.

### 4. 🏷️ Manifest & Tag Cleanup
* Updated manifest tags to conform strictly to Blender Extensions platform standards: `tags = ["Render", "Import-Export"]` (removed non-standard `"Material"` tag).

---

## 🌟 What Was Introduced in v2.4.0

### 1. 🦏 Native Rhino `.3DM` CAD Importer
ID RenderFlo natively imports Rhinoceros 3D (`.3dm`) files directly alongside `.STEP`, `.STP`, `.IGES`, and `.STL`:
* **Geometry Engine**: Direct extraction of Rhino `Mesh`, `Brep`, `Extrusion`, and `SubD` objects with cached render meshes.
* **True CAD Split Normals**: Converts Rhino surface normals into custom split vertex normals (`normals_split_custom_set_from_vertices`), guaranteeing razor-sharp industrial design fillets, chamfers, and bezels without shading artifacts or black edge clipping.
* **Rhino Layer-to-Material Mapping**: Automatically translates Rhino layers and their native display colors into distinct Blender Principled BSDF materials (`Rhino_<LayerName>`). Your imported product arrives pre-configured for instant colorway adjustments in the CMF Matrix!
* **Smart Unit Detection**: Automatically queries Rhino model unit metadata (`model.Settings.ModelUnitSystem`) to cleanly scale millimeters, centimeters, inches, or meters to native Blender dimensions.
* **Automated Product Alignment**: Automatically centers CAD parts on the XY origin, snaps the base to the Z=0 ground plane, and positions the target empty at the product's optical center.

---

### 2. 💡 KeyShot-Style Procedural HDRI Dome & Interactive 2D Pin Canvas
Bring professional studio lighting into Blender with a fully procedural environment dome and interactive pin system:
* **Interactive 2D Pin Canvas**: Launch a real-time, interactive 2D panoramic canvas directly in the 3D Viewport. Visually position pins across the latitude/longitude dome map with live viewport feedback.
* **Viewport Isolation**: The 2D canvas strictly renders within the active working viewport and automatically disables when secondary viewports or render cameras are focused.
* **Pin Types & Control**:
  * **Round Pins** (`CIRCLE`): Specular spotlight pins with independent radius and falloff softness.
  * **Softbox Strips** (`RECT`): Rectangular softbox lights with adjustable aspect ratio and 2D tilt rotation.
  * **Eyedropper Normal Raycaster**: Click on any surface point of your 3D CAD model to cast a reflection vector and automatically calculate the required azimuth and elevation to place the specular highlight directly on that surface.
* **External HDRI Support**: Seamlessly switch between the procedural dome and high-dynamic-range image maps (`.hdr` / `.exr`) with one-click browsing, intensity, and global dome rotation.

---

### 3. 🔦 Simultaneous Dual-Lighting Pipeline
* Run both the **Procedural HDRI Dome & Pins** and **Physical Studio Lamps** together in the same scene without conflict.
* The segmented lighting tabs (`[ HDRI Dome & Pins ]` | `[ Physical Lights ]`) serve as a clean UI filter while Cycles and EEVEE evaluate both lighting sources simultaneously.
* **Physical Light Deletion**: Easily remove unwanted lamps directly from the N-panel via dedicated `[ X ]` buttons without having to open the Outliner.

---

### 4. 🎨 Color Management Look & Contrast Selector
* Added a dedicated **Contrast** selector right beside **Exposure** in Section 5 (Environment & Backdrop).
* Choose instantly between all 8 standard Blender color management looks: *None*, *Very Low*, *Low*, *Medium Low*, *Medium*, *Medium High*, *High*, and *Very High Contrast*.

---

### 5. 📐 HardOps-Inspired Collapsible UI Navigation
Eliminate vertical N-panel scroll clutter with streamlined, collapsible module headers:
* **CAD Engine & Import**
* **New Studio Defaults**
* **1. Format & Aspect Ratio**
* **2. Studio Camera & Framing**
* **3. CMF Variations**
* **4. Lighting Rig (HDRI & Physical)**
* **5. Environment, Floor & Backdrop**
* **6. GPU & Fast Render Queue**

Each section expands and collapses with a single click (`▼` / `▶`), keeping your workspace focused and neat.

---

### 6. 🔒 Studio Padlock Protection
* **Padlock Protection**: Lock hero camera positions and studio setups (`is_locked`) against accidental modifications.
* **Unblocked Tweaking**: Lighting and HDRI pin adjustments remain fully interactive while locked, accompanied by a 1-click **Unlock Padlock Banner** when you want to resume editing camera transforms.

---

## 🛠️ System Compatibility
* **Blender Versions**: 100% backward- and forward-compatible across **Blender 3.6 LTS, 4.0, 4.1, 4.2 LTS, 4.5 LTS, through 5.2.2+**.
* **Supported Platforms**: Windows (`x86_64`), macOS (`Apple Silicon arm64` & `Intel x86_64`), and Linux (`x86_64`).

---

## 📦 Installation Instructions

### Blender 4.2+ (Official Extension Package):
1. In Blender, go to **Edit > Preferences > Get Extensions**.
2. Click the top-right menu icon (down arrow) and select **Install from Disk...**
3. Select your platform package (e.g. `id_renderflo-2.4.1-windows-x64.zip`) and enable the extension.
4. Press **N** in any 3D Viewport to open the **ID RenderFlo** panel.

### Blender 3.6 LTS – 4.1 (Classic Add-on):
1. In Blender, go to **Edit > Preferences > Add-ons**.
2. Click **Install...** and select `id_renderflo-2.4.1-website-standalone.zip`.
3. Check the box to activate **ID RenderFlo**.
4. Press **N** in any 3D Viewport to access the studio manager.
