# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.0.0 — Non-Blocking Modal GPU Batch & Matrix Render Queue.
Runs non-blocking Cycles GPU renders across Studios and CMF colorways with live progress HUD.
"""

import bpy
import os
import sys

from ..state import is_internal_update, internal_update_guard


# ------------------------------------------------------------------------
# GPU Hardware & Quality Configuration
# ------------------------------------------------------------------------

def configure_cycles_gpu(scene, force_gpu=True):
    scene.render.engine = 'CYCLES'
    if not hasattr(scene, "cycles"):
        return "Cycles not available"

    if not force_gpu:
        scene.cycles.device = 'CPU'
        return "CPU"

    scene.cycles.device = 'GPU'
    try:
        prefs = bpy.context.preferences
        cprefs = prefs.addons['cycles'].preferences
        preferred_backends = ['OPTIX', 'CUDA', 'HIP', 'METAL', 'ONEAPI']
        chosen_backend = None

        for backend in preferred_backends:
            try:
                cprefs.compute_device_type = backend
                cprefs.get_devices()
                gpu_devs = [d for d in cprefs.devices if d.type != 'CPU']
                if gpu_devs:
                    chosen_backend = backend
                    for d in cprefs.devices:
                        d.use = (d.type != 'CPU')
                    break
            except Exception:
                continue

        if chosen_backend:
            return f"GPU ({chosen_backend})"
    except Exception:
        pass

    return "GPU (Active)"


def apply_render_quality_settings(scene, samples):
    if hasattr(scene, "cycles"):
        scene.cycles.samples = samples
        scene.cycles.preview_samples = scene.rf_viewport_samples
        scene.cycles.use_adaptive_sampling = True
        scene.cycles.adaptive_threshold = scene.rf_noise_threshold
        scene.cycles.use_denoising = scene.rf_use_denoiser


def update_global_render_settings(self, context):
    if is_internal_update() or not context or not context.scene:
        return
    scene = context.scene
    configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)
    apply_render_quality_settings(scene, scene.rf_render_samples)


# ------------------------------------------------------------------------
# Batch & Matrix Render Queue Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_cancel_batch_render(bpy.types.Operator):
    bl_idname = "renderflo.cancel_batch_render"
    bl_label = "Cancel Batch Queue"

    def execute(self, context):
        context.scene.rf_is_batch_rendering = False
        return {'FINISHED'}


class RENDERFLO_OT_batch_render(bpy.types.Operator):
    bl_idname = "renderflo.batch_render"
    bl_label = "Batch Render Studios (GPU Modal Queue)"

    matrix_mode: bpy.props.BoolProperty(default=False)

    _timer = None
    _jobs = []
    _current_job_idx = 0
    _is_rendering_frame = False
    _frame_finished = False
    _render_cancelled = False
    _orig_filepath = ""
    _orig_res_x = 1920
    _orig_res_y = 1080
    _orig_res_scale = 100
    _orig_samples = 256
    _orig_world = None
    _base_dir = ""

    def _on_render_complete(self, scene, depsgraph=None):
        self._frame_finished = True

    def _on_render_cancel(self, scene, depsgraph=None):
        self._render_cancelled = True

    def _cleanup(self, context):
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None

        if self._on_render_complete in bpy.app.handlers.render_complete:
            bpy.app.handlers.render_complete.remove(self._on_render_complete)
        if self._on_render_cancel in bpy.app.handlers.render_cancel:
            bpy.app.handlers.render_cancel.remove(self._on_render_cancel)

        scene = context.scene
        scene.render.filepath = self._orig_filepath
        scene.render.resolution_x = self._orig_res_x
        scene.render.resolution_y = self._orig_res_y
        scene.render.resolution_percentage = self._orig_res_scale
        if hasattr(scene, "cycles"):
            scene.cycles.samples = self._orig_samples
        if self._orig_world:
            scene.world = self._orig_world

        scene.rf_is_batch_rendering = False
        scene.rf_batch_status_text = ""
        for area in context.screen.areas:
            area.tag_redraw()

    def invoke(self, context, event):
        scene = context.scene
        if scene.rf_is_batch_rendering:
            self.report({'WARNING'}, "Batch Render is already running!")
            return {'CANCELLED'}

        from .cmf_materials import sync_studio_cmf_toggles
        for s in scene.rf_studios:
            sync_studio_cmf_toggles(scene, s)

        from .studio_manager import capture_studio_state
        if getattr(scene, "rf_auto_save_studios", True) and (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            active_s = scene.rf_studios[scene.rf_studio_index]
            if not active_s.is_locked:
                capture_studio_state(context, active_s)

        self._orig_filepath = scene.render.filepath

        custom_dir = scene.rf_render_output_dir.strip() if hasattr(scene, "rf_render_output_dir") else ""
        if custom_dir:
            self._base_dir = bpy.path.abspath(custom_dir)
        elif self._orig_filepath:
            self._base_dir = bpy.path.abspath(self._orig_filepath)
            if not self._base_dir.endswith(os.sep) and not os.path.isdir(self._base_dir):
                self._base_dir = os.path.dirname(self._base_dir)
        else:
            default_dir = os.path.join(os.path.expanduser("~"), "Pictures", "ID_RenderFlo")
            self._base_dir = default_dir

        os.makedirs(self._base_dir, exist_ok=True)

        self._orig_res_x = scene.render.resolution_x
        self._orig_res_y = scene.render.resolution_y
        self._orig_res_scale = scene.render.resolution_percentage
        self._orig_samples = scene.cycles.samples if hasattr(scene, "cycles") else 256
        self._orig_world = scene.world

        hw_status = configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)
        self._jobs = []

        for s_idx, studio in enumerate(scene.rf_studios):
            if not studio.render_enabled:
                continue

            s_name = bpy.path.clean_name(studio.name)
            res_tag = f"{studio.res_x}x{studio.res_y}"

            if self.matrix_mode:
                if studio.use_materials and len(studio.cmf_matrix_toggles) > 0:
                    selected_cmfs = [t.cmf_name for t in studio.cmf_matrix_toggles if t.enabled]
                    if selected_cmfs:
                        for cmf_name in selected_cmfs:
                            c_name = bpy.path.clean_name(cmf_name)
                            out_path = os.path.join(self._base_dir, f"{s_name}_{c_name}_{res_tag}")
                            self._jobs.append((s_idx, cmf_name, out_path, f"{studio.name} + {cmf_name}"))
                    else:
                        out_path = os.path.join(self._base_dir, f"{s_name}_Default_{res_tag}")
                        self._jobs.append((s_idx, None, out_path, f"{studio.name} (Default)"))
                else:
                    out_path = os.path.join(self._base_dir, f"{s_name}_Default_{res_tag}")
                    self._jobs.append((s_idx, None, out_path, f"{studio.name} (Default)"))
            else:
                out_path = os.path.join(self._base_dir, f"{s_name}_{res_tag}")
                self._jobs.append((s_idx, None, out_path, f"{studio.name}"))

        if not self._jobs:
            self.report({'WARNING'}, "No checked Studios to render.")
            return {'CANCELLED'}

        if not scene.camera and not any(s.camera_obj for s in scene.rf_studios):
            self.report({'ERROR'}, "No Camera in scene! Please assign or create a Studio Camera first.")
            return {'CANCELLED'}

        self._current_job_idx = 0
        self._is_rendering_frame = False
        self._frame_finished = False
        self._render_cancelled = False

        bpy.app.handlers.render_complete.append(self._on_render_complete)
        bpy.app.handlers.render_cancel.append(self._on_render_cancel)

        scene.rf_is_batch_rendering = True
        scene.rf_batch_progress = 0.0
        scene.rf_batch_status_text = f"Starting {hw_status} Queue (0 / {len(self._jobs)})..."

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.5, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        scene = context.scene

        if event.type == 'ESC' or self._render_cancelled or not scene.rf_is_batch_rendering:
            self._cleanup(context)
            self.report({'WARNING'}, "Batch Render Cancelled.")
            return {'CANCELLED'}

        if event.type != 'TIMER':
            return {'PASS_THROUGH'}

        if self._is_rendering_frame:
            if self._frame_finished:
                self._is_rendering_frame = False
                self._frame_finished = False
                self._current_job_idx += 1
            else:
                return {'PASS_THROUGH'}

        total_jobs = len(self._jobs)
        if self._current_job_idx >= total_jobs:
            self._cleanup(context)
            self.report({'INFO'}, f"ID RenderFlo: Batch Render Complete! ({total_jobs} images saved to {self._base_dir})")
            return {'FINISHED'}

        s_idx, cmf_override, out_path, job_label = self._jobs[self._current_job_idx]
        studio = scene.rf_studios[s_idx]

        scene.rf_studio_index = s_idx
        from .studio_manager import apply_studio_state
        apply_studio_state(context, studio)

        if cmf_override:
            cmf = next((c for c in scene.rf_cmf_presets if c.name == cmf_override), None)
            if cmf:
                from .cmf_materials import restore_materials_from_collection
                restore_materials_from_collection(cmf.object_materials)

        shot_samples = studio.studio_samples if studio.use_custom_samples else scene.rf_render_samples
        apply_render_quality_settings(scene, shot_samples)
        scene.render.filepath = out_path

        scene.rf_batch_progress = (self._current_job_idx / total_jobs) * 100.0
        scene.rf_batch_status_text = f"Rendering [{self._current_job_idx + 1}/{total_jobs}]: {job_label} ({shot_samples} samples)"
        for area in context.screen.areas:
            area.tag_redraw()

        self._is_rendering_frame = True
        self._frame_finished = False

        res = bpy.ops.render.render('INVOKE_DEFAULT', write_still=True)
        if 'RUNNING_MODAL' not in res:
            bpy.ops.render.render(write_still=True)
            self._frame_finished = True

        return {'PASS_THROUGH'}


class RENDERFLO_OT_render_action_bar(bpy.types.Operator):
    bl_idname = "renderflo.render_action_bar"
    bl_label = "RENDER Product"
    bl_description = "Render active studio or execute batch render queue"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        if getattr(scene, "rf_is_batch_rendering", False):
            scene.rf_is_batch_rendering = False
            return {'FINISHED'}

        if len(scene.rf_studios) > 0:
            return bpy.ops.renderflo.batch_render('INVOKE_DEFAULT')
        else:
            custom_dir = scene.rf_render_output_dir.strip() if hasattr(scene, "rf_render_output_dir") else ""
            if custom_dir:
                base_dir = bpy.path.abspath(custom_dir)
                os.makedirs(base_dir, exist_ok=True)
                scene.render.filepath = os.path.join(base_dir, "render")
            return bpy.ops.render.render('INVOKE_DEFAULT', write_still=True)


class RENDERFLO_OT_open_render_folder(bpy.types.Operator):
    bl_idname = "renderflo.open_render_folder"
    bl_label = "Open Folder"
    bl_description = "Open the render output directory in file explorer"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        custom_dir = scene.rf_render_output_dir.strip() if hasattr(scene, "rf_render_output_dir") else ""
        if custom_dir:
            abs_path = bpy.path.abspath(custom_dir)
        elif scene.render.filepath:
            abs_path = bpy.path.abspath(scene.render.filepath)
            if not os.path.isdir(abs_path):
                abs_path = os.path.dirname(abs_path)
        else:
            abs_path = os.path.join(os.path.expanduser("~"), "Pictures", "ID_RenderFlo")

        os.makedirs(abs_path, exist_ok=True)
        try:
            import subprocess
            if sys.platform == 'win32':
                os.startfile(abs_path)
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', abs_path])
            else:
                subprocess.Popen(['xdg-open', abs_path])
            self.report({'INFO'}, f"Opened render folder: {abs_path}")
        except Exception as e:
            self.report({'WARNING'}, f"Could not open folder: {e}")
        return {'FINISHED'}


batch_classes = (
    RENDERFLO_OT_cancel_batch_render,
    RENDERFLO_OT_batch_render,
    RENDERFLO_OT_render_action_bar,
    RENDERFLO_OT_open_render_folder,
)


def register():
    for cls in batch_classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(batch_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

