# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.0.0 — Property Groups & Scene Custom Properties.
Defines data structures for Studios, CMF variations, HDRI Dome & Pins, Decals, and Section Cutaways.
"""

import bpy
import math
from .state import ASPECT_PRESETS, CONTRAST_PRESETS, is_internal_update, internal_update_guard


# ------------------------------------------------------------------------
# Callback Dispatchers (Lazy imports to prevent circular references)
# ------------------------------------------------------------------------

def _dispatch_hdri_pin_update(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import lighting_hdri
    lighting_hdri.on_hdri_pin_update(self, context)


def _dispatch_studio_hdri_update(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import lighting_hdri
    lighting_hdri.on_studio_hdri_update(self, context)


def _dispatch_studio_viewport_dome_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import lighting_hdri
    lighting_hdri.on_studio_viewport_dome_change(self, context)


def _dispatch_studio_camera_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import studio_manager
    studio_manager.on_studio_camera_change(self, context)


def _dispatch_studio_cmf_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import cmf_materials
    cmf_materials.on_studio_cmf_change(self, context)


def _dispatch_studio_use_materials_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import cmf_materials
    cmf_materials.on_studio_use_materials_change(self, context)


def _dispatch_studio_image_style_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import studio_manager
    studio_manager.on_studio_image_style_change(self, context)


def _dispatch_studio_lock_change(self, context):
    if not context or not getattr(context, "scene", None):
        return
    from .modules import studio_manager
    studio_manager.on_studio_lock_change(self, context)


def _dispatch_studio_aspect_ratio(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import studio_manager
    studio_manager.update_studio_aspect_ratio(self, context)


def _dispatch_global_render_settings(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import batch_queue
    batch_queue.update_global_render_settings(self, context)


def _dispatch_studio_samples_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    scene = context.scene
    if 0 <= scene.rf_studio_index < len(scene.rf_studios):
        if scene.rf_studios[scene.rf_studio_index] == self:
            from .modules.batch_queue import apply_render_quality_settings
            target_samples = self.studio_samples if self.use_custom_samples else scene.rf_render_samples
            apply_render_quality_settings(scene, target_samples)


def _dispatch_active_studio_index_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    scene = context.scene
    if len(scene.rf_studios) == 0:
        if scene.rf_studio_index != 0:
            scene.rf_studio_index = 0
        return
    if scene.rf_studio_index >= len(scene.rf_studios):
        scene.rf_studio_index = max(0, len(scene.rf_studios) - 1)
        return
    from .modules import studio_manager
    studio_manager.on_active_studio_index_change(self, context)


def _dispatch_orbit_mode_change(self, context):
    from .ui import header_ribbon
    header_ribbon.on_orbit_mode_change(self, context)


def _dispatch_zebra_matcap_change(self, context):
    from .ui import header_ribbon
    header_ribbon.on_zebra_matcap_change(self, context)


def _dispatch_explode_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import flex_deform
    flex_deform.update_exploded_view(context.scene, self.rf_explode_factor)


def _dispatch_turntable_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    from .modules import flex_deform
    flex_deform.update_turntable_rotation(context.scene, self.rf_turntable_angle)


def get_studio_enum_items(self, context):
    items = []
    if context and getattr(context, "scene", None):
        for idx, s in enumerate(context.scene.rf_studios):
            items.append((str(idx), s.name, f"Switch to studio '{s.name}'"))
    if not items:
        items.append(('0', "Default Studio", "Default studio setup"))
    return items


def on_active_studio_enum_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    try:
        target_idx = int(self.rf_active_studio_enum)
        scene = context.scene
        if 0 <= target_idx < len(scene.rf_studios) and target_idx != scene.rf_studio_index:
            bpy.ops.renderflo.activate_studio(index=target_idx)
    except (ValueError, TypeError):
        pass


def get_aspect_ratio_enum_items(self, context):
    from .state import ASPECT_PRESETS
    return [(c, n, d) for c, n, d, _, _ in ASPECT_PRESETS]


def on_active_aspect_ratio_enum_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    scene = context.scene
    if 0 <= scene.rf_studio_index < len(scene.rf_studios):
        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.aspect_preset != self.rf_active_aspect_preset_enum:
            studio.aspect_preset = self.rf_active_aspect_preset_enum


def get_cmf_dropdown_items(self, context):
    items = []
    if context and getattr(context, "scene", None):
        for idx, cmf in enumerate(context.scene.rf_cmf_presets):
            items.append((cmf.name, cmf.name, f"Apply CMF colorway '{cmf.name}'", 'COLOR', idx))
    if not items:
        items = [('Default', "Default", "Default product materials", 'COLOR', 0)]
    return items


def on_active_cmf_dropdown_change(self, context):
    if is_internal_update() or not context or not getattr(context, "scene", None):
        return
    scene = context.scene
    from .modules import cmf_materials
    if 0 <= scene.rf_studio_index < len(scene.rf_studios):
        studio = scene.rf_studios[scene.rf_studio_index]
        if studio.cmf_mode != self.rf_active_cmf_enum:
            studio.cmf_mode = self.rf_active_cmf_enum
            cmf_materials.apply_cmf_to_scene(scene, studio)
    else:
        cmf = next((c for c in scene.rf_cmf_presets if c.name == self.rf_active_cmf_enum), None)
        if cmf:
            cmf_materials.restore_materials_from_collection(cmf.object_materials)


def get_cmf_enum_items(self, context):
    return get_cmf_dropdown_items(self, context)


# ------------------------------------------------------------------------
# Property Groups
# ------------------------------------------------------------------------

class RENDERFLO_PG_collection_state(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Collection Name")
    hide_viewport: bpy.props.BoolProperty(name="Hide Viewport")
    hide_render: bpy.props.BoolProperty(name="Hide Render")


class RENDERFLO_PG_material_slot(bpy.types.PropertyGroup):
    slot_index: bpy.props.IntProperty(name="Slot Index")
    material_name: bpy.props.StringProperty(name="Material Name")


class RENDERFLO_PG_object_materials(bpy.types.PropertyGroup):
    object_name: bpy.props.StringProperty(name="Object Name")
    slots: bpy.props.CollectionProperty(type=RENDERFLO_PG_material_slot)


class RENDERFLO_PG_object_transform(bpy.types.PropertyGroup):
    object_name: bpy.props.StringProperty(name="Object Name")
    location: bpy.props.FloatVectorProperty(size=3)
    rotation_euler: bpy.props.FloatVectorProperty(size=3)
    scale: bpy.props.FloatVectorProperty(size=3, default=(1.0, 1.0, 1.0))


class RENDERFLO_PG_cmf_preset(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="CMF Name", default="CMF_01")
    object_materials: bpy.props.CollectionProperty(type=RENDERFLO_PG_object_materials)


class RENDERFLO_PG_studio_cmf_toggle(bpy.types.PropertyGroup):
    cmf_name: bpy.props.StringProperty(name="CMF Name")
    enabled: bpy.props.BoolProperty(name="Include in Matrix", default=True)


class RENDERFLO_PG_light_state(bpy.types.PropertyGroup):
    light_obj_name: bpy.props.StringProperty(name="Light Object")
    location: bpy.props.FloatVectorProperty(size=3)
    rotation_euler: bpy.props.FloatVectorProperty(size=3)
    scale: bpy.props.FloatVectorProperty(size=3, default=(1.0, 1.0, 1.0))
    energy: bpy.props.FloatProperty(default=100.0)
    color: bpy.props.FloatVectorProperty(size=3, subtype='COLOR', default=(1.0, 1.0, 1.0))
    size: bpy.props.FloatProperty(default=1.0)
    hide_viewport: bpy.props.BoolProperty(default=False)
    hide_render: bpy.props.BoolProperty(default=False)


class RENDERFLO_PG_hdri_pin(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Pin Name", default="Pin_01")
    enabled: bpy.props.BoolProperty(name="Enabled", default=True, update=_dispatch_hdri_pin_update)
    pin_shape: bpy.props.EnumProperty(
        name="Shape",
        items=[
            ('CIRCLE', "Round Pin", "Circular radial highlight pin"),
            ('RECT', "Softbox Strip", "Rectangular directional softbox strip"),
        ],
        default='CIRCLE',
        update=_dispatch_hdri_pin_update
    )
    azimuth: bpy.props.FloatProperty(
        name="Azimuth",
        description="Horizontal angle in degrees",
        default=45.0,
        min=-180.0,
        max=180.0,
        update=_dispatch_hdri_pin_update
    )
    elevation: bpy.props.FloatProperty(
        name="Elevation",
        description="Vertical angle in degrees",
        default=35.0,
        min=-90.0,
        max=90.0,
        update=_dispatch_hdri_pin_update
    )
    radius: bpy.props.FloatProperty(
        name="Size",
        description="Angular size of the pin (small values create sharp pinpoint highlights)",
        default=0.08,
        min=0.0005,
        max=1.5,
        precision=4,
        step=0.1,
        update=_dispatch_hdri_pin_update
    )
    aspect: bpy.props.FloatProperty(
        name="Aspect Ratio",
        description="Width-to-height ratio when pin_shape is RECT",
        default=2.0,
        min=0.05,
        max=20.0,
        precision=2,
        update=_dispatch_hdri_pin_update
    )
    rotation: bpy.props.FloatProperty(
        name="Tilt",
        description="2D tilt angle in degrees for rectangular softbox pin",
        default=0.0,
        min=-180.0,
        max=180.0,
        update=_dispatch_hdri_pin_update
    )
    falloff: bpy.props.FloatProperty(
        name="Glow / Falloff",
        description="Edge softness / glow feathering (lower for crisp glints, higher for soft wrap)",
        default=0.04,
        min=0.0001,
        max=1.0,
        precision=4,
        step=0.1,
        update=_dispatch_hdri_pin_update
    )
    energy: bpy.props.FloatProperty(
        name="Energy",
        description="Intensity / brightness",
        default=15.0,
        min=0.0,
        max=500.0,
        update=_dispatch_hdri_pin_update
    )
    color: bpy.props.FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        update=_dispatch_hdri_pin_update
    )


class RENDERFLO_PG_decal_settings(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Decal Name", default="Decal")
    image: bpy.props.PointerProperty(name="Logo / Artwork", type=bpy.types.Image)
    scale: bpy.props.FloatProperty(name="Scale", default=1.0, min=0.01, max=100.0)
    rotation: bpy.props.FloatProperty(name="Rotation", default=0.0, min=-180.0, max=180.0)
    opacity: bpy.props.FloatProperty(name="Opacity", default=1.0, min=0.0, max=1.0)
    metallic: bpy.props.FloatProperty(name="Metallic", default=0.0, min=0.0, max=1.0)
    roughness: bpy.props.FloatProperty(name="Roughness", default=0.2, min=0.0, max=1.0)


class RENDERFLO_PG_cutaway_settings(bpy.types.PropertyGroup):
    enabled: bpy.props.BoolProperty(name="Enable Section Cutaway", default=False)
    axis: bpy.props.EnumProperty(
        name="Cut Axis",
        items=[
            ('X', "X-Axis (Sagittal)", "Cut perpendicular to X axis"),
            ('Y', "Y-Axis (Coronal)", "Cut perpendicular to Y axis"),
            ('Z', "Z-Axis (Horizontal)", "Cut perpendicular to Z axis"),
        ],
        default='X'
    )
    slice_position: bpy.props.FloatProperty(name="Slice Offset", default=0.0)
    invert: bpy.props.BoolProperty(name="Invert Cut Direction", default=False)
    cap_color: bpy.props.FloatVectorProperty(name="Cap Fill Color", subtype='COLOR', size=3, default=(0.9, 0.35, 0.05))
    cap_roughness: bpy.props.FloatProperty(name="Cap Roughness", default=0.3, min=0.0, max=1.0)


class RENDERFLO_PG_cable_settings(bpy.types.PropertyGroup):
    cable_diameter: bpy.props.FloatProperty(name="Diameter (mm)", default=4.0, min=0.5, max=50.0)
    slack_sag: bpy.props.FloatProperty(name="Sag / Gravity Slack", default=0.2, min=0.0, max=2.0)
    resolution: bpy.props.IntProperty(name="Curve Resolution", default=24, min=4, max=128)
    braided_look: bpy.props.BoolProperty(name="Braided Nylon Material", default=True)


class RENDERFLO_PG_strap_settings(bpy.types.PropertyGroup):
    bend_angle: bpy.props.FloatProperty(name="Bend Angle", default=65.0, min=0.0, max=180.0)
    wrist_radius: bpy.props.FloatProperty(name="Wrist Radius (mm)", default=30.0, min=5.0, max=150.0)
    strap_axis: bpy.props.EnumProperty(
        name="Length Axis",
        items=[('Y', "Y-Axis", "Length runs along Y"), ('X', "X-Axis", "Length runs along X"), ('Z', "Z-Axis", "Length runs along Z")],
        default='Y'
    )


class RENDERFLO_PG_studio_item(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Studio Name", default="New Studio")
    render_enabled: bpy.props.BoolProperty(name="Include in Batch", default=True)
    is_locked: bpy.props.BoolProperty(
        name="Lock Studio",
        description="Freeze camera & lighting transforms and prevent auto-save overwrites",
        default=False,
        update=_dispatch_studio_lock_change
    )

    camera_obj: bpy.props.PointerProperty(
        name="Camera",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'CAMERA',
        update=_dispatch_studio_camera_change
    )

    aspect_preset: bpy.props.EnumProperty(
        name="Aspect Ratio",
        items=[(c, n, d) for c, n, d, _, _ in ASPECT_PRESETS],
        default='16_9',
        update=_dispatch_studio_aspect_ratio
    )
    base_resolution: bpy.props.IntProperty(name="Long Edge (px)", default=1920, min=128, max=16384, update=_dispatch_studio_aspect_ratio)
    res_x: bpy.props.IntProperty(name="Width (X)", default=1920, min=64, max=16384, update=_dispatch_studio_aspect_ratio)
    res_y: bpy.props.IntProperty(name="Height (Y)", default=1080, min=64, max=16384, update=_dispatch_studio_aspect_ratio)
    res_scale: bpy.props.IntProperty(name="Resolution %", default=100, min=10, max=400, subtype='PERCENTAGE', update=_dispatch_studio_aspect_ratio)

    use_custom_samples: bpy.props.BoolProperty(
        name="Custom Samples for Studio",
        description="Override global samples specifically for this Studio",
        default=False,
        update=_dispatch_studio_samples_change
    )
    studio_samples: bpy.props.IntProperty(
        name="Studio Samples",
        description="Cycles render samples for this specific studio",
        default=256,
        min=1,
        max=65536,
        update=_dispatch_studio_samples_change
    )

    light_collection_name: bpy.props.StringProperty(name="Studio Light Collection")
    world_name: bpy.props.StringProperty(name="World")

    # Procedural HDRI Dome & Interactive Pin Properties
    use_hdri_dome: bpy.props.BoolProperty(
        name="Use Procedural HDRI Dome",
        description="Generate procedural HDRI studio dome with interactive highlight pins",
        default=True,
        update=_dispatch_studio_hdri_update
    )
    use_custom_hdri: bpy.props.BoolProperty(
        name="Use HDRI Map",
        description="Use an external HDRI or EXR environment image as background",
        default=False,
        update=_dispatch_studio_hdri_update
    )
    hdri_image: bpy.props.PointerProperty(
        name="HDRI Map",
        type=bpy.types.Image,
        description="External HDRI or EXR environment image",
        update=_dispatch_studio_hdri_update
    )
    hdri_image_strength: bpy.props.FloatProperty(
        name="HDRI Intensity",
        description="Brightness intensity multiplier for the external HDRI map",
        default=1.0,
        min=0.0,
        max=50.0,
        update=_dispatch_studio_hdri_update
    )
    hdri_base_color: bpy.props.FloatVectorProperty(
        name="Base Color",
        description="Ambient background tint of the HDRI dome",
        subtype='COLOR',
        size=3,
        default=(0.05, 0.05, 0.06),
        min=0.0,
        max=1.0,
        update=_dispatch_studio_hdri_update
    )
    hdri_base_energy: bpy.props.FloatProperty(
        name="Base Energy",
        description="Background ambient brightness",
        default=0.5,
        min=0.0,
        max=50.0,
        update=_dispatch_studio_hdri_update
    )
    hdri_rotation: bpy.props.FloatProperty(
        name="HDRI Rotation",
        description="Global dome Z-rotation in degrees",
        default=0.0,
        min=-180.0,
        max=180.0,
        update=_dispatch_studio_hdri_update
    )
    hdri_glow_size: bpy.props.FloatProperty(
        name="HDRI Glow (Distance Scale)",
        description="Scale the size of the HDRI glow and pin highlights to simulate lights closer or farther based on product size",
        default=1.0,
        min=0.01,
        max=10.0,
        precision=3,
        step=0.1,
        update=_dispatch_studio_hdri_update
    )
    hdri_pins: bpy.props.CollectionProperty(type=RENDERFLO_PG_hdri_pin)
    viewport_show_dome: bpy.props.BoolProperty(
        name="Show Dome in Viewport",
        description="Show procedural HDRI dome in 3D Viewport background (temporarily disables transparent film during interactive design)",
        default=True,
        update=_dispatch_studio_viewport_dome_change
    )
    hdri_preview_image: bpy.props.PointerProperty(type=bpy.types.Image)

    cmf_mode: bpy.props.EnumProperty(name="CMF Variation", items=get_cmf_enum_items, update=_dispatch_studio_cmf_change)

    exposure: bpy.props.FloatProperty(name="Exposure", default=0.0, min=-10.0, max=10.0, update=_dispatch_studio_image_style_change)
    contrast: bpy.props.EnumProperty(
        name="Contrast",
        description="Color management look / contrast tone curve",
        items=[(k, l, d) for k, l, d in CONTRAST_PRESETS],
        default='None',
        update=_dispatch_studio_image_style_change
    )
    film_transparent: bpy.props.BoolProperty(name="Transparent PNG", default=True, update=_dispatch_studio_image_style_change)

    use_camera: bpy.props.BoolProperty(name="Camera", default=True)
    use_resolution: bpy.props.BoolProperty(name="Aspect Ratio & Res", default=True)
    use_lights: bpy.props.BoolProperty(name="Lights & HDRI", default=True)
    lighting_tab: bpy.props.EnumProperty(
        name="Lighting Module",
        description="Switch between KeyShot-style HDRI Dome & Pins and Physical Lamps",
        items=[
            ('HDRI', "HDRI Dome & Pins", "KeyShot-style procedural HDRI dome and highlight pins", 'WORLD', 0),
            ('LIGHTS', "Physical Lights", "Key, Rim, and Fill studio lamps", 'LIGHT_SUN', 1),
        ],
        default='HDRI'
    )
    use_materials: bpy.props.BoolProperty(name="CMF (Materials)", default=True, update=_dispatch_studio_use_materials_change)
    use_collections: bpy.props.BoolProperty(name="Model Sets", default=True)
    use_transforms: bpy.props.BoolProperty(name="Exploded / Part Positions", default=False)
    use_image_style: bpy.props.BoolProperty(name="Image Style", default=True)

    cmf_matrix_toggles: bpy.props.CollectionProperty(type=RENDERFLO_PG_studio_cmf_toggle)
    collection_states: bpy.props.CollectionProperty(type=RENDERFLO_PG_collection_state)
    object_materials: bpy.props.CollectionProperty(type=RENDERFLO_PG_object_materials)
    object_transforms: bpy.props.CollectionProperty(type=RENDERFLO_PG_object_transform)
    light_states: bpy.props.CollectionProperty(type=RENDERFLO_PG_light_state)


# ------------------------------------------------------------------------
# Registration of Property Groups & Scene Props
# ------------------------------------------------------------------------

property_classes = (
    RENDERFLO_PG_collection_state,
    RENDERFLO_PG_material_slot,
    RENDERFLO_PG_object_materials,
    RENDERFLO_PG_object_transform,
    RENDERFLO_PG_cmf_preset,
    RENDERFLO_PG_studio_cmf_toggle,
    RENDERFLO_PG_light_state,
    RENDERFLO_PG_hdri_pin,
    RENDERFLO_PG_decal_settings,
    RENDERFLO_PG_cutaway_settings,
    RENDERFLO_PG_cable_settings,
    RENDERFLO_PG_strap_settings,
    RENDERFLO_PG_studio_item,
)


def register_properties():
    for cls in property_classes:
        bpy.utils.register_class(cls)

    # Core collections
    bpy.types.Scene.rf_studios = bpy.props.CollectionProperty(type=RENDERFLO_PG_studio_item)
    bpy.types.Scene.rf_cmf_presets = bpy.props.CollectionProperty(type=RENDERFLO_PG_cmf_preset)
    bpy.types.Scene.rf_studio_index = bpy.props.IntProperty(
        name="Active Studio Index",
        default=0,
        min=0,
        update=_dispatch_active_studio_index_change
    )
    bpy.types.Scene.rf_active_studio_enum = bpy.props.EnumProperty(
        name="Studio",
        description="Select and activate Studio snapshot",
        items=get_studio_enum_items,
        update=on_active_studio_enum_change
    )
    bpy.types.Scene.rf_active_aspect_preset_enum = bpy.props.EnumProperty(
        name="Aspect Ratio",
        description="Select active studio framing ratio",
        items=get_aspect_ratio_enum_items,
        update=on_active_aspect_ratio_enum_change
    )
    bpy.types.Scene.rf_active_cmf_enum = bpy.props.EnumProperty(
        name="CMF Colorway",
        description="Switch active colorway preset across product components",
        items=get_cmf_dropdown_items,
        update=on_active_cmf_dropdown_change
    )
    bpy.types.Scene.rf_explode_factor = bpy.props.FloatProperty(
        name="Explode Assembly",
        description="Parametric non-destructive exploded view of product parts",
        default=0.0,
        min=0.0,
        max=100.0,
        subtype='PERCENTAGE',
        update=_dispatch_explode_change
    )
    bpy.types.Scene.rf_turntable_angle = bpy.props.FloatProperty(
        name="Turntable Orbit",
        description="Rotate product assembly around optical center Z-axis",
        default=0.0,
        min=0.0,
        max=math.pi * 2,
        subtype='ANGLE',
        update=_dispatch_turntable_change
    )

    # Sub-settings
    bpy.types.Scene.rf_decal_settings = bpy.props.PointerProperty(type=RENDERFLO_PG_decal_settings)
    bpy.types.Scene.rf_cutaway_settings = bpy.props.PointerProperty(type=RENDERFLO_PG_cutaway_settings)
    bpy.types.Scene.rf_cable_settings = bpy.props.PointerProperty(type=RENDERFLO_PG_cable_settings)
    bpy.types.Scene.rf_strap_settings = bpy.props.PointerProperty(type=RENDERFLO_PG_strap_settings)

    # Navigation & Viewport Workspace Controls
    bpy.types.Scene.rf_ui_tab = bpy.props.EnumProperty(
        name="Studio Tab",
        description="Select active inspector module",
        items=[
            ('CAD', "CAD Bridge", "Import CAD (.STEP/.3DM) and 1-Click Hot-Reload", 'IMPORT', 0),
            ('STUDIOS', "Studios", "Studio snapshot manager, camera framing, and custom samples", 'CAMERA_DATA', 1),
            ('LIGHTING', "Lighting", "Procedural HDRI pins & physical studio softboxes", 'LIGHT_SUN', 2),
            ('CMF', "CMF Matrix", "Color, Material & Finish Presets", 'MATERIAL', 3),
            ('DECALS', "Decals & FX", "Raycast conformal decals and live section cutaways", 'MOD_BOOLEAN', 4),
            ('RENDER', "Render & Manufacturing (DXF)", "GPU batch render queue & DXF manufacturing export", 'RENDER_STILL', 5),
        ],
        default='CAD'
    )

    bpy.types.Scene.rf_orbit_mode = bpy.props.EnumProperty(
        name="Viewport Orbit Style",
        description="Switch viewport orbit navigation behavior",
        items=[
            ('BLENDER', "Blender Standard", "Default Turntable / Orbit behavior"),
            ('RHINO', "Rhino 3D Style", "Turntable + Zoom to Mouse cursor + Orbit around selection"),
            ('SOLIDWORKS', "SolidWorks Style", "Trackball / CAD Free-orbit mode"),
        ],
        default='BLENDER',
        update=_dispatch_orbit_mode_change
    )

    bpy.types.Scene.rf_zebra_enabled = bpy.props.BoolProperty(
        name="Zebra MatCap Analysis",
        description="Toggle Zebra striping MatCap to inspect Class-A surface curvature continuity",
        default=False,
        update=_dispatch_zebra_matcap_change
    )

    # Collapsible Section Properties
    bpy.types.Scene.rf_fold_cad = bpy.props.BoolProperty(name="CAD Engine", default=False)
    bpy.types.Scene.rf_fold_new_studio = bpy.props.BoolProperty(name="New Studio Defaults", default=False)
    bpy.types.Scene.rf_fold_format = bpy.props.BoolProperty(name="Format & Aspect", default=True)
    bpy.types.Scene.rf_fold_camera = bpy.props.BoolProperty(name="Studio Camera", default=True)
    bpy.types.Scene.rf_fold_cmf = bpy.props.BoolProperty(name="CMF Variations", default=True)
    bpy.types.Scene.rf_fold_lighting = bpy.props.BoolProperty(name="Lighting Rig", default=True)
    bpy.types.Scene.rf_fold_env = bpy.props.BoolProperty(name="Environment & Backdrop", default=False)
    bpy.types.Scene.rf_fold_gpu = bpy.props.BoolProperty(name="GPU & Render Settings", default=False)
    bpy.types.Scene.rf_fold_decals = bpy.props.BoolProperty(name="Decals & Stickers", default=True)
    bpy.types.Scene.rf_fold_cutaways = bpy.props.BoolProperty(name="Live Section Cutaway", default=True)
    bpy.types.Scene.rf_fold_flex = bpy.props.BoolProperty(name="Strap & Cable Tools", default=True)

    bpy.types.Scene.rf_studio_new_cam_mode = bpy.props.EnumProperty(
        name="New Studio Camera",
        items=[
            ('LINK_CURRENT', "Link Current Camera (Shared)", "Use the exact same Camera object as the current Studio"),
            ('NEW_COPY', "Spawn New Camera (Copy Angle)", "Create a new independent Camera starting at the current camera's angle"),
            ('NEW_VIEW', "Spawn New Camera (From 3D View)", "Create a new independent Camera matching your current 3D Viewport angle"),
        ],
        default='LINK_CURRENT'
    )
    bpy.types.Scene.rf_studio_clone_lights = bpy.props.BoolProperty(name="Clone Current Studio Lights", default=False)
    bpy.types.Scene.rf_auto_save_studios = bpy.props.BoolProperty(
        name="Live Auto-Save Studios",
        description="Continuously save changes to camera and lights automatically into the active Studio",
        default=True
    )

    bpy.types.Scene.rf_force_gpu = bpy.props.BoolProperty(
        name="Force GPU Compute",
        description="Configure Cycles to use dedicated GPU (OptiX / CUDA / HIP / Metal)",
        default=True,
        update=_dispatch_global_render_settings
    )
    bpy.types.Scene.rf_render_samples = bpy.props.IntProperty(
        name="Render Samples",
        description="Cycles sample count for final Studio renders",
        default=256,
        min=1,
        max=65536,
        update=_dispatch_global_render_settings
    )
    bpy.types.Scene.rf_viewport_samples = bpy.props.IntProperty(
        name="Viewport Samples",
        description="Cycles sample count for 3D Viewport preview",
        default=64,
        min=1,
        max=4096,
        update=_dispatch_global_render_settings
    )
    bpy.types.Scene.rf_use_denoiser = bpy.props.BoolProperty(
        name="Use Denoiser",
        description="Enable Cycles AI Denoising for clean studio renders",
        default=True,
        update=_dispatch_global_render_settings
    )
    bpy.types.Scene.rf_noise_threshold = bpy.props.FloatProperty(
        name="Adaptive Noise Limit",
        description="Stop sampling pixels once they reach this noise threshold",
        default=0.01,
        min=0.0001,
        max=1.0,
        update=_dispatch_global_render_settings
    )

    bpy.types.Scene.rf_is_batch_rendering = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.rf_batch_progress = bpy.props.FloatProperty(default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE')
    bpy.types.Scene.rf_batch_status_text = bpy.props.StringProperty(default="")

    # CAD Hot-Reload Cache
    bpy.types.Scene.rf_last_cad_filepath = bpy.props.StringProperty(name="Last Imported CAD File", default="")
    bpy.types.Scene.rf_last_cad_collection = bpy.props.StringProperty(name="Last CAD Collection", default="")

    # Render Output Directory
    bpy.types.Scene.rf_render_output_dir = bpy.props.StringProperty(
        name="Render Output Directory",
        description="Folder where rendered images and batch outputs will be saved",
        default="",
        subtype='DIR_PATH',
    )


def unregister_properties():
    scene_props = (
        "rf_render_output_dir",
        "rf_turntable_angle", "rf_explode_factor",
        "rf_active_cmf_enum", "rf_active_aspect_preset_enum", "rf_active_studio_enum",
        "rf_last_cad_collection", "rf_last_cad_filepath",
        "rf_fold_flex", "rf_fold_cutaways", "rf_fold_decals",
        "rf_fold_gpu", "rf_fold_env", "rf_fold_lighting", "rf_fold_cmf",
        "rf_fold_camera", "rf_fold_format", "rf_fold_new_studio", "rf_fold_cad",
        "rf_batch_status_text", "rf_batch_progress", "rf_is_batch_rendering",
        "rf_noise_threshold", "rf_use_denoiser", "rf_viewport_samples",
        "rf_render_samples", "rf_force_gpu", "rf_auto_save_studios",
        "rf_studio_clone_lights", "rf_studio_new_cam_mode",
        "rf_zebra_enabled", "rf_orbit_mode", "rf_ui_tab",
        "rf_strap_settings", "rf_cable_settings", "rf_cutaway_settings", "rf_decal_settings",
        "rf_studio_index", "rf_cmf_presets", "rf_studios"
    )
    for prop in scene_props:
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)

    for cls in reversed(property_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

