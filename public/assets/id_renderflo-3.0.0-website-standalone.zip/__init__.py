# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.0.0 — Universal Industrial Design Studio & CAD Pipeline Suite for Blender.
Created by Sahitya Kashyap (https://sahityakashyap.in)
Dual licensed under GPL-3.0-or-later and MIT.
"""

bl_info = {
    "name": "ID RenderFlo",
    "author": "Sahitya Kashyap (sahityakashyap.in)",
    "version": (3, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N-Panel) > ID RenderFlo & Top Viewport Ribbon & File > Import > CAD",
    "description": "Universal Industrial Design Studio Suite & Parametric CAD Pipeline: Native Rhino .3dm & OpenCASCADE STEP Importer with 1-Click Hot-Reload, Multi-Studio Snapshots, Procedural HDRI Dome & 2D Pin Canvas, CMF Matrix Presets, Raycast Decal Dropper, Live Section Cutaways, GPU Batch Queue & Manufacturing DXF Export",
    "doc_url": "https://sahityakashyap.in",
    "tracker_url": "https://sahityakashyap.in",
    "category": "Render",
}

import sys
import importlib
import bpy

# ------------------------------------------------------------------------
# Submodule Reloading (Topological Order)
# ------------------------------------------------------------------------
_submodule_names = [
    "state",
    "properties",
    "modules.cad_bridge",
    "modules.studio_manager",
    "modules.lighting_hdri",
    "modules.cmf_materials",
    "modules.decals_cutaways",
    "modules.flex_deform",
    "modules.batch_queue",
    "ui.header_ribbon",
    "ui.left_toolbar",
    "ui.main_panel",
]

_loaded_modules = {}
for name in _submodule_names:
    full_name = f"{__name__}.{name}"
    if full_name in sys.modules:
        _loaded_modules[name] = importlib.reload(sys.modules[full_name])

from . import state
from . import properties
from .modules import (
    cad_bridge,
    studio_manager,
    lighting_hdri,
    cmf_materials,
    decals_cutaways,
    flex_deform,
    batch_queue,
)
from .ui import (
    header_ribbon,
    left_toolbar,
    main_panel,
)

# ------------------------------------------------------------------------
# Addon Preferences & CAD Configuration
# ------------------------------------------------------------------------

class IDRenderFloPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__ or __name__.partition('.')[0]

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="ID RenderFlo — CAD Engine Configuration (Standalone Edition)", icon='PREFERENCES')

        occ_ok = cad_bridge.is_cascadio_ready()
        rhino_ok = cad_bridge.is_rhino_ready()

        col = box.column(align=True)
        r1 = col.row()
        r1.label(text="OpenCASCADE (cascadio / STEP / IGES):", icon='CHECKMARK' if occ_ok else 'CANCEL')
        r1.label(text="Active" if occ_ok else "Not Installed")

        r2 = col.row()
        r2.label(text="Rhino3DM (.3dm geometry):", icon='CHECKMARK' if rhino_ok else 'CANCEL')
        r2.label(text="Active" if rhino_ok else "Not Installed")

        row = box.row(align=True)
        row.scale_y = 1.3
        op_all = row.operator("renderflo.bootstrap_cad_kernel", text="Install CAD Engine (OCC & Rhino)", icon='IMPORT')
        op_all.package = 'ALL'
        row.operator("renderflo.browse_cad_wheel", text="Browse Offline Wheel / Archive...", icon='FILE_FOLDER')
        row.operator("renderflo.recheck_cad_engine", text="Recheck", icon='FILE_REFRESH')

        if not occ_ok or not rhino_ok:
            row_sub = box.row(align=True)
            if not occ_ok:
                op_occ = row_sub.operator("renderflo.bootstrap_cad_kernel", text="Install OpenCASCADE Only", icon='IMPORT')
                op_occ.package = 'OCC'
            if not rhino_ok:
                op_rh = row_sub.operator("renderflo.bootstrap_cad_kernel", text="Install Rhino3DM Only", icon='IMPORT')
                op_rh.package = 'RHINO'

        paths_box = layout.box()
        paths_box.label(text="CAD Engine Search & Storage Paths:", icon='FILE_FOLDER')
        search_paths = cad_bridge.get_extension_search_paths()
        if search_paths:
            for p in search_paths:
                paths_box.label(text=p)
        else:
            paths_box.label(text="No search paths active")


# ------------------------------------------------------------------------
# Keymaps
# ------------------------------------------------------------------------
addon_keymaps = []


def register_keymaps():
    wm = bpy.context.window_manager
    kc = getattr(wm, "keyconfigs", None)
    if not kc or not getattr(kc, "addon", None):
        return

    km = kc.addon.keymaps.new(name='3D View', space_type='VIEW_3D')
    # Alt + Shift + R -> Wide Floating Studio Dashboard
    kmi = km.keymap_items.new(
        "renderflo.studio_dashboard",
        type='R',
        value='PRESS',
        alt=True,
        shift=True
    )
    addon_keymaps.append((km, kmi))


def unregister_keymaps():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()


# ------------------------------------------------------------------------
# Registration & Unregistration
# ------------------------------------------------------------------------

def register():
    # 0. Preferences
    try:
        bpy.utils.register_class(IDRenderFloPreferences)
    except Exception:
        pass

    # 1. Properties
    properties.register_properties()

    # 2. Functional Modules
    cad_bridge.register()
    try:
        cad_bridge.refresh_engine_status()
    except Exception:
        pass
    studio_manager.register()
    lighting_hdri.register()
    cmf_materials.register()
    decals_cutaways.register()
    flex_deform.register()
    batch_queue.register()

    # 3. User Interface
    header_ribbon.register()
    left_toolbar.register()
    main_panel.register()

    # 4. Keymaps
    try:
        register_keymaps()
    except Exception:
        pass


def unregister():
    # 1. Keymaps
    unregister_keymaps()

    # 2. User Interface
    main_panel.unregister()
    left_toolbar.unregister()
    header_ribbon.unregister()

    # 3. Functional Modules
    batch_queue.unregister()
    flex_deform.unregister()
    decals_cutaways.unregister()
    cmf_materials.unregister()
    lighting_hdri.unregister()
    studio_manager.unregister()
    cad_bridge.unregister()

    # 4. Properties
    properties.unregister_properties()

    # 5. Preferences
    try:
        bpy.utils.unregister_class(IDRenderFloPreferences)
    except Exception:
        pass


if __name__ == "__main__":
    register()