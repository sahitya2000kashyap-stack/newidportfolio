# -*- coding: utf-8 -*-
"""
ID RenderFlo v3.0.0 — Left Toolbar Quick Action Buttons.
T-Panel quick actions for rapid CAD import, studio staging, lighting, decals, cutaways, and batch queue.
"""

import bpy


class RENDERFLO_PT_left_toolbar(bpy.types.Panel):
    bl_label = "ID RenderFlo Quick Actions"
    bl_idname = "RENDERFLO_PT_left_toolbar"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'

    def draw(self, context):
        layout = self.layout

        # Primary Quick-Tools Stack (Mockup 1:1)
        col = layout.column(align=True)
        col.scale_y = 1.35

        col.operator("renderflo.place_highlight_modal", text="Pin", icon='EYEDROPPER')
        col.operator("renderflo.load_decal_image", text="Decal", icon='IMAGE_DATA')
        col.operator("renderflo.create_cutaway_box", text="Slice", icon='MOD_WIREFRAME')
        col.operator("renderflo.snap_shadow_floor", text="Floor", icon='MESH_PLANE')
        col.operator("renderflo.generate_router_outline", text="Router", icon='CURVE_DATA')

        layout.separator()

        # Secondary Quick Actions
        sec_box = layout.box()
        s_col = sec_box.column(align=True)
        s_col.scale_y = 1.1
        s_col.operator("renderflo.add_studio", text="New Studio", icon='ADD')
        s_col.operator("renderflo.interactive_hdri_canvas", text="HDRI Canvas", icon='WINDOW')


toolbar_classes = (
    RENDERFLO_PT_left_toolbar,
)


def register():
    for cls in toolbar_classes:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            pass


def unregister():
    for cls in reversed(toolbar_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
